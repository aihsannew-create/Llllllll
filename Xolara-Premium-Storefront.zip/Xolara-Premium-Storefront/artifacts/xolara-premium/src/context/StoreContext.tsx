import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Product, CartItem, CustomDesignSubmission, Order, ProductCategory, ProductColor } from '../types';
import { INITIAL_PRODUCTS } from '../data/initialProducts';
import { migrateLegacyUsdPricesToINR } from '../lib/currency';
import { migrateLegacySeedImages } from '../lib/catalogMigrations';

interface PromoCode {
  code: string;
  discountPercentage: number;
  description: string;
}

const AVAILABLE_PROMOS: PromoCode[] = [
  { code: 'XOLARA10', discountPercentage: 10, description: '10% off entire order' },
  { code: 'WEARYOURIDENTITY', discountPercentage: 15, description: '15% brand launch privilege' },
  { code: 'VIPDROP20', discountPercentage: 20, description: '20% VIP collector discount' },
];

interface ToastMessage {
  id: string;
  title: string;
  message: string;
  type?: 'success' | 'info' | 'crimson';
}

interface StoreContextType {
  products: Product[];
  activeCategory: ProductCategory;
  setActiveCategory: (cat: ProductCategory) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  selectedProduct: Product | null;
  setSelectedProduct: (product: Product | null) => void;
  
  // Navigation
  activeView: string;
  navigateTo: (view: string, product?: Product) => void;

  // Cart
  cart: CartItem[];
  addToCart: (product: Product, size: string, color: ProductColor, quantity?: number, customSpecs?: any) => void;
  removeFromCart: (cartItemId: string) => void;
  updateQuantity: (cartItemId: string, newQty: number) => void;
  clearCart: () => void;
  isCartOpen: boolean;
  setIsCartOpen: (open: boolean) => void;
  cartCount: number;
  cartSubtotal: number;
  cartDiscount: number;
  cartShipping: number;
  cartTax: number;
  cartTotal: number;
  appliedPromo: PromoCode | null;
  applyPromoCode: (code: string) => { success: boolean; message: string };
  removePromoCode: () => void;

  // Wishlist
  wishlist: string[];
  toggleWishlist: (productId: string) => void;
  isWishlistOpen: boolean;
  setIsWishlistOpen: (open: boolean) => void;

  // Search & Modals
  isSearchOpen: boolean;
  setIsSearchOpen: (open: boolean) => void;
  isCheckoutOpen: boolean;
  setIsCheckoutOpen: (open: boolean) => void;
  quickViewProduct: Product | null;
  setQuickViewProduct: (product: Product | null) => void;

  // Custom Designs
  customSubmissions: CustomDesignSubmission[];
  submitCustomDesign: (submission: Omit<CustomDesignSubmission, 'id' | 'createdAt' | 'status'>) => void;
  updateSubmissionStatus: (id: string, status: CustomDesignSubmission['status']) => void;

  // Orders
  orders: Order[];
  createOrder: (orderData: Omit<Order, 'id' | 'orderNumber' | 'createdAt' | 'status'>) => Order;

  // Admin / CMS Product Management
  addProduct: (product: Omit<Product, 'id' | 'createdAt' | 'rating' | 'reviewsCount'>) => void;
  updateProduct: (id: string, updated: Partial<Product>) => void;
  deleteProduct: (id: string) => void;
  resetToDefaultCatalog: () => void;

  // Toasts
  toasts: ToastMessage[];
  addToast: (title: string, message: string, type?: 'success' | 'info' | 'crimson') => void;
  removeToast: (id: string) => void;
}

const StoreContext = createContext<StoreContextType | undefined>(undefined);

export const StoreProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  // Load products from localStorage or fallback to INITIAL_PRODUCTS
  const [products, setProducts] = useState<Product[]>(() => {
    migrateLegacyUsdPricesToINR();
    migrateLegacySeedImages();
    try {
      const saved = localStorage.getItem('xolara_products');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {
      console.error('Error loading products from storage', e);
    }
    return INITIAL_PRODUCTS;
  });

  // Cart
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('xolara_cart');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Wishlist
  const [wishlist, setWishlist] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('xolara_wishlist');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Custom Design submissions
  const [customSubmissions, setCustomSubmissions] = useState<CustomDesignSubmission[]>(() => {
    try {
      const saved = localStorage.getItem('xolara_custom_submissions');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Orders
  const [orders, setOrders] = useState<Order[]>(() => {
    try {
      const saved = localStorage.getItem('xolara_orders');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // App UI State
  const [activeCategory, setActiveCategory] = useState<ProductCategory>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [activeView, setActiveView] = useState<string>('home');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isWishlistOpen, setIsWishlistOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);
  const [appliedPromo, setAppliedPromo] = useState<PromoCode | null>(null);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  // Sync to localStorage
  useEffect(() => {
    localStorage.setItem('xolara_products', JSON.stringify(products));
  }, [products]);

  useEffect(() => {
    localStorage.setItem('xolara_cart', JSON.stringify(cart));
  }, [cart]);

  useEffect(() => {
    localStorage.setItem('xolara_wishlist', JSON.stringify(wishlist));
  }, [wishlist]);

  useEffect(() => {
    localStorage.setItem('xolara_custom_submissions', JSON.stringify(customSubmissions));
  }, [customSubmissions]);

  useEffect(() => {
    localStorage.setItem('xolara_orders', JSON.stringify(orders));
  }, [orders]);

  // Toast notification helper
  const addToast = (title: string, message: string, type: 'success' | 'info' | 'crimson' = 'crimson') => {
    const id = Math.random().toString(36).substring(2, 9);
    setToasts(prev => [...prev, { id, title, message, type }]);
    setTimeout(() => {
      removeToast(id);
    }, 4000);
  };

  const removeToast = (id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  };

  // Navigation
  const navigateTo = (view: string, product?: Product) => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    if (view === 'product-detail' && product) {
      setSelectedProduct(product);
      setActiveView('product-detail');
    } else {
      setActiveView(view);
    }
  };

  // Cart operations
  const addToCart = (product: Product, size: string, color: ProductColor, quantity = 1, customSpecs?: any) => {
    const cartItemId = `${product.id}-${size}-${color.name}${customSpecs ? '-custom' : ''}`;
    
    setCart(prev => {
      const existing = prev.find(item => item.id === cartItemId);
      if (existing) {
        return prev.map(item =>
          item.id === cartItemId
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      }
      return [
        ...prev,
        {
          id: cartItemId,
          productId: product.id,
          product,
          selectedColor: color,
          selectedSize: size,
          quantity,
          customSpecs
        }
      ];
    });

    addToast('Added to Bag', `${product.name} (${size} / ${color.name}) is in your cart.`, 'crimson');
    setIsCartOpen(true);
  };

  const removeFromCart = (cartItemId: string) => {
    setCart(prev => prev.filter(item => item.id !== cartItemId));
    addToast('Bag Updated', 'Item removed from your bag.', 'info');
  };

  const updateQuantity = (cartItemId: string, newQty: number) => {
    if (newQty <= 0) {
      removeFromCart(cartItemId);
      return;
    }
    setCart(prev =>
      prev.map(item => (item.id === cartItemId ? { ...item, quantity: newQty } : item))
    );
  };

  const clearCart = () => {
    setCart([]);
  };

  // Promo Code
  const applyPromoCode = (code: string) => {
    const clean = code.trim().toUpperCase();
    const found = AVAILABLE_PROMOS.find(p => p.code === clean);
    if (found) {
      setAppliedPromo(found);
      addToast('VIP Code Applied', `${found.description} activated!`, 'success');
      return { success: true, message: `${found.discountPercentage}% discount unlocked!` };
    }
    return { success: false, message: 'Invalid promo code. Try XOLARA10 or WEARYOURIDENTITY' };
  };

  const removePromoCode = () => {
    setAppliedPromo(null);
  };

  // Cart Calculations
  const cartCount = cart.reduce((acc, item) => acc + item.quantity, 0);
  const cartSubtotal = cart.reduce((acc, item) => {
    const unitPrice = item.product.discountPrice ?? item.product.price;
    return acc + unitPrice * item.quantity;
  }, 0);

  const discountRate = appliedPromo ? appliedPromo.discountPercentage / 100 : 0;
  const cartDiscount = cartSubtotal * discountRate;
  // Delivery fees and tax are not estimated automatically; the store must confirm them manually.
  const cartShipping = 0;
  const cartTax = 0;
  const cartTotal = Math.max(0, cartSubtotal - cartDiscount + cartShipping + cartTax);

  // Wishlist
  const toggleWishlist = (productId: string) => {
    setWishlist(prev => {
      const exists = prev.includes(productId);
      if (exists) {
        addToast('Removed from Wishlist', 'Item removed from your saved pieces.', 'info');
        return prev.filter(id => id !== productId);
      } else {
        const prod = products.find(p => p.id === productId);
        addToast('Saved to Wishlist', `${prod ? prod.name : 'Item'} added to your wishlist.`, 'crimson');
        return [...prev, productId];
      }
    });
  };

  // Custom Design Submissions
  const submitCustomDesign = (submission: Omit<CustomDesignSubmission, 'id' | 'createdAt' | 'status'>) => {
    const newSubmission: CustomDesignSubmission = {
      ...submission,
      id: `des-${Date.now().toString().slice(-5)}`,
      status: 'Received',
      createdAt: new Date().toISOString().split('T')[0],
    };
    setCustomSubmissions(prev => [newSubmission, ...prev]);
    addToast('Design Request Saved Locally', 'This request is stored only in this browser and is not sent to the store.', 'info');
  };

  const updateSubmissionStatus = (id: string, status: CustomDesignSubmission['status']) => {
    setCustomSubmissions(prev =>
      prev.map(sub => (sub.id === id ? { ...sub, status } : sub))
    );
    addToast('Status Updated', `Submission ${id} status set to ${status}.`, 'info');
  };

  // Orders
  const createOrder = (orderData: Omit<Order, 'id' | 'orderNumber' | 'createdAt' | 'status'>): Order => {
    const orderNum = `XOL-${Math.floor(100000 + Math.random() * 900000)}`;
    const newOrder: Order = {
      ...orderData,
      id: `ord-${Date.now()}`,
      orderNumber: orderNum,
      status: 'Request Received',
      createdAt: new Date().toISOString(),
    };

    setOrders(prev => [newOrder, ...prev]);
    clearCart();
    setAppliedPromo(null);
    return newOrder;
  };

  // Admin CMS CRUD Operations
  const addProduct = (newProd: Omit<Product, 'id' | 'createdAt' | 'rating' | 'reviewsCount'>) => {
    const id = `xol-${Date.now().toString().slice(-4)}`;
    const created: Product = {
      ...newProd,
      tags: [...new Set([...newProd.tags, 'Made in India'])],
      id,
      rating: 0,
      reviewsCount: 0,
      createdAt: new Date().toISOString().split('T')[0],
    };
    setProducts(prev => [created, ...prev]);
    addToast('Product Published', `${created.name} was successfully added to the catalog.`, 'success');
  };

  const updateProduct = (id: string, updated: Partial<Product>) => {
    setProducts(prev =>
      prev.map(p => (
        p.id === id
          ? {
              ...p,
              ...updated,
              tags: [...new Set([...(updated.tags ?? p.tags), 'Made in India'])],
            }
          : p
      ))
    );
    addToast('Catalog Updated', `Product details have been saved.`, 'info');
  };

  const deleteProduct = (id: string) => {
    setProducts(prev => prev.filter(p => p.id !== id));
    addToast('Product Deleted', 'Product has been removed from catalog.', 'info');
  };

  const resetToDefaultCatalog = () => {
    setProducts(INITIAL_PRODUCTS);
    localStorage.setItem('xolara_products', JSON.stringify(INITIAL_PRODUCTS));
    addToast('Catalog Reset', 'Products restored to initial XOLARA collection.', 'info');
  };

  return (
    <StoreContext.Provider
      value={{
        products,
        activeCategory,
        setActiveCategory,
        searchQuery,
        setSearchQuery,
        selectedProduct,
        setSelectedProduct,
        activeView,
        navigateTo,
        cart,
        addToCart,
        removeFromCart,
        updateQuantity,
        clearCart,
        isCartOpen,
        setIsCartOpen,
        cartCount,
        cartSubtotal,
        cartDiscount,
        cartShipping,
        cartTax,
        cartTotal,
        appliedPromo,
        applyPromoCode,
        removePromoCode,
        wishlist,
        toggleWishlist,
        isWishlistOpen,
        setIsWishlistOpen,
        isSearchOpen,
        setIsSearchOpen,
        isCheckoutOpen,
        setIsCheckoutOpen,
        quickViewProduct,
        setQuickViewProduct,
        customSubmissions,
        submitCustomDesign,
        updateSubmissionStatus,
        orders,
        createOrder,
        addProduct,
        updateProduct,
        deleteProduct,
        resetToDefaultCatalog,
        toasts,
        addToast,
        removeToast,
      }}
    >
      {children}
    </StoreContext.Provider>
  );
};

export const useStore = () => {
  const context = useContext(StoreContext);
  if (!context) {
    throw new Error('useStore must be used within a StoreProvider');
  }
  return context;
};
