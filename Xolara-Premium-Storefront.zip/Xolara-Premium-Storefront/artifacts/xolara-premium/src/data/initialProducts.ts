import { Product } from '../types';

export const INITIAL_PRODUCTS: Product[] = [
  {
    id: 'xol-001',
    sku: 'XOL-CRIMSON-OBSIDIAN',
    name: 'Obsidian Crimson Oversized Heavyweight Tee',
    slug: 'obsidian-crimson-oversized-tee',
    category: 'OVERSIZED',
    price: 5800,
    discountPrice: 4600,
    images: [
      '/xolara-editorial.png',
      '/product-images/black-tee-hanger.jpg',
      '/product-images/folded-tees.jpg'
    ],
    colors: [
      { name: 'Obsidian Black', hex: '#0a0a0f' },
      { name: 'Blood Crimson', hex: '#dc2626' },
      { name: 'Deep Violet', hex: '#6d28d9' }
    ],
    sizes: ['S', 'M', 'L', 'XL', '2XL'],
    description: 'Designed and made in India from heavyweight cotton, with a relaxed drop-shoulder fit, reinforced ribbed collar, and signature XOLARA chest graphic.',
    fabricSpecs: 'Combed cotton • 300 GSM • Pre-shrunk • Double-needle hem stitching',
    stock: 24,
    status: 'Active',
    isFeatured: true,
    isLimitedDrop: true,
    rating: 0,
    reviewsCount: 0,
    tags: ['Oversized', 'Heavyweight', 'Drop 01', 'Limited', 'Made in India'],
    createdAt: '2026-08-01'
  },
  {
    id: 'xol-002',
    sku: 'XOL-CYBER-PULSE-TEE',
    name: 'Cyber Violet Neon Graphic Boxy Tee',
    slug: 'cyber-violet-neon-boxy-tee',
    category: 'T-SHIRTS',
    price: 5250,
    discountPrice: 4100,
    images: [
      '/product-images/graphic-tee-model.jpg',
      '/product-images/black-tee-hanger.jpg'
    ],
    colors: [
      { name: 'Pitch Midnight', hex: '#0f1016' },
      { name: 'Royal Violet', hex: '#7c3aed' },
      { name: 'Charcoal Mist', hex: '#262633' }
    ],
    sizes: ['XS', 'S', 'M', 'L', 'XL', '2XL'],
    description: 'Made in India with a bold cyberpunk-inspired graphic and an easy boxy fit.',
    fabricSpecs: 'Ringspun cotton • 260 GSM • Screen-printed graphic • Seamless tubular torso',
    stock: 18,
    status: 'Active',
    isFeatured: true,
    isLimitedDrop: false,
    rating: 0,
    reviewsCount: 0,
    tags: ['Graphic Tee', 'Neon', 'Streetwear', 'Made in India'],
    createdAt: '2026-08-05'
  },
  {
    id: 'xol-003',
    sku: 'XOL-MONOLITH-HOODIE',
    name: 'Monolith Raw-Edge Cyberpunk Hoodie',
    slug: 'monolith-raw-edge-cyberpunk-hoodie',
    category: 'STREETWEAR',
    price: 11500,
    discountPrice: 9350,
    images: [
      '/xolara-editorial.png',
      '/product-images/apparel-flatlay.jpg'
    ],
    colors: [
      { name: 'Matte Onyx', hex: '#09090b' },
      { name: 'Dark Bordeaux', hex: '#881337' },
      { name: 'Neon Purple Tint', hex: '#581c87' }
    ],
    sizes: ['S', 'M', 'L', 'XL', '2XL', '3XL'],
    description: 'The definitive luxury heavyweight hoodie. Features an oversized double-layered hood without drawstrings for clean minimalist architecture, tailored drop shoulders, and subtle matte black laser-etched hardware.',
    fabricSpecs: '460 GSM brushed cotton fleece • Thermal lining • Custom XOLARA metal tab at hem',
    stock: 12,
    status: 'Limited Drop',
    isFeatured: true,
    isLimitedDrop: true,
    rating: 0,
    reviewsCount: 0,
    tags: ['Hoodie', '460 GSM', 'Heavyweight', 'Bestseller', 'Made in India'],
    createdAt: '2026-08-10'
  },
  {
    id: 'xol-004',
    sku: 'XOL-CUSTOM-CANVAS-01',
    name: 'Custom Bespoke Archival Graphic T-Shirt',
    slug: 'custom-bespoke-archival-graphic-tee',
    category: 'CUSTOM DESIGNS',
    price: 6400,
    discountPrice: 5000,
    images: [
      '/product-images/folded-tees.jpg',
      '/product-images/black-tee-hanger.jpg'
    ],
    colors: [
      { name: 'Vanta Black', hex: '#050507' },
      { name: 'Crimson Smoke', hex: '#991b1b' },
      { name: 'Ultraviolet', hex: '#4c1d95' },
      { name: 'Pure Chalk', hex: '#f4f4f5' }
    ],
    sizes: ['XS', 'S', 'M', 'L', 'XL', '2XL', '3XL'],
    description: 'Made in India and ready for custom graphics, typography, logos, and personal artwork.',
    fabricSpecs: '280 GSM combed cotton • Smooth surface for printing • Anti-pilling treatment',
    stock: 50,
    status: 'Active',
    isFeatured: true,
    isLimitedDrop: false,
    rating: 0,
    reviewsCount: 0,
    tags: ['Custom Design', 'Bespoke', 'High Density', 'Made in India'],
    createdAt: '2026-08-12'
  },
  {
    id: 'xol-005',
    sku: 'XOL-VANGUARD-ACID-WASH',
    name: 'Vanguard Mineral Acid-Wash Relaxed Tee',
    slug: 'vanguard-mineral-acid-wash-tee',
    category: 'NEW DROPS',
    price: 5950,
    discountPrice: 4950,
    images: [
      '/product-images/graphic-tee-model.jpg',
      '/product-images/black-tee-hanger.jpg'
    ],
    colors: [
      { name: 'Acid Washed Charcoal', hex: '#27272a' },
      { name: 'Distressed Crimson', hex: '#7f1d1d' },
      { name: 'Faded Plum', hex: '#3b0764' }
    ],
    sizes: ['S', 'M', 'L', 'XL', '2XL'],
    description: 'Hand-treated mineral wash gives each individual piece a 1-of-1 vintage texture. Subtle distressed collar detailing and distressed typography that reads "WEAR YOUR IDENTITY".',
    fabricSpecs: '270 GSM Slub Jersey Cotton • Hand-dyed mineral wash finish • Reinforced shoulder-to-shoulder taping',
    stock: 15,
    status: 'Active',
    isFeatured: false,
    isLimitedDrop: true,
    rating: 0,
    reviewsCount: 0,
    tags: ['Acid Wash', 'Vintage', '1 of 1', 'Made in India'],
    createdAt: '2026-08-15'
  },
  {
    id: 'xol-006',
    sku: 'XOL-NIGHTSTALKER-CARGO',
    name: 'Nightstalker Modular Technical Cargo Pants',
    slug: 'nightstalker-modular-technical-cargo',
    category: 'STREETWEAR',
    price: 12350,
    discountPrice: 10650,
    images: [
      '/product-images/trousers-model.jpg',
      '/product-images/apparel-flatlay.jpg'
    ],
    colors: [
      { name: 'Stealth Black', hex: '#0c0c10' },
      { name: 'Crimson Accent Black', hex: '#18181b' }
    ],
    sizes: ['S', 'M', 'L', 'XL'],
    description: 'Engineered for fluid movement. Constructed from water-repellent stretch ripstop with magnetic quick-release cargo compartments and adjustable ankle toggles for customizable stacking.',
    fabricSpecs: 'DWR Coated Technical Cotton-Nylon blend • YKK waterproof zippers • Fidlock compatible magnetic buckles',
    stock: 8,
    status: 'Active',
    isFeatured: true,
    isLimitedDrop: true,
    rating: 0,
    reviewsCount: 0,
    tags: ['Techwear', 'Cargos', 'Water-Repellent', 'Made in India'],
    createdAt: '2026-08-14'
  },
  {
    id: 'xol-007',
    sku: 'XOL-IDENTITY-HEAVY-TEE',
    name: 'Signature "Identity" Back-Graphic Heavy Tee',
    slug: 'signature-identity-back-graphic-heavy-tee',
    category: 'T-SHIRTS',
    price: 5550,
    discountPrice: 4400,
    images: [
      '/product-images/graphic-tee-model.jpg',
      '/product-images/black-tee-hanger.jpg'
    ],
    colors: [
      { name: 'Black Shadow', hex: '#09090c' },
      { name: 'Royal Amethyst', hex: '#581c87' },
      { name: 'Crimson Rush', hex: '#b91c1c' }
    ],
    sizes: ['S', 'M', 'L', 'XL', '2XL'],
    description: 'Minimalist embroidered front logo with a maximalist high-contrast typographical back piece embodying the XOLARA ethos: "WEAR YOUR IDENTITY. BUILT TO STAND OUT."',
    fabricSpecs: '290 GSM 100% Combed Compact Yarn • Puff-print ink + high precision embroidery combo • Preshrunk',
    stock: 22,
    status: 'Active',
    isFeatured: true,
    isLimitedDrop: false,
    rating: 0,
    reviewsCount: 0,
    tags: ['Signature', 'Embroidery', 'Puff Print', 'Made in India'],
    createdAt: '2026-08-16'
  },
  {
    id: 'xol-008',
    sku: 'XOL-VORTEX-OVERSIZED-TEE',
    name: 'Vortex Deep-Violet Oversized Heavy Tee',
    slug: 'vortex-deep-violet-oversized-heavy-tee',
    category: 'OVERSIZED',
    price: 5600,
    discountPrice: 4400,
    images: [
      '/product-images/black-tee-hanger.jpg',
      '/product-images/folded-tees.jpg'
    ],
    colors: [
      { name: 'Deep Violet', hex: '#6d28d9' },
      { name: 'Obsidian Black', hex: '#0b0b10' },
      { name: 'Imperial Crimson', hex: '#dc2626' }
    ],
    sizes: ['XS', 'S', 'M', 'L', 'XL', '2XL'],
    description: 'Cut with broad shoulders and extended sleeves for the ideal boxy drape. Deep purple mineral wash with micro metallic foil accents.',
    fabricSpecs: '280 GSM Luxury Cotton • Metallic foil accents heat-bonded • Enzyme washed for drape and softness',
    stock: 14,
    status: 'Active',
    isFeatured: false,
    isLimitedDrop: false,
    rating: 0,
    reviewsCount: 0,
    tags: ['Oversized', 'Violet', 'Foil Accent', 'Made in India'],
    createdAt: '2026-08-17'
  }
];
