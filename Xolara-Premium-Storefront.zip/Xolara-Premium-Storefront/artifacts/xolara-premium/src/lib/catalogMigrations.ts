import type { CartItem, Order, Product } from '../types';
import { INITIAL_PRODUCTS } from '../data/initialProducts';

const CATALOG_IMAGE_MIGRATION = 'xolara_seed_images_v1';

const LEGACY_SEED_IMAGES: Record<string, string[]> = {
  'xol-001': [
    'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=1000&q=80',
    'https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?auto=format&fit=crop&w=1000&q=80',
    'https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?auto=format&fit=crop&w=1000&q=80',
  ],
  'xol-002': [
    'https://images.unsplash.com/photo-1576566588028-4147f3842f27?auto=format&fit=crop&w=1000&q=80',
    'https://images.unsplash.com/photo-1562157873-818bc0726f68?auto=format&fit=crop&w=1000&q=80',
  ],
  'xol-003': [
    'https://images.unsplash.com/photo-1556905055-8f358a7a47b2?auto=format&fit=crop&w=1000&q=80',
    'https://images.unsplash.com/photo-1509967419530-da38b4704bc6?auto=format&fit=crop&w=1000&q=80',
  ],
  'xol-004': [
    'https://images.unsplash.com/photo-1529374255404-311a2a4f1fd9?auto=format&fit=crop&w=1000&q=80',
    'https://images.unsplash.com/photo-1618354691373-d851c5c3a990?auto=format&fit=crop&w=1000&q=80',
  ],
  'xol-005': [
    'https://images.unsplash.com/photo-1503342394128-c104d54dba01?auto=format&fit=crop&w=1000&q=80',
    'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=1000&q=80',
  ],
  'xol-006': [
    'https://images.unsplash.com/photo-1517445312882-bc9910d016b7?auto=format&fit=crop&w=1000&q=80',
    'https://images.unsplash.com/photo-1552374196-1ab2a1c593e8?auto=format&fit=crop&w=1000&q=80',
  ],
  'xol-007': [
    'https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?auto=format&fit=crop&w=1000&q=80',
    'https://images.unsplash.com/photo-1576566588028-4147f3842f27?auto=format&fit=crop&w=1000&q=80',
  ],
  'xol-008': [
    'https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?auto=format&fit=crop&w=1000&q=80',
    'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=1000&q=80',
  ],
};

const currentSeedImages = new Map(
  INITIAL_PRODUCTS.map((product) => [product.id, product.images]),
);

const replaceUneditedSeedImages = <T extends { id: string; images: string[] }>(
  product: T,
): T => {
  const previousImages = LEGACY_SEED_IMAGES[product.id];
  const updatedImages = currentSeedImages.get(product.id);
  if (
    !previousImages ||
    !updatedImages ||
    !Array.isArray(product.images) ||
    product.images.length !== previousImages.length ||
    product.images.some((image, index) => image !== previousImages[index])
  ) {
    return product;
  }

  return { ...product, images: updatedImages };
};

const migrateCartItemImages = (item: CartItem): CartItem => ({
  ...item,
  product: replaceUneditedSeedImages(item.product),
});

const readStored = <T,>(key: string): T | null => {
  const value = localStorage.getItem(key);
  return value ? (JSON.parse(value) as T) : null;
};

export const migrateLegacySeedImages = (): void => {
  if (typeof window === 'undefined') return;

  try {
    if (localStorage.getItem(CATALOG_IMAGE_MIGRATION) === 'done') return;

    const products = readStored<Product[]>('xolara_products');
    if (products) {
      localStorage.setItem(
        'xolara_products',
        JSON.stringify(products.map(replaceUneditedSeedImages)),
      );
    }

    const cart = readStored<CartItem[]>('xolara_cart');
    if (cart) {
      localStorage.setItem(
        'xolara_cart',
        JSON.stringify(cart.map(migrateCartItemImages)),
      );
    }

    const orders = readStored<Order[]>('xolara_orders');
    if (orders) {
      localStorage.setItem(
        'xolara_orders',
        JSON.stringify(
          orders.map((order) => ({
            ...order,
            items: order.items.map(migrateCartItemImages),
          })),
        ),
      );
    }

    localStorage.setItem(CATALOG_IMAGE_MIGRATION, 'done');
  } catch (error) {
    console.error('Could not refresh the saved Xolara seed images.', error);
  }
};