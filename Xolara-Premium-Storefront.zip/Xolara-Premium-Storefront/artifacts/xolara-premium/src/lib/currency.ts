import type { CartItem, CustomDesignSubmission, Order, Product } from '../types';

const LEGACY_CURRENCY_MIGRATION = 'xolara_currency_migration_inr_v1';
const LEGACY_INR_RATE = 85;

export const formatINR = (amount: number): string =>
  new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0,
  }).format(Number.isFinite(amount) ? amount : 0);

const toINR = (amount: number): number => Math.round(amount * LEGACY_INR_RATE);
const toProductPrice = (amount: number): number =>
  Math.round(toINR(amount) / 50) * 50;

const migrateProduct = (product: Product): Product => ({
  ...product,
  price: toProductPrice(product.price),
  rating: 0,
  reviewsCount: 0,
  discountPrice:
    product.discountPrice === undefined
      ? undefined
      : toProductPrice(product.discountPrice),
  tags: [...new Set([...(product.tags || []), 'Made in India'])],
});

const migrateCartItem = (item: CartItem): CartItem => ({
  ...item,
  product: migrateProduct(item.product),
  customSpecs: item.customSpecs
    ? { ...item.customSpecs, estimatedPrice: toINR(item.customSpecs.estimatedPrice) }
    : undefined,
});

const readStored = <T,>(key: string): T | null => {
  try {
    const value = localStorage.getItem(key);
    return value ? (JSON.parse(value) as T) : null;
  } catch {
    return null;
  }
};

export const migrateLegacyUsdPricesToINR = (): void => {
  if (typeof window === 'undefined') return;

  try {
    if (localStorage.getItem(LEGACY_CURRENCY_MIGRATION) === 'done') return;

    const updates: Array<[string, string]> = [];
    const products = readStored<Product[]>('xolara_products');
    if (products) updates.push(['xolara_products', JSON.stringify(products.map(migrateProduct))]);

    const cart = readStored<CartItem[]>('xolara_cart');
    if (cart) updates.push(['xolara_cart', JSON.stringify(cart.map(migrateCartItem))]);

    const submissions = readStored<CustomDesignSubmission[]>('xolara_custom_submissions');
    if (submissions) {
      updates.push([
        'xolara_custom_submissions',
        JSON.stringify(
          submissions.map((submission) => ({
            ...submission,
            estimatedPrice: toINR(submission.estimatedPrice),
          })),
        ),
      ]);
    }

    const orders = readStored<Order[]>('xolara_orders');
    if (orders) {
      updates.push([
        'xolara_orders',
        JSON.stringify(
          orders.map((order) => ({
            ...order,
            status: String(order.status) === 'Confirmed' ? 'Request Received' : order.status,
            paymentMethod: 'Manual confirmation required',
            items: order.items.map(migrateCartItem),
            subtotal: toINR(order.subtotal),
            discount: toINR(order.discount),
            shipping: toINR(order.shipping),
            tax: toINR(order.tax),
            total: toINR(order.total),
          })),
        ),
      ]);
    }

    updates.forEach(([key, value]) => localStorage.setItem(key, value));
    localStorage.setItem(LEGACY_CURRENCY_MIGRATION, 'done');
  } catch (error) {
    console.error('Could not convert saved Xolara prices to INR.', error);
  }
};