import React from 'react';
import { ArrowUpRight } from 'lucide-react';
import { motion } from 'motion/react';
import { useStore } from '../context/StoreContext';

export const Hero: React.FC = () => {
  const { navigateTo } = useStore();

  return (
    <section
      id="hero-section"
      className="relative isolate flex min-h-[560px] items-center overflow-hidden border-b border-[#34464b]/50"
      style={{ height: 'min(72svh, 680px)' }}
    >
      <div className="absolute inset-0 -z-20 bg-[#0d1016]" />
      <div className="absolute inset-0 -z-10 bg-[url('/xolara-editorial.png')] bg-cover bg-[position:68%_center] opacity-75 mix-blend-screen" />
      <div className="absolute inset-0 -z-10 bg-gradient-to-r from-[#0d1016] via-[#0d1016]/85 via-55% to-[#0d1016]/15" />
      <div className="absolute inset-0 -z-10 bg-gradient-to-t from-[#0d1016]/80 via-transparent to-[#0d1016]/10" />

      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
        className="mx-auto w-full max-w-[1440px] px-6 py-16 sm:px-10 lg:px-16"
      >
        <div className="mb-6 flex items-center gap-3 text-[9px] font-medium uppercase tracking-[.32em] text-[#e89b4c]">
          <span className="h-px w-10 bg-[#e89b4c]" />
          Made in India · The uncommon uniform
        </div>
        <h1 className="max-w-4xl font-heading text-[clamp(3.5rem,9.5vw,8rem)] font-semibold uppercase leading-[.83] tracking-[-.075em] text-[#f3efe5]">
          Wear your
          <br />
          <span className="stroke-text">identity.</span>
        </h1>
        <div className="mt-7 flex max-w-xl flex-col gap-6 sm:flex-row sm:items-center">
          <p className="max-w-xs text-sm leading-6 text-[#c0beb5]">
            India-made streetwear. Heavyweight forms. Made to feel like you.
          </p>
          <div className="flex gap-3">
            <button
              onClick={() => navigateTo('shop')}
              className="group flex items-center gap-4 bg-[#e89b4c] px-5 py-3.5 text-[10px] font-bold uppercase tracking-[.18em] text-[#0d1016] transition-transform hover:-translate-y-0.5"
            >
              Shop the collection
              <ArrowUpRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
            </button>
            <button
              onClick={() => navigateTo('custom-design')}
              className="flex items-center border border-[#b9b9ae]/40 px-5 py-3.5 text-[10px] font-bold uppercase tracking-[.18em] text-[#f3efe5] transition-colors hover:border-[#e89b4c] hover:text-[#e89b4c]"
            >
              Custom studio
            </button>
          </div>
        </div>
      </motion.div>

      <div className="absolute bottom-5 right-6 font-mono text-[8px] uppercase tracking-[.2em] text-[#a3a79f] lg:right-16">
        Small-run · 300 GSM
      </div>
    </section>
  );
};