import React, { useState, useRef } from 'react';
import { useStore } from '../context/StoreContext';
import { Product, ProductCategory, ProductStatus, ProductColor } from '../types';
import { formatINR } from '../lib/currency';
import { 
  Plus, 
  Trash2, 
  Edit3, 
  Upload, 
  Check, 
  Sparkles, 
  Layers, 
  ShieldCheck, 
  Search, 
  Download, 
  RotateCcw, 
  Image as ImageIcon,
  Package,
  FileText,
  User,
  Clock,
  Eye,
  Copy,
  Sliders,
  CheckCircle2,
  X
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

const CATEGORIES: ProductCategory[] = [
  'T-SHIRTS',
  'OVERSIZED',
  'STREETWEAR',
  'CUSTOM DESIGNS',
  'NEW DROPS'
];

const ALL_SIZES = ['XS', 'S', 'M', 'L', 'XL', '2XL', '3XL'] as const;

const compressProductImage = async (file: File): Promise<string> => {
  const bitmap = await createImageBitmap(file);
  const scale = Math.min(1, 1400 / Math.max(bitmap.width, bitmap.height));
  const canvas = document.createElement('canvas');
  canvas.width = Math.max(1, Math.round(bitmap.width * scale));
  canvas.height = Math.max(1, Math.round(bitmap.height * scale));
  const context = canvas.getContext('2d');

  if (!context) {
    bitmap.close();
    throw new Error('Image editor is not available.');
  }

  context.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
  bitmap.close();

  const blob = await new Promise<Blob | null>((resolve) =>
    canvas.toBlob(resolve, 'image/webp', 0.78),
  );
  if (!blob) throw new Error('The selected image could not be processed.');

  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') resolve(reader.result);
      else reject(new Error('The selected image could not be read.'));
    };
    reader.onerror = () => reject(new Error('The selected image could not be read.'));
    reader.readAsDataURL(blob);
  });
};

export const AdminCMS: React.FC = () => {
  const { 
    products, 
    addProduct, 
    updateProduct, 
    deleteProduct, 
    resetToDefaultCatalog,
    customSubmissions,
    updateSubmissionStatus,
    orders,
    addToast,
    navigateTo
  } = useStore();

  const [activeTab, setActiveTab] = useState<'products' | 'custom-requests' | 'orders'>('products');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [catalogSearch, setCatalogSearch] = useState('');

  // Form State for Add / Edit
  const [formName, setFormName] = useState('');
  const [formSku, setFormSku] = useState('');
  const [formCategory, setFormCategory] = useState<ProductCategory>('OVERSIZED');
  const [formPrice, setFormPrice] = useState('65');
  const [formDiscountPrice, setFormDiscountPrice] = useState('');
  const [formDescription, setFormDescription] = useState('');
  const [formFabricSpecs, setFormFabricSpecs] = useState('100% Organic Combed French Terry Cotton • 300 GSM • Pre-shrunk');
  const [formStock, setFormStock] = useState('20');
  const [formStatus, setFormStatus] = useState<ProductStatus>('Active');
  const [formIsFeatured, setFormIsFeatured] = useState(true);
  const [formIsLimitedDrop, setFormIsLimitedDrop] = useState(false);
  const [formSizes, setFormSizes] = useState<('XS' | 'S' | 'M' | 'L' | 'XL' | '2XL' | '3XL')[]>(['S', 'M', 'L', 'XL', '2XL']);
  
  // Images list
  const [formImages, setFormImages] = useState<string[]>([
    '/product-images/black-tee-hanger.jpg'
  ]);
  const [newImageUrl, setNewImageUrl] = useState('');

  // Colors list
  const [formColors, setFormColors] = useState<ProductColor[]>([
    { name: 'Obsidian Black', hex: '#0a0a0f' },
    { name: 'Blood Crimson', hex: '#dc2626' }
  ]);
  const [newColorName, setNewColorName] = useState('');
  const [newColorHex, setNewColorHex] = useState('#6d28d9');

  const fileUploadRef = useRef<HTMLInputElement>(null);

  // Quick SKU generation
  const generateSku = (name: string, category: string) => {
    const prefix = 'XOL';
    const catCode = category.slice(0, 3).toUpperCase();
    const cleanName = name.replace(/[^a-zA-Z0-9]/g, '').slice(0, 4).toUpperCase() || 'PROD';
    const rand = Math.floor(100 + Math.random() * 900);
    return `${prefix}-${catCode}-${cleanName}-${rand}`;
  };

  // Open modal for creating a new product
  const handleOpenAddModal = () => {
    setEditingProduct(null);
    setFormName('');
    setFormSku(generateSku('NewDrop', 'OVERSIZED'));
    setFormCategory('OVERSIZED');
    setFormPrice('68');
    setFormDiscountPrice('54');
    setFormDescription('Engineered with luxury 300+ GSM heavyweight Japanese cotton, oversized boxy drape, and raw distressed XOLARA detailing.');
    setFormFabricSpecs('100% Combed Heavy French Cotton • 300 GSM • Pre-shrunk & Silicone Treated for ultra-soft hand feel');
    setFormStock('25');
    setFormStatus('Active');
    setFormIsFeatured(true);
    setFormIsLimitedDrop(true);
    setFormSizes(['S', 'M', 'L', 'XL', '2XL']);
    setFormImages(['/product-images/black-tee-hanger.jpg']);
    setFormColors([
      { name: 'Obsidian Black', hex: '#0a0a0f' },
      { name: 'Blood Crimson', hex: '#dc2626' }
    ]);
    setIsAddModalOpen(true);
  };

  // Open modal for editing an existing product
  const handleOpenEditModal = (prod: Product) => {
    setEditingProduct(prod);
    setFormName(prod.name);
    setFormSku(prod.sku);
    setFormCategory(prod.category);
    setFormPrice(prod.price.toString());
    setFormDiscountPrice(prod.discountPrice ? prod.discountPrice.toString() : '');
    setFormDescription(prod.description);
    setFormFabricSpecs(prod.fabricSpecs);
    setFormStock(prod.stock.toString());
    setFormStatus(prod.status);
    setFormIsFeatured(!!prod.isFeatured);
    setFormIsLimitedDrop(!!prod.isLimitedDrop);
    setFormSizes([...prod.sizes]);
    setFormImages([...prod.images]);
    setFormColors([...prod.colors]);
    setIsAddModalOpen(true);
  };

  // Image Upload File Handler
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const input = e.currentTarget;
    const files = Array.from(input.files ?? []);
    input.value = '';

    for (const file of files) {
      try {
        const optimizedImage = await compressProductImage(file);
        setFormImages((previous) => [optimizedImage, ...previous]);
        addToast('Photo ready', `${file.name} was optimized for this browser.`, 'success');
      } catch {
        addToast('Photo could not be added', `Check the file format for ${file.name}.`, 'info');
      }
    }
  };

  const handleAddImageUrl = () => {
    if (newImageUrl.trim()) {
      setFormImages(prev => [...prev, newImageUrl.trim()]);
      setNewImageUrl('');
    }
  };

  const handleRemoveImage = (index: number) => {
    setFormImages(prev => prev.filter((_, i) => i !== index));
  };

  const handleAddColor = () => {
    if (newColorName.trim()) {
      setFormColors(prev => [...prev, { name: newColorName.trim(), hex: newColorHex }]);
      setNewColorName('');
    }
  };

  const handleRemoveColor = (index: number) => {
    setFormColors(prev => prev.filter((_, i) => i !== index));
  };

  const handleToggleSize = (size: typeof ALL_SIZES[number]) => {
    setFormSizes(prev => 
      prev.includes(size) ? prev.filter(s => s !== size) : [...prev, size]
    );
  };

  // Save product (Add or Update)
  const handleSaveProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName.trim()) {
      addToast('Name Required', 'Please enter a product name.', 'info');
      return;
    }
    if (formImages.length === 0) {
      addToast('Image Required', 'Please upload or add at least one product image.', 'info');
      return;
    }
    if (formSizes.length === 0) {
      addToast('Size Required', 'Select at least one available size.', 'info');
      return;
    }

    const priceNum = parseFloat(formPrice) || 50;
    const discountNum = formDiscountPrice ? parseFloat(formDiscountPrice) : undefined;
    const stockNum = parseInt(formStock) || 10;
    const slug = formName.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');

    if (editingProduct) {
      updateProduct(editingProduct.id, {
        name: formName,
        sku: formSku || generateSku(formName, formCategory),
        slug,
        category: formCategory,
        price: priceNum,
        discountPrice: discountNum,
        description: formDescription,
        fabricSpecs: formFabricSpecs,
        stock: stockNum,
        status: formStatus,
        isFeatured: formIsFeatured,
        isLimitedDrop: formIsLimitedDrop,
        sizes: formSizes,
        images: formImages,
        colors: formColors,
      });
    } else {
      addProduct({
        name: formName,
        sku: formSku || generateSku(formName, formCategory),
        slug,
        category: formCategory,
        price: priceNum,
        discountPrice: discountNum,
        description: formDescription,
        fabricSpecs: formFabricSpecs,
        stock: stockNum,
        status: formStatus,
        isFeatured: formIsFeatured,
        isLimitedDrop: formIsLimitedDrop,
        sizes: formSizes,
        images: formImages,
        colors: formColors,
        tags: [formCategory, 'New Release']
      });
    }

    setIsAddModalOpen(false);
  };

  // Export JSON Catalog
  const handleExportCatalog = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(products, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `xolara_products_backup_${Date.now()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
    addToast('Catalog Exported', 'JSON backup file downloaded successfully.', 'success');
  };

  // Filter products in CMS list
  const filteredList = products.filter(p =>
    p.name.toLowerCase().includes(catalogSearch.toLowerCase()) ||
    p.sku.toLowerCase().includes(catalogSearch.toLowerCase()) ||
    p.category.toLowerCase().includes(catalogSearch.toLowerCase())
  );

  const totalStockCount = products.reduce((acc, p) => acc + p.stock, 0);
  const totalOrderRequestValue = orders.reduce((acc, o) => acc + o.total, 0);

  return (
    <div className="py-12 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-8">
      
      {/* CMS Header & Identity Badge */}
      <div className="flex flex-col justify-between gap-6 border border-[#34464b] bg-[#11161c] p-6 sm:flex-row sm:items-center sm:p-8">
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <span className="border border-[#e89b4c]/50 bg-[#e89b4c]/10 px-3 py-1 font-mono text-[10px] font-bold uppercase tracking-widest text-[#e89b4c]">
              Xolara store manager
            </span>
          </div>

          <h1 className="font-heading text-3xl font-semibold uppercase tracking-tight text-white sm:text-4xl">
            Manage <span className="text-[#e89b4c]">your products</span>
          </h1>

          <p className="max-w-2xl text-xs leading-5 text-neutral-300 sm:text-sm">
            Change prices, photos, descriptions, stock, sizes, colors and availability. Add products or review orders and custom requests.
          </p>
          <p className="text-[11px] text-[#a7dfd8]">
            Edits are saved in this browser only. Download a catalog backup before changing or resetting your browser data.
          </p>
        </div>

        {/* Primary CMS Actions */}
        <div className="flex flex-wrap items-center gap-3">
          <button
            id="cms-add-product-btn"
            onClick={handleOpenAddModal}
            className="flex items-center gap-2 bg-[#e89b4c] px-5 py-3 font-heading text-xs font-bold uppercase tracking-wider text-[#0d1016] transition-colors hover:bg-[#f4b96f]"
          >
            <Plus className="w-4 h-4" />
            <span>Upload New Product</span>
          </button>

          <button
            onClick={handleExportCatalog}
            className="p-3 rounded-xl bg-white/[0.05] hover:bg-white/[0.1] border border-white/10 text-neutral-300 hover:text-white"
            title="Export Products JSON"
          >
            <Download className="w-4 h-4" />
          </button>

          <button
            onClick={() => {
              if (window.confirm('Restore the original Xolara products? This replaces your current catalog in this browser.')) {
                resetToDefaultCatalog();
              }
            }}
            className="p-3 rounded-xl bg-white/[0.05] hover:bg-red-600/20 border border-white/10 hover:border-red-500/40 text-neutral-300 hover:text-red-400"
            title="Reset to Initial Catalog"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Metrics Strip */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-5 rounded-2xl bg-[#0c0c14] border border-white/[0.08] space-y-1">
          <div className="text-[11px] font-mono text-neutral-400 uppercase">Live Catalog</div>
          <div className="font-heading font-black text-2xl text-white">{products.length} <span className="text-xs font-normal text-neutral-400">Garments</span></div>
        </div>
        <div className="p-5 rounded-2xl bg-[#0c0c14] border border-white/[0.08] space-y-1">
          <div className="text-[11px] font-mono text-neutral-400 uppercase">Total Vault Stock</div>
          <div className="font-heading font-black text-2xl text-red-400">{totalStockCount} <span className="text-xs font-normal text-neutral-400">Units</span></div>
        </div>
        <div className="p-5 rounded-2xl bg-[#0c0c14] border border-white/[0.08] space-y-1">
          <div className="text-[11px] font-mono text-neutral-400 uppercase">Custom Submissions</div>
          <div className="font-heading font-black text-2xl text-purple-400">{customSubmissions.length} <span className="text-xs font-normal text-neutral-400">Inquiries</span></div>
        </div>
        <div className="p-5 rounded-2xl bg-[#0c0c14] border border-white/[0.08] space-y-1">
          <div className="text-[11px] font-mono text-neutral-400 uppercase">Local Request Value</div>
          <div className="font-heading font-black text-2xl text-emerald-400">{formatINR(totalOrderRequestValue)} <span className="text-xs font-normal text-neutral-400">({orders.length} browser-only requests)</span></div>
        </div>
      </div>

      {/* Tabs Switcher */}
      <div className="flex items-center gap-3 border-b border-white/10 pb-4">
        <button
          onClick={() => setActiveTab('products')}
          className={`px-5 py-2.5 rounded-xl text-xs font-bold tracking-wider uppercase transition-all ${
            activeTab === 'products'
              ? 'bg-[#e89b4c] text-[#0d1016] shadow-lg'
              : 'bg-white/[0.04] text-neutral-400 hover:text-white'
          }`}
        >
          Product Catalog ({products.length})
        </button>

        <button
          onClick={() => setActiveTab('custom-requests')}
          className={`px-5 py-2.5 rounded-xl text-xs font-bold tracking-wider uppercase transition-all flex items-center gap-1.5 ${
            activeTab === 'custom-requests'
              ? 'bg-[#e89b4c] text-[#0d1016] shadow-lg'
              : 'bg-white/[0.04] text-neutral-400 hover:text-white'
          }`}
        >
          <span>Bespoke Design Requests</span>
          <span className="w-5 h-5 rounded-full bg-purple-600 text-white text-[10px] flex items-center justify-center font-mono">
            {customSubmissions.length}
          </span>
        </button>

        <button
          onClick={() => setActiveTab('orders')}
          className={`px-5 py-2.5 rounded-xl text-xs font-bold tracking-wider uppercase transition-all flex items-center gap-1.5 ${
            activeTab === 'orders'
              ? 'bg-[#e89b4c] text-[#0d1016] shadow-lg'
              : 'bg-white/[0.04] text-neutral-400 hover:text-white'
          }`}
        >
          <span>Order Requests ({orders.length})</span>
        </button>
      </div>

      {/* Tab 1: Product Catalog Table */}
      {activeTab === 'products' && (
        <div className="space-y-4">
          
          {/* Table Search & Add Button */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 p-4 rounded-2xl bg-[#0c0c14] border border-white/[0.08]">
            <div className="relative w-full sm:w-80">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-400" />
              <input
                type="text"
                placeholder="Filter by title, SKU, or category..."
                value={catalogSearch}
                onChange={(e) => setCatalogSearch(e.target.value)}
                className="w-full bg-[#141422] border border-white/10 rounded-xl pl-10 pr-4 py-2 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-red-500"
              />
            </div>

            <span className="text-xs font-mono text-neutral-400">
              Showing {filteredList.length} of {products.length} catalog items
            </span>
          </div>

          {/* Table */}
          <div className="rounded-2xl bg-[#0c0c14] border border-white/[0.08] overflow-hidden overflow-x-auto">
            <table className="w-full text-left text-xs font-mono border-collapse">
              <thead>
                <tr className="bg-[#12121e] border-b border-white/10 text-neutral-400 uppercase text-[10px] tracking-wider">
                  <th className="py-3.5 px-4">Garment</th>
                  <th className="py-3.5 px-4">SKU / Code</th>
                  <th className="py-3.5 px-4">Category</th>
                  <th className="py-3.5 px-4">Price</th>
                  <th className="py-3.5 px-4">Stock</th>
                  <th className="py-3.5 px-4">Status</th>
                  <th className="py-3.5 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5 text-neutral-300">
                {filteredList.map((product) => (
                  <tr key={product.id} className="hover:bg-white/[0.02] transition-colors">
                    {/* Image & Title */}
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-3">
                        <img
                          src={product.images[0]}
                          alt={product.name}
                          className="w-12 h-12 rounded-lg object-cover bg-[#141420] border border-white/10"
                        />
                        <div>
                          <div className="font-bold text-white font-heading text-sm line-clamp-1">
                            {product.name}
                          </div>
                          <div className="text-[10px] text-neutral-400">
                            {product.colors.map(c => c.name).join(', ')}
                          </div>
                        </div>
                      </div>
                    </td>

                    {/* SKU */}
                    <td className="py-3 px-4 font-mono text-neutral-300">
                      {product.sku}
                    </td>

                    {/* Category */}
                    <td className="py-3 px-4">
                      <span className="px-2.5 py-1 rounded bg-white/[0.05] border border-white/10 text-[10px] font-bold text-neutral-200">
                        {product.category}
                      </span>
                    </td>

                    {/* Price */}
                    <td className="py-3 px-4">
                      <div className="font-bold text-white">
                        {formatINR(product.discountPrice || product.price)}
                      </div>
                      {product.discountPrice && (
                        <div className="text-[10px] text-neutral-500 line-through">
                          {formatINR(product.price)}
                        </div>
                      )}
                    </td>

                    {/* Stock */}
                    <td className="py-3 px-4">
                      <span className={`px-2 py-0.5 rounded font-bold ${
                        product.stock <= 5 ? 'bg-red-950 text-red-400 border border-red-500/30' : 'bg-emerald-950/60 text-emerald-400'
                      }`}>
                        {product.stock} in stock
                      </span>
                    </td>

                    {/* Status */}
                    <td className="py-3 px-4">
                      <span className={`px-2 py-0.5 rounded text-[10px] uppercase font-bold ${
                        product.status === 'Active'
                          ? 'bg-purple-950 text-purple-300 border border-purple-500/30'
                          : product.status === 'Limited Drop'
                          ? 'bg-red-950 text-red-300 border border-red-500/40'
                          : 'bg-neutral-800 text-neutral-400'
                      }`}>
                        {product.status}
                      </span>
                    </td>

                    {/* Actions */}
                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <button
                          onClick={() => navigateTo('product-detail', product)}
                          className="p-2 rounded-lg bg-white/[0.05] hover:bg-white/[0.1] text-neutral-300 hover:text-white"
                          title="View Live Product Page"
                        >
                          <Eye className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleOpenEditModal(product)}
                          className="p-2 rounded-lg bg-purple-950/60 hover:bg-purple-900 border border-purple-500/30 text-purple-300"
                          title="Edit Product Details"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => {
                            if (window.confirm(`Delete ${product.name}?`)) {
                              deleteProduct(product.id);
                            }
                          }}
                          className="p-2 rounded-lg bg-red-950/60 hover:bg-red-900 border border-red-500/30 text-red-300"
                          title="Delete Product"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab 2: Custom Inquiries Tracker */}
      {activeTab === 'custom-requests' && (
        <div className="space-y-4">
          <div className="p-4 rounded-2xl bg-[#0c0c14] border border-white/[0.08] flex items-center justify-between">
            <h3 className="font-heading font-bold text-white text-base">
              Bespoke Custom T-Shirt Design Submissions
            </h3>
            <span className="text-xs font-mono text-neutral-400">{customSubmissions.length} active leads</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {customSubmissions.map((sub) => (
              <div
                key={sub.id}
                className="p-6 rounded-2xl bg-[#0c0c14] border border-white/[0.08] hover:border-purple-500/40 space-y-4 transition-all"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-0.5 rounded bg-purple-950 text-purple-300 font-mono text-xs font-bold border border-purple-500/30">
                      ID: {sub.id}
                    </span>
                    <span className="text-xs text-neutral-400">{sub.createdAt}</span>
                  </div>

                  <select
                    value={sub.status}
                    onChange={(e) => updateSubmissionStatus(sub.id, e.target.value as any)}
                    className="bg-[#141422] border border-white/10 text-white text-xs rounded-lg px-2.5 py-1 focus:outline-none focus:border-red-500 font-mono"
                  >
                    <option value="Received">Received</option>
                    <option value="In Review">In Review</option>
                    <option value="Sample Approved">Sample Approved</option>
                    <option value="In Production">In Production</option>
                    <option value="Completed">Completed</option>
                  </select>
                </div>

                {/* Customer Contact */}
                <div className="space-y-1 text-xs">
                  <div className="font-bold text-white text-sm">{sub.customerName}</div>
                  <div className="text-neutral-400 font-mono">Email: <a href={`mailto:${sub.customerEmail}`} className="text-red-400 underline">{sub.customerEmail}</a></div>
                  <div className="text-neutral-400 font-mono">Phone: {sub.customerPhone}</div>
                </div>

                {/* Garment Details & Image */}
                <div className="p-3.5 rounded-xl bg-[#131320] border border-white/5 flex gap-4 text-xs font-mono">
                  {sub.designImage ? (
                    <img src={sub.designImage} alt="Design preview" className="w-16 h-16 rounded-lg object-contain bg-black p-1 border border-white/10" />
                  ) : (
                    <div className="w-16 h-16 rounded-lg bg-black/40 border border-white/10 flex items-center justify-center text-neutral-500 text-[10px] text-center">
                      No File
                    </div>
                  )}

                  <div className="space-y-1">
                    <div className="text-white font-bold">{sub.productType}</div>
                    <div className="text-neutral-400">Color: {sub.colorName} • Size: {sub.size} • Qty: {sub.quantity}</div>
                    <div className="text-neutral-400">Placement: {sub.position}</div>
                    {sub.customText && <div className="text-purple-300 font-bold">Text: "{sub.customText}"</div>}
                  </div>
                </div>

                <div className="text-xs text-neutral-300 bg-[#090910] p-3 rounded-xl border border-white/5">
                  <strong className="text-neutral-400 block mb-0.5">Special Instructions:</strong>
                  {sub.specialInstructions}
                </div>

                <div className="flex items-center justify-between text-xs font-mono pt-2 border-t border-white/5">
                  <span className="text-neutral-400">Estimated Total: <strong className="text-white">{formatINR(sub.estimatedPrice)}</strong></span>
                  <a
                    href={`mailto:${sub.customerEmail}?subject=XOLARA%20PREMIUM%20-%20Your%20Custom%20Design%20Proof%20(${sub.id})`}
                    className="px-3 py-1.5 rounded-lg bg-gradient-to-r from-red-600 to-purple-600 text-white font-bold uppercase text-[10px]"
                  >
                    Reply to Client
                  </a>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 3: Orders Log */}
      {activeTab === 'orders' && (
        <div className="space-y-4">
          <div className="p-4 rounded-2xl bg-[#0c0c14] border border-white/[0.08] flex items-center justify-between">
            <h3 className="font-heading font-bold text-white text-base">Local Order Requests</h3>
            <span className="text-xs font-mono text-neutral-400">{orders.length} browser-only requests</span>
          </div>

          {orders.length === 0 ? (
            <div className="py-16 text-center rounded-2xl bg-[#0c0c14] border border-white/[0.08] text-neutral-400">
              <Package className="w-8 h-8 mx-auto mb-2 text-neutral-500" />
              <p>No order requests saved in this browser yet.</p>
            </div>
          ) : (
            <div className="space-y-4">
              {orders.map((ord) => (
                <div key={ord.id} className="p-6 rounded-2xl bg-[#0c0c14] border border-white/[0.08] space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="font-mono text-sm font-bold text-white">{ord.orderNumber}</span>
                      <span className="text-xs text-neutral-500 ml-3">{new Date(ord.createdAt).toLocaleDateString()}</span>
                    </div>
                    <span className="px-3 py-1 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-500/30 text-xs font-mono font-bold">
                      {ord.status}
                    </span>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-mono">
                    <div className="p-3 rounded-xl bg-[#131320] border border-white/5 space-y-1">
                      <strong className="text-white block uppercase">Customer Details</strong>
                      <div>{ord.customer.fullName} ({ord.customer.email})</div>
                      <div>{ord.customer.phone}</div>
                      <div>{ord.customer.address}, {ord.customer.city}, {ord.customer.state} {ord.customer.zipCode}</div>
                    </div>

                    <div className="p-3 rounded-xl bg-[#131320] border border-white/5 space-y-1">
                      <strong className="text-white block uppercase">Financial Breakdown</strong>
                      <div>Payment: {ord.paymentMethod}</div>
                      <div>Subtotal: {formatINR(ord.subtotal)} | Discount: -{formatINR(ord.discount)}</div>
                      <div className="text-white font-bold text-sm">Product estimate: {formatINR(ord.total)}</div>
                      <div>Delivery and applicable tax are not included.</div>
                    </div>
                  </div>

                  {/* Items list */}
                  <div className="space-y-2 pt-2 border-t border-white/5">
                    <span className="text-[11px] font-mono text-neutral-400 uppercase block">Items ({ord.items.length}):</span>
                    {ord.items.map((item, idx) => (
                      <div key={idx} className="flex items-center justify-between text-xs font-mono text-neutral-300">
                        <span>{item.quantity}x {item.product.name} ({item.selectedSize} / {item.selectedColor.name})</span>
                        <span className="font-bold text-white">{formatINR((item.product.discountPrice || item.product.price) * item.quantity)}</span>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ADD / EDIT PRODUCT MODAL */}
      <AnimatePresence>
        {isAddModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md overflow-y-auto">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="w-full max-w-3xl my-8 bg-[#0e0e18] border border-white/15 rounded-3xl p-6 sm:p-8 space-y-6 shadow-[0_0_50px_rgba(0,0,0,0.9)] max-h-[90vh] overflow-y-auto"
            >
              <div className="flex items-center justify-between pb-4 border-b border-white/10">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-lg bg-red-600/20 border border-red-500/40 flex items-center justify-center text-red-400">
                    <Plus className="w-4 h-4" />
                  </div>
                  <h3 className="font-heading font-bold text-xl text-white">
                    {editingProduct ? 'Edit Product Specifications' : 'Upload New XOLARA Garment'}
                  </h3>
                </div>

                <button
                  onClick={() => setIsAddModalOpen(false)}
                  className="w-8 h-8 rounded-lg bg-white/5 hover:bg-white/10 text-neutral-400 hover:text-white flex items-center justify-center"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <form onSubmit={handleSaveProduct} className="space-y-6">
                
                {/* Product Name & SKU */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-mono text-neutral-300 font-bold uppercase mb-1.5">
                      Product Name *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Acid Crimson Drop-Shoulder Tee"
                      value={formName}
                      onChange={(e) => setFormName(e.target.value)}
                      className="w-full bg-[#141422] border border-white/10 rounded-xl px-4 py-2.5 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-red-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-mono text-neutral-300 font-bold uppercase mb-1.5">
                      SKU Code
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. XOL-OVER-CRIM-01"
                      value={formSku}
                      onChange={(e) => setFormSku(e.target.value)}
                      className="w-full bg-[#141422] border border-white/10 rounded-xl px-4 py-2.5 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-purple-500"
                    />
                  </div>
                </div>

                {/* Category & Status */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-mono text-neutral-300 font-bold uppercase mb-1.5">
                      Category *
                    </label>
                    <select
                      value={formCategory}
                      onChange={(e) => setFormCategory(e.target.value as any)}
                      className="w-full bg-[#141422] border border-white/10 text-white text-xs rounded-xl p-3 focus:outline-none focus:border-red-500"
                    >
                      {CATEGORIES.map(cat => (
                        <option key={cat} value={cat}>{cat}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-mono text-neutral-300 font-bold uppercase mb-1.5">
                      Product Status
                    </label>
                    <select
                      value={formStatus}
                      onChange={(e) => setFormStatus(e.target.value as any)}
                      className="w-full bg-[#141422] border border-white/10 text-white text-xs rounded-xl p-3 focus:outline-none focus:border-purple-500"
                    >
                      <option value="Active">Active (Available in Shop)</option>
                      <option value="Limited Drop">Limited Drop (Capsule badge)</option>
                      <option value="Draft">Draft (Hidden)</option>
                      <option value="Sold Out">Sold Out</option>
                    </select>
                  </div>
                </div>

                {/* Pricing & Stock */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs font-mono text-neutral-300 font-bold uppercase mb-1.5">
                      Regular Price (INR ₹) *
                    </label>
                    <input
                      type="number"
                      required
                      min="1"
                      step="1"
                      placeholder="5800"
                      value={formPrice}
                      onChange={(e) => setFormPrice(e.target.value)}
                      className="w-full bg-[#141422] border border-white/10 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none focus:border-red-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-mono text-neutral-300 font-bold uppercase mb-1.5">
                      Discount Price (INR ₹) (Optional)
                    </label>
                    <input
                      type="number"
                      min="1"
                      step="1"
                      placeholder="4600"
                      value={formDiscountPrice}
                      onChange={(e) => setFormDiscountPrice(e.target.value)}
                      className="w-full bg-[#141422] border border-white/10 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none focus:border-purple-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-mono text-neutral-300 font-bold uppercase mb-1.5">
                      Stock Quantity
                    </label>
                    <input
                      type="number"
                      min="0"
                      value={formStock}
                      onChange={(e) => setFormStock(e.target.value)}
                      className="w-full bg-[#141422] border border-white/10 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none focus:border-red-500"
                    />
                  </div>
                </div>

                {/* Multiple Images Upload System */}
                <div className="space-y-3 p-4 rounded-2xl bg-[#12121e] border border-white/5">
                    <label className="block text-xs font-mono font-bold uppercase text-neutral-300">
                     Product photos (upload or paste a URL) *
                  </label>
                   <p className="text-[11px] text-neutral-400">
                     Uploaded images are resized and saved with this browser's product catalog.
                   </p>

                  <div className="flex flex-wrap items-center gap-3">
                    <input
                      ref={fileUploadRef}
                      type="file"
                      multiple
                      accept="image/*"
                      onChange={handleFileUpload}
                      className="hidden"
                    />
                    <button
                      type="button"
                      onClick={() => fileUploadRef.current?.click()}
                      className="px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 border border-white/10 text-white text-xs font-bold flex items-center gap-2"
                    >
                      <Upload className="w-3.5 h-3.5 text-red-400" />
                      <span>Upload Files from Device</span>
                    </button>

                    <div className="flex-1 flex gap-2 min-w-[240px]">
                      <input
                        type="url"
                        placeholder="Or paste web image URL..."
                        value={newImageUrl}
                        onChange={(e) => setNewImageUrl(e.target.value)}
                        className="flex-1 bg-[#181828] border border-white/10 rounded-xl px-3 py-2 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-purple-500"
                      />
                      <button
                        type="button"
                        onClick={handleAddImageUrl}
                        className="px-3 py-2 rounded-xl bg-purple-600 text-white text-xs font-bold"
                      >
                        Add URL
                      </button>
                    </div>
                  </div>

                  {/* Thumbnail gallery */}
                  <div className="flex flex-wrap gap-3 pt-2">
                    {formImages.map((img, idx) => (
                      <div key={idx} className="relative w-20 h-20 rounded-xl overflow-hidden border border-white/20 group">
                        <img src={img} alt={`Preview ${idx}`} className="w-full h-full object-cover" />
                        <button
                          type="button"
                          onClick={() => handleRemoveImage(idx)}
                          className="absolute top-1 right-1 w-5 h-5 rounded-full bg-red-600 text-white flex items-center justify-center text-[10px] opacity-0 group-hover:opacity-100 transition-opacity"
                        >
                          ✕
                        </button>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Available Sizes Checklist */}
                <div className="space-y-2">
                  <label className="block text-xs font-mono text-neutral-300 font-bold uppercase">
                    Available Sizes *
                  </label>
                  <div className="flex flex-wrap gap-2">
                    {ALL_SIZES.map(sz => {
                      const isSelected = formSizes.includes(sz);
                      return (
                        <button
                          key={sz}
                          type="button"
                          onClick={() => handleToggleSize(sz)}
                          className={`px-4 py-2 rounded-xl text-xs font-mono font-bold transition-all ${
                            isSelected
                              ? 'bg-gradient-to-r from-red-600 to-purple-600 text-white shadow-md'
                              : 'bg-[#141422] text-neutral-400 border border-white/5'
                          }`}
                        >
                          {sz}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Available Colors Manager */}
                <div className="space-y-3 p-4 rounded-2xl bg-[#12121e] border border-white/5">
                  <label className="block text-xs font-mono text-neutral-300 font-bold uppercase">
                    Color Variants
                  </label>

                  <div className="flex flex-wrap gap-2 items-center">
                    {formColors.map((col, idx) => (
                      <span
                        key={idx}
                        className="inline-flex items-center gap-2 px-3 py-1.5 rounded-xl bg-[#181828] border border-white/10 text-xs font-mono text-white"
                      >
                        <span className="w-3 h-3 rounded-full border border-white/40" style={{ backgroundColor: col.hex }} />
                        <span>{col.name}</span>
                        <button
                          type="button"
                          onClick={() => handleRemoveColor(idx)}
                          className="text-neutral-500 hover:text-red-400 ml-1 font-bold"
                        >
                          ✕
                        </button>
                      </span>
                    ))}
                  </div>

                  <div className="flex items-center gap-2 pt-1">
                    <input
                      type="text"
                      placeholder="Color Name (e.g. Acid Red)"
                      value={newColorName}
                      onChange={(e) => setNewColorName(e.target.value)}
                      className="bg-[#181828] border border-white/10 rounded-xl px-3 py-2 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-red-500"
                    />
                    <input
                      type="color"
                      value={newColorHex}
                      onChange={(e) => setNewColorHex(e.target.value)}
                      className="w-10 h-9 rounded-xl bg-transparent cursor-pointer border border-white/10 p-0.5"
                    />
                    <button
                      type="button"
                      onClick={handleAddColor}
                      className="px-3 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-bold"
                    >
                      + Add Color
                    </button>
                  </div>
                </div>

                {/* Description & Fabric Specs */}
                <div className="space-y-4">
                  <div>
                    <label className="block text-xs font-mono text-neutral-300 font-bold uppercase mb-1.5">
                      Description
                    </label>
                    <textarea
                      rows={2}
                      value={formDescription}
                      onChange={(e) => setFormDescription(e.target.value)}
                      className="w-full bg-[#141422] border border-white/10 rounded-xl p-3 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-red-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-mono text-neutral-300 font-bold uppercase mb-1.5">
                      Fabric & Textile Specs
                    </label>
                    <input
                      type="text"
                      value={formFabricSpecs}
                      onChange={(e) => setFormFabricSpecs(e.target.value)}
                      className="w-full bg-[#141422] border border-white/10 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none focus:border-purple-500"
                    />
                  </div>
                </div>

                {/* Feature Toggles */}
                <div className="flex items-center gap-6 text-xs font-mono text-neutral-300">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={formIsFeatured}
                      onChange={(e) => setFormIsFeatured(e.target.checked)}
                      className="accent-red-600 rounded"
                    />
                    <span>Feature on Drop Carousel</span>
                  </label>

                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={formIsLimitedDrop}
                      onChange={(e) => setFormIsLimitedDrop(e.target.checked)}
                      className="accent-purple-600 rounded"
                    />
                    <span>Limited Drop Edition</span>
                  </label>
                </div>

                {/* Submit Action */}
                <div className="flex items-center justify-end gap-3 pt-4 border-t border-white/10">
                  <button
                    type="button"
                    onClick={() => setIsAddModalOpen(false)}
                    className="px-5 py-3 rounded-xl bg-white/5 hover:bg-white/10 text-neutral-300 text-xs font-bold uppercase"
                  >
                    Cancel
                  </button>

                  <button
                    type="submit"
                    className="px-8 py-3 rounded-xl bg-gradient-to-r from-red-600 via-rose-600 to-purple-600 text-white font-heading font-bold text-xs tracking-wider uppercase shadow-[0_0_25px_rgba(225,29,72,0.4)]"
                  >
                    {editingProduct ? 'Save Changes' : 'Publish to Catalog'}
                  </button>
                </div>

              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
};
