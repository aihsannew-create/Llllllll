import React, { useState } from 'react';
import { useStore } from '../context/StoreContext';
import { 
  X, 
  Trash2, 
  ShoppingBag, 
  ArrowRight, 
  Tag
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { formatINR } from '../lib/currency';

export const CartDrawer: React.FC = () => {
  const { 
    isCartOpen, 
    setIsCartOpen, 
    cart, 
    removeFromCart, 
    updateQuantity, 
    cartCount,
    cartSubtotal,
    cartDiscount,
    cartTotal,
    appliedPromo,
    applyPromoCode,
    removePromoCode,
    setIsCheckoutOpen,
    navigateTo
  } = useStore();

  const [promoInput, setPromoInput] = useState('');
  const [promoError, setPromoError] = useState('');

  const handleApplyPromo = (e: React.FormEvent) => {
    e.preventDefault();
    if (!promoInput.trim()) return;
    const res = applyPromoCode(promoInput);
    if (!res.success) {
      setPromoError(res.message);
    } else {
      setPromoError('');
      setPromoInput('');
    }
  };

  const handleProceedToCheckout = () => {
    setIsCartOpen(false);
    setIsCheckoutOpen(true);
  };

  return (
    <AnimatePresence>
      {isCartOpen && (
        <div className="fixed inset-0 z-50 overflow-hidden">
          
          {/* Backdrop Overlay */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setIsCartOpen(false)}
            className="absolute inset-0 bg-black/80 backdrop-blur-sm transition-opacity"
          />

          <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
            <motion.div
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 30, stiffness: 300 }}
              className="w-screen max-w-md bg-[#0b0b14] border-l border-white/10 flex flex-col justify-between shadow-[0_0_60px_rgba(0,0,0,0.9)]"
            >
              
              {/* Header */}
              <div className="p-6 border-b border-white/[0.08] flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-lg bg-red-600/20 border border-red-500/40 flex items-center justify-center text-red-400">
                    <ShoppingBag className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="font-heading font-black text-lg text-white uppercase tracking-wider">
                      Shopping Bag
                    </h3>
                    <span className="text-[11px] font-mono text-neutral-400">
                      {cartCount} {cartCount === 1 ? 'Garment' : 'Garments'} Selected
                    </span>
                  </div>
                </div>

                <button
                  id="cart-drawer-close-btn"
                  onClick={() => setIsCartOpen(false)}
                  className="w-9 h-9 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] border border-white/10 flex items-center justify-center text-neutral-400 hover:text-white"
                  aria-label="Close cart"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Cart Items List Area */}
              <div className="flex-1 overflow-y-auto p-6 space-y-4">
                {cart.length === 0 ? (
                  <div className="py-20 text-center space-y-4">
                    <div className="w-16 h-16 rounded-full bg-white/[0.04] border border-white/10 flex items-center justify-center mx-auto text-neutral-500">
                      <ShoppingBag className="w-7 h-7" />
                    </div>
                    <div className="space-y-1">
                      <h4 className="font-heading font-bold text-white text-base">Your Bag Is Empty</h4>
                      <p className="text-xs text-neutral-400 max-w-xs mx-auto">
                        Explore our latest heavyweight limited drops or create a bespoke custom piece.
                      </p>
                    </div>
                    <button
                      onClick={() => {
                        setIsCartOpen(false);
                        navigateTo('shop');
                      }}
                      className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-red-600 to-purple-600 text-white text-xs font-bold tracking-wider uppercase shadow-[0_0_15px_rgba(225,29,72,0.3)]"
                    >
                      Shop Now
                    </button>
                  </div>
                ) : (
                  cart.map((item) => {
                    const unitPrice = item.product.discountPrice || item.product.price;
                    return (
                      <div
                        key={item.id}
                        className="p-4 rounded-2xl bg-[#0e0e18] border border-white/[0.06] flex gap-4 relative group"
                      >
                        {/* Thumbnail */}
                        <div className="w-20 h-24 rounded-xl overflow-hidden bg-[#141422] flex-shrink-0 border border-white/5">
                          <img
                            src={item.customSpecs?.designImage || item.product.images[0]}
                            alt={item.product.name}
                            className="w-full h-full object-cover"
                          />
                        </div>

                        {/* Details */}
                        <div className="flex-1 flex flex-col justify-between">
                          <div>
                            <div className="flex items-start justify-between gap-2">
                              <h4 className="font-heading font-bold text-sm text-white line-clamp-1">
                                {item.product.name}
                              </h4>
                              <button
                                onClick={() => removeFromCart(item.id)}
                                className="text-neutral-500 hover:text-red-400 p-1"
                                title="Remove item"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>

                            <div className="text-[11px] font-mono text-neutral-400 space-y-0.5 mt-0.5">
                              <div>Size: <strong className="text-white">{item.selectedSize}</strong> • Color: <strong className="text-white">{item.selectedColor.name}</strong></div>
                              {item.customSpecs && (
                                <div className="text-purple-300 font-semibold">Custom Bespoke Atelier Spec</div>
                              )}
                            </div>
                          </div>

                          {/* Quantity & Item Subtotal */}
                          <div className="flex items-center justify-between pt-2">
                            <div className="flex items-center gap-2 bg-[#141422] border border-white/10 rounded-lg p-0.5">
                              <button
                                onClick={() => updateQuantity(item.id, item.quantity - 1)}
                                className="w-6 h-6 text-xs text-white hover:bg-white/10 rounded flex items-center justify-center font-bold"
                              >
                                -
                              </button>
                              <span className="w-6 text-center text-xs font-mono font-bold text-white">
                                {item.quantity}
                              </span>
                              <button
                                onClick={() => updateQuantity(item.id, item.quantity + 1)}
                                className="w-6 h-6 text-xs text-white hover:bg-white/10 rounded flex items-center justify-center font-bold"
                              >
                                +
                              </button>
                            </div>

                            <span className="font-heading font-bold text-sm text-white font-mono">
                              {formatINR(unitPrice * item.quantity)}
                            </span>
                          </div>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>

              {/* Footer Summary & Checkout Button */}
              {cart.length > 0 && (
                <div className="p-6 border-t border-white/[0.08] bg-[#0c0c14] space-y-4">
                  
                  {/* Promo Code Input */}
                  <div>
                    {appliedPromo ? (
                      <div className="flex items-center justify-between p-2.5 rounded-xl bg-purple-950/60 border border-purple-500/40 text-xs font-mono">
                        <span className="flex items-center gap-1.5 text-purple-300">
                          <Tag className="w-3.5 h-3.5 text-purple-400" />
                          <span>Code <strong>{appliedPromo.code}</strong> (-{appliedPromo.discountPercentage}%)</span>
                        </span>
                        <button
                          onClick={removePromoCode}
                          className="text-red-400 hover:text-red-300 font-bold"
                        >
                          Remove
                        </button>
                      </div>
                    ) : (
                      <form onSubmit={handleApplyPromo} className="flex gap-2">
                        <input
                          type="text"
                          placeholder="Promo code (e.g. XOLARA10)"
                          value={promoInput}
                          onChange={(e) => setPromoInput(e.target.value)}
                          className="flex-1 bg-[#141422] border border-white/10 rounded-xl px-3 py-2 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-red-500 uppercase font-mono"
                        />
                        <button
                          type="submit"
                          className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-bold uppercase font-mono"
                        >
                          Apply
                        </button>
                      </form>
                    )}
                    {promoError && (
                      <p className="text-[11px] text-red-400 font-mono mt-1">{promoError}</p>
                    )}
                  </div>

                  {/* Calculations */}
                  <div className="space-y-1.5 text-xs font-mono">
                    <div className="flex justify-between text-neutral-400">
                      <span>Subtotal</span>
                      <span className="text-white">{formatINR(cartSubtotal)}</span>
                    </div>

                    {cartDiscount > 0 && (
                      <div className="flex justify-between text-purple-400">
                        <span>VIP Privilege Discount</span>
                        <span>-{formatINR(cartDiscount)}</span>
                      </div>
                    )}

                    <div className="flex justify-between text-neutral-400">
                      <span>Delivery</span>
                      <span className="text-neutral-300">Confirmed manually</span>
                    </div>

                    <div className="flex justify-between text-neutral-400">
                      <span>Tax</span>
                      <span className="text-neutral-300">Confirmed manually</span>
                    </div>

                    <div className="pt-2 border-t border-white/10 flex justify-between text-base font-bold text-white font-mono">
                      <span>Product estimate</span>
                      <span className="font-black text-lg text-transparent bg-clip-text bg-gradient-to-r from-red-400 to-purple-400">
                        {formatINR(cartTotal)}
                      </span>
                    </div>
                    <p className="pt-1 text-[10px] leading-4 text-neutral-500">
                      Excludes delivery and any applicable tax. This preview does not process payment or arrange shipping automatically.
                    </p>
                  </div>

                  {/* Checkout CTA */}
                  <button
                    id="cart-proceed-checkout-btn"
                    onClick={handleProceedToCheckout}
                    className="w-full py-4 rounded-xl bg-gradient-to-r from-red-600 via-rose-600 to-purple-600 hover:from-red-500 hover:to-purple-500 text-white font-heading font-bold text-xs tracking-[0.18em] uppercase flex items-center justify-center gap-2 shadow-[0_0_25px_rgba(225,29,72,0.4)] transition-all"
                  >
                    <span>Proceed to Checkout</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>

                </div>
              )}

            </motion.div>
          </div>
        </div>
      )}
    </AnimatePresence>
  );
};
