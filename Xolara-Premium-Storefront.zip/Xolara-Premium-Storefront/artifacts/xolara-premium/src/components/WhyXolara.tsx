import React from 'react';
import { ShieldCheck, Sparkles, HeartHandshake, Crown, Flame } from 'lucide-react';
import { motion } from 'motion/react';

const FEATURES = [
  {
    icon: ShieldCheck,
    title: 'PREMIUM QUALITY',
    desc: 'India-made garments with product-specific fabric and print details listed on each product page.',
    color: 'from-red-500/20 to-rose-600/10',
    border: 'border-red-500/30',
    iconColor: 'text-red-400'
  },
  {
    icon: Sparkles,
    title: 'ORIGINAL DESIGNS',
    desc: 'Original streetwear graphics and small-run designs, created and made in India.',
    color: 'from-purple-500/20 to-violet-600/10',
    border: 'border-purple-500/30',
    iconColor: 'text-purple-400'
  },
  {
    icon: HeartHandshake,
    title: 'MADE WITH PASSION',
    desc: 'Made in India. Each product page lists its available colours, sizes, materials and care details.',
    color: 'from-rose-500/20 to-red-600/10',
    border: 'border-rose-500/30',
    iconColor: 'text-rose-400'
  },
  {
    icon: Crown,
    title: 'DIRECT ORDER REQUESTS',
    desc: 'Prices are shown in Indian rupees. Delivery charges and timing are confirmed manually; no dropshipping or automatic fulfilment is connected.',
    color: 'from-violet-500/20 to-purple-600/10',
    border: 'border-violet-500/30',
    iconColor: 'text-violet-400'
  }
];

export const WhyXolara: React.FC = () => {
  return (
    <section 
      id="why-xolara-section" 
      className="py-24 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto relative overflow-hidden"
    >
      {/* Background glow flares */}
      <div className="absolute top-1/2 left-1/4 -translate-y-1/2 w-80 h-80 bg-red-600/10 rounded-full blur-[100px] pointer-events-none" />
      <div className="absolute top-1/2 right-1/4 -translate-y-1/2 w-80 h-80 bg-purple-600/10 rounded-full blur-[100px] pointer-events-none" />

      {/* Section Header */}
      <div className="text-center max-w-2xl mx-auto mb-16 space-y-3">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/[0.04] border border-white/10 text-neutral-300 text-xs font-mono font-bold tracking-[0.2em] uppercase">
          <Flame className="w-3.5 h-3.5 text-red-500" />
          <span>THE FOUNDATIONAL PILLARS</span>
        </div>
        
        <h2 className="font-heading font-black text-3xl sm:text-5xl text-white uppercase tracking-tight">
          WHY <span className="text-transparent bg-clip-text bg-gradient-to-r from-red-500 to-purple-500">XOLARA</span>
        </h2>
        
        <p className="text-neutral-400 text-sm sm:text-base">
          Setting the benchmark for contemporary luxury streetwear and bespoke craftsmanship.
        </p>
      </div>

      {/* 4 Feature Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {FEATURES.map((item, index) => {
          const IconComponent = item.icon;
          return (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1, duration: 0.5 }}
              className={`p-7 rounded-3xl bg-[#0c0c14] border ${item.border} hover:scale-[1.02] hover:shadow-[0_0_30px_rgba(225,29,72,0.2)] transition-all duration-300 flex flex-col justify-between space-y-6 group`}
            >
              <div className="space-y-4">
                <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${item.color} border border-white/10 flex items-center justify-center shadow-md group-hover:scale-110 transition-transform`}>
                  <IconComponent className={`w-7 h-7 ${item.iconColor}`} />
                </div>

                <h3 className="font-heading font-extrabold text-lg text-white tracking-wide group-hover:text-red-400 transition-colors">
                  {item.title}
                </h3>

                <p className="text-neutral-300 text-xs leading-relaxed">
                  {item.desc}
                </p>
              </div>

              <div className="pt-4 border-t border-white/5 flex items-center justify-between text-[11px] font-mono text-neutral-500">
                <span>0{index + 1} // ARCHIVE</span>
                <span className="w-1.5 h-1.5 rounded-full bg-red-500 opacity-0 group-hover:opacity-100 transition-opacity" />
              </div>
            </motion.div>
          );
        })}
      </div>
    </section>
  );
};
