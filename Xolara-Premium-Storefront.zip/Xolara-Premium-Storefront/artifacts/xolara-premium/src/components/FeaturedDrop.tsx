import React, { useRef } from 'react';
import { useStore } from '../context/StoreContext';
import { Product } from '../types';
import { 
  ChevronLeft, 
  ChevronRight, 
  Flame, 
  ShoppingBag, 
  Heart, 
  ArrowRight,
  Sparkles
} from 'lucide-react';
import { motion } from 'motion/react';
import { formatINR } from '../lib/currency';

export const FeaturedDrop: React.FC = () => {
  const { products, addToCart, toggleWishlist, wishlist, navigateTo } = useStore();
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  const dropProducts = products.filter(p => p.isFeatured || p.isLimitedDrop).slice(0, 4);

  const scroll = (direction: 'left' | 'right') => {
    if (scrollContainerRef.current) {
      const scrollAmount = direction === 'left' ? -380 : 380;
      scrollContainerRef.current.scrollBy({ left: scrollAmount, behavior: 'smooth' });
    }
  };

  return (
    <section 
      id="featured-drop-section" 
      className="relative overflow-hidden border-t border-[#34464b]/50 bg-[#11161c] px-4 py-12 sm:px-6 lg:px-12"
    >
      {/* Background Neon Lighting */}
      <div className="pointer-events-none absolute left-10 top-1/2 h-96 w-96 -translate-y-1/2 rounded-full bg-[#e89b4c]/[.06] blur-[120px]" />
      <div className="pointer-events-none absolute right-10 top-1/2 h-96 w-96 -translate-y-1/2 rounded-full bg-[#2b827d]/[.06] blur-[120px]" />

      <div className="max-w-7xl mx-auto">
        
        {/* Section Header */}
        <div className="mb-7 flex flex-col justify-between gap-5 md:flex-row md:items-end">
          <div className="space-y-2">
            <div className="flex items-center gap-3">
              <h2 className="font-heading text-2xl font-semibold uppercase tracking-[0.2em] text-[#f3efe5] sm:text-3xl lg:text-4xl">
                The XOLARA Drop
              </h2>
              <span className="border border-[#e89b4c] px-2.5 py-0.5 text-[9px] font-bold uppercase tracking-widest text-[#e89b4c]">
                LIMITED DROP
              </span>
            </div>
            
            <p className="max-w-xl text-xs uppercase tracking-[.14em] text-[#8d948f] sm:text-sm">
              Strictly limited quantities. Engineered from ultra-heavyweight textiles and custom garment treatments.
            </p>
          </div>

          {/* Carousel Controls & View All */}
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigateTo('shop')}
                className="flex items-center gap-2 pr-2 text-[10px] font-bold uppercase tracking-[0.2em] text-[#b9b9ae] transition-colors hover:text-[#e89b4c]"
            >
              <span>View All Pieces</span>
              <ArrowRight className="w-3.5 h-3.5 text-[#e89b4c]" />
            </button>

            <div className="flex items-center gap-2">
              <button
                id="drop-scroll-left"
                onClick={() => scroll('left')}
                className="flex h-10 w-10 items-center justify-center border border-[#34464b] bg-[#f3efe5]/[.03] text-[#f3efe5] transition-all hover:border-[#e89b4c] hover:bg-[#e89b4c]/10"
                aria-label="Scroll left"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                id="drop-scroll-right"
                onClick={() => scroll('right')}
                className="flex h-10 w-10 items-center justify-center border border-[#34464b] bg-[#f3efe5]/[.03] text-[#f3efe5] transition-all hover:border-[#2b827d] hover:bg-[#2b827d]/10"
                aria-label="Scroll right"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Horizontal Carousel Track */}
        <div
          ref={scrollContainerRef}
          className="flex items-stretch gap-4 overflow-x-auto pb-2 scrollbar-none snap-x snap-mandatory focus:outline-none"
          style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
        >
          {dropProducts.map((product) => {
            const isWishlisted = wishlist.includes(product.id);
            const displayPrice = product.discountPrice || product.price;

            return (
              <motion.div
                key={product.id}
                initial={{ opacity: 0, scale: 0.96 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                className="group flex w-[248px] flex-shrink-0 snap-start flex-col justify-between overflow-hidden border border-[#34464b] bg-[#0d1016] transition-all duration-300 hover:-translate-y-1 hover:border-[#e89b4c] sm:w-[276px]"
              >
                {/* Product Media Area */}
                <div className="relative aspect-[4/4.3] overflow-hidden bg-[#182026]">
                  <img
                    src={product.images[0]}
                    alt={product.name}
                      className="h-full w-full object-cover object-center transition-transform duration-700 group-hover:scale-105"
                    loading="lazy"
                  />

                  {/* Gradient Overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0d1016] via-transparent to-transparent opacity-90" />

                  {/* Top Badges */}
                  <div className="absolute top-3 left-3 flex flex-col gap-1.5 z-10">
                    <span className="bg-[#2b827d] px-2 py-0.5 text-[9px] font-bold uppercase tracking-widest text-white">
                      MADE IN INDIA
                    </span>
                    {product.isLimitedDrop && (
                        <span className="bg-[#e89b4c] px-2 py-0.5 text-[9px] font-black uppercase tracking-widest text-[#0d1016]">
                        LIMITED
                      </span>
                    )}
                    {product.discountPrice && (
                        <span className="bg-[#2b827d] px-2 py-0.5 font-mono text-[9px] font-bold text-[#f3efe5]">
                        SAVE {formatINR(product.price - product.discountPrice)}
                      </span>
                    )}
                  </div>

                  {/* Wishlist Button */}
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleWishlist(product.id);
                    }}
                    className={`absolute top-3 right-3 w-8 h-8 rounded-lg backdrop-blur-md border flex items-center justify-center transition-all z-10 ${
                      isWishlisted
                         ? 'bg-[#2b827d] text-[#f3efe5] border-[#2b827d]'
                         : 'bg-[#0d1016]/75 text-[#b9b9ae] border-[#b9b9ae]/20 hover:text-[#f3efe5] hover:border-[#e89b4c]'
                    }`}
                    aria-label="Toggle Wishlist"
                  >
                    <Heart className={`w-3.5 h-3.5 ${isWishlisted ? 'fill-current' : ''}`} />
                  </button>

                  {/* Color preview dots */}
                  <div className="absolute bottom-3 left-3 flex items-center gap-1.5 z-10">
                    {product.colors.slice(0, 3).map((col, idx) => (
                      <span
                        key={idx}
                        className="w-3 h-3 rounded-full border border-white/30 shadow-sm"
                        style={{ backgroundColor: col.hex }}
                        title={col.name}
                      />
                    ))}
                    {product.colors.length > 3 && (
                      <span className="text-[9px] font-mono text-neutral-300 font-bold">
                        +{product.colors.length - 3}
                      </span>
                    )}
                  </div>
                </div>

                {/* Product Content Details */}
                <div className="p-4 sm:p-5 flex-1 flex flex-col justify-between space-y-3">
                  <div>
                    <div className="text-[9px] tracking-widest text-neutral-400 font-mono uppercase mb-1">
                      {product.category} • SKU: {product.sku.slice(0, 12)}
                    </div>
                    <h3 
                      onClick={() => navigateTo('product-detail', product)}
                       className="cursor-pointer truncate font-heading text-sm font-semibold text-[#f3efe5] transition-colors hover:text-[#e89b4c] sm:text-base"
                    >
                      {product.name}
                    </h3>
                       <p className="mt-1 line-clamp-1 text-[11px] text-[#8d948f]">
                      {product.description}
                    </p>
                  </div>

                  {/* Price & Action Row */}
                  <div className="pt-3 border-t border-white/5 flex items-center justify-between gap-3">
                    <div>
                      <div className="flex items-baseline gap-2">
                       <span className="font-heading text-base font-semibold text-[#f3efe5] font-mono">
                           {formatINR(displayPrice)}
                        </span>
                        {product.discountPrice && (
                          <span className="text-[11px] text-neutral-500 line-through font-mono">
                            {formatINR(product.price)}
                          </span>
                        )}
                      </div>
                       <div className="text-[9px] font-medium text-[#78c3bc]">In Stock ({product.stock})</div>
                    </div>

                    <button
                      onClick={() => addToCart(product, product.sizes[0] || 'L', product.colors[0])}
                       className="flex items-center gap-1.5 bg-[#e89b4c] px-3.5 py-2 text-[11px] font-bold uppercase tracking-wider text-[#0d1016] transition-all hover:-translate-y-0.5"
                    >
                       <ShoppingBag className="h-3 w-3" />
                      <span>Add</span>
                    </button>
                  </div>
                </div>

              </motion.div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
