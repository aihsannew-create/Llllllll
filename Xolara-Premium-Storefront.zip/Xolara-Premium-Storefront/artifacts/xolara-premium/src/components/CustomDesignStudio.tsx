import React, { useState, useRef } from 'react';
import { useStore } from '../context/StoreContext';
import { 
  Upload, 
  Sparkles, 
  Layers, 
  RotateCcw, 
  Check, 
  ShoppingBag, 
  Send, 
  Eye, 
  Palette, 
  Maximize2,
  FileImage,
  Flame,
  ShieldCheck
} from 'lucide-react';
import { motion } from 'motion/react';
import { CustomDesignSpecs, Product } from '../types';
import { formatINR } from '../lib/currency';

const GARMENT_TYPES = [
  { id: 'tee-300', name: 'Oversized Heavyweight 300 GSM Tee', basePrice: 4950, minQty: 1 },
  { id: 'tee-acid', name: 'Mineral Acid-Wash Boxy Tee', basePrice: 5450, minQty: 1 },
  { id: 'tee-cyber', name: 'Cyberpunk Drop-Shoulder Heavy Tee', basePrice: 5250, minQty: 1 },
  { id: 'hoodie-460', name: 'Cotton Fleece 460 GSM Signature Hoodie', basePrice: 10200, minQty: 1 },
];

const GARMENT_COLORS = [
  { name: 'Obsidian Black', hex: '#09090e', shirtFilter: 'brightness(0.2) contrast(1.2)' },
  { name: 'Blood Crimson', hex: '#991b1b', shirtFilter: 'sepia(1) saturate(6) hue-rotate(320deg) brightness(0.6)' },
  { name: 'Royal Amethyst', hex: '#581c87', shirtFilter: 'sepia(1) saturate(5) hue-rotate(240deg) brightness(0.5)' },
  { name: 'Washed Concrete', hex: '#3f3f46', shirtFilter: 'brightness(0.5) contrast(1.1)' },
  { name: 'Bone Chalk', hex: '#e4e4e7', shirtFilter: 'brightness(0.95)' },
];

const PRINT_POSITIONS = [
  { id: 'Front Chest', label: 'Front Chest Minimal' },
  { id: 'Oversized Front', label: 'Oversized Front Graphic' },
  { id: 'Back Center', label: 'Full Back Center' },
  { id: 'Sleeve Minimal', label: 'Sleeve Minimalist' },
];

export const CustomDesignStudio: React.FC = () => {
  const { submitCustomDesign, addToCart, addToast, setIsCheckoutOpen } = useStore();
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Studio State
  const [selectedGarment, setSelectedGarment] = useState(GARMENT_TYPES[0]);
  const [selectedColor, setSelectedColor] = useState(GARMENT_COLORS[0]);
  const [selectedSize, setSelectedSize] = useState('L');
  const [quantity, setQuantity] = useState(1);
  const [printPosition, setPrintPosition] = useState<'Front Chest' | 'Oversized Front' | 'Back Center' | 'Sleeve Minimal'>('Oversized Front');
  
  // Custom uploaded artwork or text
  const [uploadedArtwork, setUploadedArtwork] = useState<string | null>(null);
  const [artworkFileName, setArtworkFileName] = useState('');
  const [customText, setCustomText] = useState('');
  const [textColor, setTextColor] = useState('#ffffff');
  const [graphicScale, setGraphicScale] = useState(100); // 50 - 150 %
  const [garmentSide, setGarmentSide] = useState<'front' | 'back'>('front');

  // Client Details Form
  const [customerName, setCustomerName] = useState('');
  const [customerEmail, setCustomerEmail] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [specialInstructions, setSpecialInstructions] = useState('');

  // Bulk Discount calculation
  const getUnitDiscount = (qty: number) => {
    if (qty >= 50) return 0.30; // 30% off
    if (qty >= 20) return 0.20; // 20% off
    if (qty >= 5) return 0.10;  // 10% off
    return 0;
  };

  const discount = getUnitDiscount(quantity);
  const unitPrice = Math.round(selectedGarment.basePrice * (1 - discount));
  const estimatedTotalPrice = unitPrice * quantity;

  // Handle image upload
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 10 * 1024 * 1024) {
        addToast('File too large', 'Please upload an image smaller than 10MB.', 'info');
        return;
      }
      setArtworkFileName(file.name);
      const reader = new FileReader();
      reader.onload = (event) => {
        setUploadedArtwork(event.target?.result as string);
        addToast('Artwork Mounted', `${file.name} loaded onto garment canvas.`, 'success');
      };
      reader.readAsDataURL(file);
    }
  };

  // Preset sample graphics for fast trial
  const samplePresets = [
    { name: 'Cyber Kanji', url: 'https://images.unsplash.com/photo-1579783902614-a3fb3927b675?auto=format&fit=crop&w=600&q=80' },
    { name: 'Gothic Skull', url: 'https://images.unsplash.com/photo-1544816155-12df9643f363?auto=format&fit=crop&w=600&q=80' },
    { name: 'Tokyo Neon', url: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=600&q=80' },
  ];

  // Save this design request in the current browser.
  const handleSubmitDesign = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName || !customerEmail) {
      addToast('Required Details', 'Please provide your full name and email address.', 'info');
      return;
    }

    submitCustomDesign({
      customerName,
      customerEmail,
      customerPhone: customerPhone || 'Not provided',
      productType: selectedGarment.name,
      baseColor: selectedColor.hex,
      colorName: selectedColor.name,
      size: selectedSize,
      quantity,
      designImage: uploadedArtwork || undefined,
      customText: customText || undefined,
      position: printPosition,
      specialInstructions: specialInstructions || 'Standard high-density direct to garment finish.',
      estimatedPrice: estimatedTotalPrice,
    });

    setCustomerName('');
    setCustomerEmail('');
    setCustomerPhone('');
    setSpecialInstructions('');
  };

  // Direct Order Prototype to Cart
  const handleOrderCustomGarment = () => {
    const customProduct: Product = {
      id: `custom-${Date.now()}`,
      sku: `XOL-CUSTOM-${selectedGarment.id.toUpperCase()}`,
      name: `Custom Bespoke ${selectedGarment.name}`,
      slug: `custom-${selectedGarment.id}`,
      category: 'CUSTOM DESIGNS',
      price: selectedGarment.basePrice,
      discountPrice: unitPrice,
      images: [
        uploadedArtwork || '/product-images/black-tee-hanger.jpg'
      ],
      colors: [{ name: selectedColor.name, hex: selectedColor.hex }],
      sizes: [selectedSize as any],
      description: `Bespoke customized piece with ${printPosition} print position. Custom text: ${customText || 'None'}. Special specs: ${specialInstructions || 'Direct to garment premium finish'}.`,
      fabricSpecs: '300 GSM cotton terry • Smooth surface optimized for printing',
      stock: 999,
      status: 'Active',
      rating: 0,
      reviewsCount: 0,
      tags: ['Custom', 'Bespoke', '1 of 1', 'Made in India'],
      createdAt: new Date().toISOString().split('T')[0]
    };

    addToCart(
      customProduct, 
      selectedSize, 
      { name: selectedColor.name, hex: selectedColor.hex }, 
      quantity,
      {
        productType: selectedGarment.name,
        baseColor: selectedColor.hex,
        colorName: selectedColor.name,
        size: selectedSize,
        quantity,
        designImage: uploadedArtwork,
        customText,
        textColor,
        position: printPosition,
        scale: graphicScale,
        specialInstructions,
        estimatedPrice: estimatedTotalPrice
      }
    );
  };

  return (
    <section 
      id="custom-design-section" 
      className="py-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto"
    >
      {/* Section Header */}
      <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-gradient-to-r from-red-600/20 to-purple-600/20 border border-purple-500/40 text-purple-300 text-xs font-bold tracking-[0.2em] uppercase shadow-[0_0_15px_rgba(139,92,246,0.25)]">
          <Sparkles className="w-3.5 h-3.5 text-purple-400" />
          <span>XOLARA BESPOKE ATELIER</span>
        </div>
        
        <h2 className="font-heading font-black text-3xl sm:text-5xl lg:text-6xl tracking-tight text-white uppercase">
          YOUR DESIGN. <span className="text-transparent bg-clip-text bg-gradient-to-r from-red-500 via-rose-400 to-purple-500">YOUR XOLARA.</span>
        </h2>
        
        <p className="text-neutral-300 text-sm sm:text-base">
          Upload your design and turn your idea into premium streetwear. High-density puff printing, DTG full-spectrum fidelity, and bespoke 300+ GSM heavyweight blanks.
        </p>
      </div>

      {/* Main Studio Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
        
        {/* Left Column: Interactive 2D Live Garment Visualizer */}
        <div className="lg:col-span-6 space-y-6">
          <div className="relative rounded-3xl p-1 bg-gradient-to-b from-purple-500/30 via-red-500/30 to-transparent shadow-[0_0_40px_rgba(139,92,246,0.2)]">
            <div className="rounded-[22px] bg-[#0c0c14] border border-white/[0.08] p-6 space-y-4">
              
              {/* Studio Canvas Controls Header */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-ping" />
                  <span className="text-xs font-mono font-bold text-white uppercase tracking-wider">
                    Interactive Garment Canvas
                  </span>
                </div>

                <div className="flex items-center gap-1.5 bg-[#141422] p-1 rounded-xl border border-white/5 text-[11px] font-mono">
                  <button
                    onClick={() => setGarmentSide('front')}
                    className={`px-3 py-1 rounded-lg font-bold transition-all ${
                      garmentSide === 'front' ? 'bg-gradient-to-r from-red-600 to-purple-600 text-white' : 'text-neutral-400 hover:text-white'
                    }`}
                  >
                    Front View
                  </button>
                  <button
                    onClick={() => setGarmentSide('back')}
                    className={`px-3 py-1 rounded-lg font-bold transition-all ${
                      garmentSide === 'back' ? 'bg-gradient-to-r from-red-600 to-purple-600 text-white' : 'text-neutral-400 hover:text-white'
                    }`}
                  >
                    Back View
                  </button>
                </div>
              </div>

              {/* Garment Mockup Display Box */}
              <div className="relative aspect-[4/4.8] rounded-2xl bg-gradient-to-b from-[#141422] to-[#08080f] border border-white/[0.06] overflow-hidden flex items-center justify-center">
                
                {/* Visual glow ambiance */}
                <div className="absolute inset-0 bg-radial-gradient-purple opacity-40 pointer-events-none" />

                {/* Base Garment Vector Mockup */}
                <div className="relative w-[85%] h-[85%] flex items-center justify-center">
                  <svg
                    viewBox="0 0 500 500"
                    className="w-full h-full drop-shadow-[0_20px_35px_rgba(0,0,0,0.9)] transition-all duration-300"
                    style={{ fill: selectedColor.hex }}
                  >
                    {/* T-Shirt Silhouette Vector */}
                    <path
                      d="M 160 80 Q 250 120 340 80 L 440 160 L 380 230 L 340 190 L 340 440 Q 250 450 160 440 L 160 190 L 120 230 L 60 160 Z"
                      stroke="#ffffff15"
                      strokeWidth="2"
                    />
                    {/* Collar Detail */}
                    <path
                      d="M 180 85 Q 250 130 320 85"
                      fill="none"
                      stroke="#ffffff25"
                      strokeWidth="4"
                    />
                  </svg>

                  {/* Artwork Print Area on Mockup */}
                  <div 
                    className={`absolute transition-all duration-300 flex flex-col items-center justify-center overflow-hidden border border-dashed border-red-500/40 rounded-lg p-2 ${
                      printPosition === 'Front Chest'
                        ? 'w-24 h-24 top-24'
                        : printPosition === 'Oversized Front'
                        ? 'w-48 h-56 top-28'
                        : printPosition === 'Back Center'
                        ? 'w-52 h-64 top-24'
                        : 'w-16 h-24 top-28 left-6'
                    }`}
                    style={{
                      transform: `scale(${graphicScale / 100})`,
                    }}
                  >
                    {uploadedArtwork ? (
                      <img
                        src={uploadedArtwork}
                        alt="Custom Graphic Preview"
                        className="max-w-full max-h-full object-contain filter drop-shadow-md"
                      />
                    ) : (
                      <div className="text-center p-2">
                        <FileImage className="w-6 h-6 text-neutral-500 mx-auto mb-1 animate-pulse" />
                        <span className="text-[10px] font-mono text-neutral-400 leading-tight block">
                          Upload Custom Art or Slogan
                        </span>
                      </div>
                    )}

                    {/* Custom Text Overlay */}
                    {customText && (
                      <div
                        className="mt-2 font-heading font-black text-center tracking-widest uppercase text-xs break-words max-w-full drop-shadow-md"
                        style={{ color: textColor }}
                      >
                        {customText}
                      </div>
                    )}
                  </div>
                </div>

                {/* Overlaid Garment Specs Tag */}
                <div className="absolute bottom-3 left-3 right-3 px-3.5 py-2 rounded-xl bg-[#090912]/90 backdrop-blur-md border border-white/10 flex items-center justify-between text-xs font-mono">
                  <span className="text-neutral-400">Position: <strong className="text-red-400">{printPosition}</strong></span>
                  <span className="text-neutral-400">Color: <strong className="text-white">{selectedColor.name}</strong></span>
                </div>
              </div>

              {/* Graphic Controls (Scale slider) */}
              <div className="space-y-3 pt-2">
                <div className="flex items-center justify-between text-xs font-mono text-neutral-400">
                  <span className="flex items-center gap-1.5">
                    <Maximize2 className="w-3.5 h-3.5 text-purple-400" />
                    Graphic Scale: <strong className="text-white">{graphicScale}%</strong>
                  </span>
                  <button
                    onClick={() => {
                      setGraphicScale(100);
                      setUploadedArtwork(null);
                      setCustomText('');
                    }}
                    className="text-neutral-400 hover:text-red-400 text-[11px] flex items-center gap-1"
                  >
                    <RotateCcw className="w-3 h-3" /> Reset
                  </button>
                </div>
                <input
                  type="range"
                  min="60"
                  max="140"
                  value={graphicScale}
                  onChange={(e) => setGraphicScale(Number(e.target.value))}
                  className="w-full accent-red-500 cursor-pointer"
                />
              </div>

              {/* Preset Sample Artwork Badges */}
              <div className="space-y-2 pt-2 border-t border-white/[0.06]">
                <span className="text-[11px] font-mono text-neutral-400 block uppercase">
                  Try Sample Graphics:
                </span>
                <div className="flex items-center gap-2">
                  {samplePresets.map((samp, idx) => (
                    <button
                      key={idx}
                      onClick={() => {
                        setUploadedArtwork(samp.url);
                        setArtworkFileName(samp.name);
                        addToast('Preset Applied', `${samp.name} graphic loaded.`, 'info');
                      }}
                      className="px-3 py-1.5 rounded-lg bg-[#141422] hover:bg-[#1f1f33] border border-white/10 text-[11px] text-neutral-300 font-mono flex items-center gap-1.5 transition-colors"
                    >
                      <Sparkles className="w-3 h-3 text-purple-400" />
                      <span>{samp.name}</span>
                    </button>
                  ))}
                </div>
              </div>

            </div>
          </div>
        </div>

        {/* Right Column: Customization Specs & Submission Form */}
        <div className="lg:col-span-6 space-y-6">
          <div className="rounded-3xl bg-[#0c0c14] border border-white/[0.08] p-6 sm:p-8 space-y-6 shadow-[0_10px_40px_rgba(0,0,0,0.7)]">
            
            {/* Step 1: Upload Design */}
            <div className="space-y-2">
              <label className="block text-xs font-mono uppercase tracking-wider text-neutral-300 font-bold">
                1. Upload Your Design / Logo / Artwork
              </label>
              
              <div
                onClick={() => fileInputRef.current?.click()}
                className="border-2 border-dashed border-white/15 hover:border-red-500/60 rounded-2xl p-6 text-center cursor-pointer bg-[#12121d] hover:bg-[#161624] transition-all group"
              >
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/png, image/jpeg, image/svg+xml, image/webp"
                  onChange={handleImageUpload}
                  className="hidden"
                />
                <Upload className="w-8 h-8 text-red-500 mx-auto mb-2 group-hover:scale-110 transition-transform" />
                <p className="text-xs font-bold text-white">
                  {artworkFileName ? `Selected: ${artworkFileName}` : 'Click to Upload Artwork (PNG, JPG, SVG, WebP)'}
                </p>
                <p className="text-[11px] text-neutral-400 mt-1">
                  High-resolution transparent PNG recommended for crisp DTG print (Up to 10MB)
                </p>
              </div>
            </div>

            {/* Custom Slogan / Streetwear Text */}
            <div className="space-y-2">
              <label className="block text-xs font-mono uppercase tracking-wider text-neutral-300 font-bold">
                2. Add Custom Typography / Slogan (Optional)
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="e.g. TOKYO 2026 // STAND APART"
                  value={customText}
                  onChange={(e) => setCustomText(e.target.value)}
                  className="flex-1 bg-[#141422] border border-white/10 rounded-xl px-4 py-2.5 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-red-500"
                />
                <input
                  type="color"
                  value={textColor}
                  onChange={(e) => setTextColor(e.target.value)}
                  className="w-11 h-10 rounded-xl bg-[#141422] border border-white/10 p-1 cursor-pointer"
                  title="Choose text color"
                />
              </div>
            </div>

            {/* Step 2: Garment Type & Color */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="block text-xs font-mono uppercase tracking-wider text-neutral-300 font-bold">
                  3. Garment Silhouette
                </label>
                <select
                  value={selectedGarment.id}
                  onChange={(e) => {
                    const found = GARMENT_TYPES.find(g => g.id === e.target.value);
                    if (found) setSelectedGarment(found);
                  }}
                  className="w-full bg-[#141422] border border-white/10 text-white text-xs rounded-xl p-3 focus:outline-none focus:border-purple-500 cursor-pointer"
                >
                  {GARMENT_TYPES.map(g => (
                    <option key={g.id} value={g.id}>
                      {g.name} ({formatINR(g.basePrice)})
                    </option>
                  ))}
                </select>
              </div>

              <div className="space-y-2">
                <label className="block text-xs font-mono uppercase tracking-wider text-neutral-300 font-bold">
                  4. Print Placement
                </label>
                <select
                  value={printPosition}
                  onChange={(e) => setPrintPosition(e.target.value as any)}
                  className="w-full bg-[#141422] border border-white/10 text-white text-xs rounded-xl p-3 focus:outline-none focus:border-purple-500 cursor-pointer"
                >
                  {PRINT_POSITIONS.map(p => (
                    <option key={p.id} value={p.id}>
                      {p.label}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Garment Base Color Palette */}
            <div className="space-y-2">
              <label className="block text-xs font-mono uppercase tracking-wider text-neutral-300 font-bold">
                5. Garment Base Color: <span className="text-red-400 font-normal">{selectedColor.name}</span>
              </label>
              <div className="flex items-center gap-3">
                {GARMENT_COLORS.map(c => {
                  const isSelected = selectedColor.name === c.name;
                  return (
                    <button
                      key={c.name}
                      onClick={() => setSelectedColor(c)}
                      className={`w-9 h-9 rounded-full border-2 transition-all flex items-center justify-center ${
                        isSelected
                          ? 'border-red-500 scale-110 shadow-[0_0_12px_rgba(225,29,72,0.6)]'
                          : 'border-white/20 hover:border-white/60'
                      }`}
                      style={{ backgroundColor: c.hex }}
                      title={c.name}
                    >
                      {isSelected && <Check className="w-4 h-4 text-white stroke-[3]" />}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Size & Quantity */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="block text-xs font-mono uppercase tracking-wider text-neutral-300 font-bold">
                  6. Size
                </label>
                <div className="flex flex-wrap gap-1.5">
                  {['XS', 'S', 'M', 'L', 'XL', '2XL', '3XL'].map(s => (
                    <button
                      key={s}
                      onClick={() => setSelectedSize(s)}
                      className={`px-3 py-2 rounded-lg text-xs font-mono font-bold transition-all ${
                        selectedSize === s
                          ? 'bg-gradient-to-r from-red-600 to-purple-600 text-white shadow-[0_0_10px_rgba(225,29,72,0.4)]'
                          : 'bg-[#141422] text-neutral-300 hover:bg-[#1c1c2e] border border-white/5'
                      }`}
                    >
                      {s}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <label className="block text-xs font-mono uppercase tracking-wider text-neutral-300 font-bold">
                  7. Quantity & Bulk Tier
                </label>
                <div className="flex items-center gap-3">
                  <input
                    type="number"
                    min="1"
                    max="1000"
                    value={quantity}
                    onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value) || 1))}
                    className="w-24 bg-[#141422] border border-white/10 rounded-xl p-2.5 text-center text-sm font-mono font-bold text-white focus:outline-none focus:border-red-500"
                  />
                  <div className="text-[11px] text-neutral-400 font-mono">
                    {discount > 0 ? (
                      <span className="text-emerald-400 font-bold">{discount * 100}% Bulk Tier Activated</span>
                    ) : (
                      <span>Tier: 5+ (10% off), 20+ (20% off)</span>
                    )}
                  </div>
                </div>
              </div>
            </div>

            {/* Special Instructions */}
            <div className="space-y-2">
              <label className="block text-xs font-mono uppercase tracking-wider text-neutral-300 font-bold">
                8. Special Printing Instructions / Finishes
              </label>
              <textarea
                rows={2}
                value={specialInstructions}
                onChange={(e) => setSpecialInstructions(e.target.value)}
                placeholder="Mention desired textures: High-density puff print, metallic silver foil, distress effect, custom woven collar labels..."
                className="w-full bg-[#141422] border border-white/10 rounded-xl p-3 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-purple-500"
              />
            </div>

            {/* Price Estimation Bar */}
            <div className="p-4 rounded-2xl bg-gradient-to-r from-red-950/40 via-purple-950/40 to-[#0e0e18] border border-red-500/30 flex items-center justify-between">
              <div>
                <span className="text-[11px] font-mono text-neutral-400 uppercase block">Estimated Atelier Investment</span>
                <span className="text-xs text-neutral-300 font-mono">{formatINR(unitPrice)} / unit ({quantity} total)</span>
              </div>
              <div className="text-right">
                <span className="font-heading font-black text-2xl text-white font-mono">
                  {formatINR(estimatedTotalPrice)}
                </span>
                <span className="text-[10px] text-emerald-400 block font-mono">Complimentary Sample Proof</span>
              </div>
            </div>

            {/* Client Contact Info Form for Submission */}
            <form onSubmit={handleSubmitDesign} className="space-y-4 pt-2 border-t border-white/[0.06]">
              <div className="text-xs font-mono uppercase tracking-wider text-neutral-300 font-bold">
                9. Your Contact Credentials
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <input
                  type="text"
                  required
                  placeholder="Full Name *"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  className="bg-[#141422] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-red-500"
                />
                <input
                  type="email"
                  required
                  placeholder="Email Address *"
                  value={customerEmail}
                  onChange={(e) => setCustomerEmail(e.target.value)}
                  className="bg-[#141422] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-red-500"
                />
              </div>

              <input
                type="tel"
                placeholder="Phone / WhatsApp (Optional, for direct follow-up)"
                value={customerPhone}
                onChange={(e) => setCustomerPhone(e.target.value)}
                className="w-full bg-[#141422] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-purple-500"
              />

              {/* Action Buttons: Submit Design & Order Prototype */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                <button
                  type="submit"
                  id="submit-design-btn"
                  className="py-3.5 px-4 rounded-xl bg-gradient-to-r from-red-600 via-rose-600 to-purple-600 hover:from-red-500 hover:to-purple-500 text-white font-heading font-bold text-xs tracking-[0.16em] uppercase flex items-center justify-center gap-2 shadow-[0_0_25px_rgba(225,29,72,0.4)] transition-all"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>SAVE REQUEST LOCALLY</span>
                </button>

                <button
                  type="button"
                  onClick={handleOrderCustomGarment}
                  id="order-custom-prototype-btn"
                  className="py-3.5 px-4 rounded-xl bg-white/[0.06] hover:bg-white/[0.1] border border-purple-500/40 hover:border-purple-400 text-white font-heading font-bold text-xs tracking-[0.16em] uppercase flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(139,92,246,0.2)] transition-all"
                >
                  <ShoppingBag className="w-3.5 h-3.5 text-purple-400" />
                  <span>ADD TO SHOPPING BAG</span>
                </button>
              </div>
            </form>

          </div>
        </div>

      </div>
    </section>
  );
};
