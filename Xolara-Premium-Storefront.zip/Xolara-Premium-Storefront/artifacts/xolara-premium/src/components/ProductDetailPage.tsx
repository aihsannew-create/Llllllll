import React, { useState, useEffect } from 'react';
import { useStore } from '../context/StoreContext';
import { Product, ProductColor } from '../types';
import { 
  ArrowLeft, 
  ShoppingBag, 
  Zap, 
  Heart, 
  ShieldCheck, 
  Truck, 
  RotateCcw, 
  Sparkles, 
  Star, 
  Check, 
  ChevronRight,
  Info,
  Layers,
  Ruler
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { formatINR } from '../lib/currency';
import { ImageWithSkeleton, ProductDetailSkeleton } from './Skeletons';

export const ProductDetailPage: React.FC = () => {
  const { 
    selectedProduct, 
    products, 
    addToCart, 
    toggleWishlist, 
    wishlist, 
    navigateTo, 
    setIsCheckoutOpen,
    addToast
  } = useStore();

  const product = selectedProduct || products[0];

  const [isLoading, setIsLoading] = useState(true);
  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [selectedSize, setSelectedSize] = useState<string>(product?.sizes[0] || 'L');
  const [selectedColor, setSelectedColor] = useState<ProductColor>(product?.colors[0] || { name: 'Obsidian Black', hex: '#0a0a0f' });
  const [quantity, setQuantity] = useState(1);
  const [activeTab, setActiveTab] = useState<'specs' | 'shipping' | 'returns' | 'reviews'>('specs');
  const [showSizeGuide, setShowSizeGuide] = useState(false);

  // Smooth perceived loading simulation when product changes
  useEffect(() => {
    setIsLoading(true);
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 280);
    return () => clearTimeout(timer);
  }, [product?.id]);

  // Sync state if product changes
  useEffect(() => {
    if (product) {
      setSelectedSize(product.sizes[0] || 'L');
      setSelectedColor(product.colors[0] || { name: 'Obsidian Black', hex: '#0a0a0f' });
      setActiveImageIndex(0);
    }
  }, [product]);

  // New review form
  const [reviewerName, setReviewerName] = useState('');
  const [reviewRating, setReviewRating] = useState(5);
  const [reviewComment, setReviewComment] = useState('');
  const [localReviews, setLocalReviews] = useState<Array<{
    id: string;
    author: string;
    rating: number;
    date: string;
    title: string;
    comment: string;
  }>>([]);

  if (!product) {
    return (
      <div className="py-24 text-center">
        <p className="text-neutral-400">Product not found.</p>
        <button
          onClick={() => navigateTo('shop')}
          className="mt-4 px-6 py-2 rounded-xl bg-red-600 text-white font-bold"
        >
          Return to Shop
        </button>
      </div>
    );
  }

  if (isLoading) {
    return <ProductDetailSkeleton />;
  }

  const isWishlisted = wishlist.includes(product.id);
  const displayPrice = product.discountPrice || product.price;
  const relatedProducts = products.filter(p => p.id !== product.id && p.category === product.category).slice(0, 4);

  const handleAdd = () => {
    addToCart(product, selectedSize, selectedColor, quantity);
  };

  const handleBuyNow = () => {
    addToCart(product, selectedSize, selectedColor, quantity);
    setIsCheckoutOpen(true);
  };

  const handlePostReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reviewerName || !reviewComment) {
      addToast('Incomplete Review', 'Please fill in your name and comment.', 'info');
      return;
    }
    const newRev = {
      id: `rev-${Date.now()}`,
      author: reviewerName,
      rating: reviewRating,
      date: 'Just now',
      title: 'Customer Review',
      comment: reviewComment
    };
    setLocalReviews(prev => [newRev, ...prev]);
    setReviewerName('');
    setReviewComment('');
    addToast('Review Added', 'This review is shown only in this browser session.', 'info');
  };

  return (
    <div className="py-10 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      
      {/* Breadcrumb / Back Link */}
      <div className="flex items-center justify-between mb-8 pb-4 border-b border-white/[0.06]">
        <button
          onClick={() => navigateTo('shop')}
          className="inline-flex items-center gap-2 text-xs font-bold tracking-widest text-neutral-400 hover:text-white uppercase transition-colors"
        >
          <ArrowLeft className="w-4 h-4 text-red-400" />
          <span>Back to Collection</span>
        </button>

        <div className="text-xs font-mono text-neutral-400 hidden sm:block">
          CATEGORY: <strong className="text-white">{product.category}</strong> • SKU: {product.sku}
        </div>
      </div>

      {/* Main Product Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14">
        
        {/* Left Column: Multi-Image Showcase Gallery */}
        <div className="lg:col-span-7 space-y-4">
          <div className="relative aspect-[4/4.6] rounded-3xl overflow-hidden bg-[#0c0c14] border border-white/10 shadow-[0_0_40px_rgba(0,0,0,0.8)] group">
            
            {/* Background lighting */}
            <div className="absolute inset-0 bg-radial-gradient-red opacity-60 pointer-events-none" />

            <ImageWithSkeleton
              src={product.images[activeImageIndex] || product.images[0]}
              alt={product.name}
              aspectRatio="aspect-[4/4.6]"
              className="group-hover:scale-105 transition-transform duration-500"
            />

            {/* Badges */}
            <div className="absolute top-4 left-4 flex flex-col gap-2 z-10">
              {product.isLimitedDrop && (
                <span className="px-3 py-1 rounded-full bg-red-600 border border-red-400/40 text-white text-xs font-black tracking-widest uppercase shadow-[0_0_15px_rgba(225,29,72,0.6)]">
                  LIMITED DROP
                </span>
              )}
              {product.discountPrice && (
                <span className="px-2.5 py-1 rounded-lg bg-purple-950/90 border border-purple-500/50 text-purple-200 text-xs font-mono font-bold">
                SAVE {formatINR(product.price - product.discountPrice)}
                </span>
              )}
            </div>

            {/* Wishlist Button */}
            <button
              onClick={() => toggleWishlist(product.id)}
              className={`absolute top-4 right-4 w-11 h-11 rounded-2xl backdrop-blur-md border flex items-center justify-center transition-all z-10 ${
                isWishlisted
                  ? 'bg-purple-600 text-white border-purple-400 shadow-[0_0_15px_rgba(139,92,246,0.6)]'
                  : 'bg-[#07070b]/80 text-neutral-300 border-white/10 hover:text-white hover:border-red-500'
              }`}
              aria-label="Wishlist"
            >
              <Heart className={`w-5 h-5 ${isWishlisted ? 'fill-current' : ''}`} />
            </button>
          </div>

          {/* Gallery Thumbnails */}
          {product.images.length > 1 && (
            <div className="flex items-center gap-3 overflow-x-auto pb-2 scrollbar-none">
              {product.images.map((imgUrl, idx) => (
                <button
                  key={idx}
                  onClick={() => setActiveImageIndex(idx)}
                  className={`relative w-20 h-20 rounded-xl overflow-hidden border-2 flex-shrink-0 transition-all ${
                    activeImageIndex === idx
                      ? 'border-[#D90429] shadow-[0_0_15px_rgba(217,4,41,0.5)] scale-105'
                      : 'border-white/10 hover:border-white/40 opacity-70 hover:opacity-100'
                  }`}
                >
                  <ImageWithSkeleton
                    src={imgUrl}
                    alt={`Thumbnail ${idx + 1}`}
                    aspectRatio="aspect-square"
                    className="w-full h-full object-cover"
                  />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Right Column: Product Purchasing Details */}
        <div className="lg:col-span-5 flex flex-col justify-between space-y-6">
          
          <div className="space-y-4">
            
            {/* Tag & Rating */}
            <div className="flex items-center justify-between">
              <span className="px-2.5 py-0.5 rounded bg-white/[0.06] border border-white/10 text-neutral-300 text-[11px] font-mono uppercase tracking-wider">
                XOLARA ATELIER • {product.category}
              </span>

              <div className="flex items-center gap-1.5 text-xs text-amber-400 font-mono">
                <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
                <span className="font-bold">{product.rating}</span>
                <span className="text-neutral-500">({product.reviewsCount + localReviews.length} reviews)</span>
              </div>
            </div>

            {/* Product Title */}
            <h1 className="font-heading font-black text-2xl sm:text-4xl text-white tracking-tight leading-tight">
              {product.name}
            </h1>

            {/* Pricing */}
            <div className="flex items-baseline gap-3 pt-1">
              <span className="font-heading font-black text-3xl text-white font-mono">
                {formatINR(displayPrice)}
              </span>
              {product.discountPrice && (
                <span className="text-lg text-neutral-500 line-through font-mono">
                  {formatINR(product.price)}
                </span>
              )}
              <span className="text-xs px-2 py-0.5 rounded bg-red-600/20 text-red-400 border border-red-500/30 font-bold uppercase tracking-wider">
                Made in India
              </span>
            </div>

            {/* Short Description */}
            <p className="text-neutral-300 text-sm leading-relaxed">
              {product.description}
            </p>

            {/* Color Selection */}
            <div className="space-y-2 pt-2">
              <div className="text-xs font-mono tracking-wider uppercase text-neutral-400 flex items-center justify-between">
                <span>Color: <strong className="text-white">{selectedColor.name}</strong></span>
              </div>
              <div className="flex items-center gap-2.5">
                {product.colors.map((c) => {
                  const isSelected = selectedColor.name === c.name;
                  return (
                    <button
                      key={c.name}
                      onClick={() => setSelectedColor(c)}
                      className={`w-8 h-8 rounded-full border-2 transition-all flex items-center justify-center relative ${
                        isSelected
                          ? 'border-red-500 scale-110 shadow-[0_0_12px_rgba(225,29,72,0.6)]'
                          : 'border-white/20 hover:border-white/50'
                      }`}
                      style={{ backgroundColor: c.hex }}
                      title={c.name}
                    >
                      {isSelected && <Check className="w-3.5 h-3.5 text-white stroke-[3]" />}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Size Selection & Size Guide */}
            <div className="space-y-2 pt-2">
              <div className="flex items-center justify-between text-xs font-mono tracking-wider uppercase">
                <span className="text-neutral-400">Select Size: <strong className="text-white">{selectedSize}</strong></span>
                <button
                  onClick={() => setShowSizeGuide(true)}
                  className="text-purple-400 hover:text-purple-300 flex items-center gap-1 underline underline-offset-4"
                >
                  <Ruler className="w-3.5 h-3.5" />
                  <span>Size Chart</span>
                </button>
              </div>

              <div className="grid grid-cols-5 gap-2">
                {product.sizes.map((s) => {
                  const isSelected = selectedSize === s;
                  return (
                    <button
                      key={s}
                      onClick={() => setSelectedSize(s)}
                      className={`py-3 rounded-xl text-xs font-mono font-bold transition-all ${
                        isSelected
                          ? 'bg-gradient-to-r from-red-600 to-purple-600 text-white shadow-[0_0_15px_rgba(225,29,72,0.4)] border border-red-400/40'
                          : 'bg-[#12121d] hover:bg-[#1c1c2e] text-neutral-300 border border-white/10'
                      }`}
                    >
                      {s}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Quantity & Stock Indicator */}
            <div className="flex items-center justify-between pt-2">
              <div className="flex items-center gap-3 bg-[#12121d] border border-white/10 rounded-xl p-1">
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="w-8 h-8 rounded-lg hover:bg-white/10 text-white font-bold flex items-center justify-center"
                >
                  -
                </button>
                <span className="w-8 text-center font-mono font-bold text-white text-sm">
                  {quantity}
                </span>
                <button
                  onClick={() => setQuantity(quantity + 1)}
                  className="w-8 h-8 rounded-lg hover:bg-white/10 text-white font-bold flex items-center justify-center"
                >
                  +
                </button>
              </div>

              <div className="text-xs font-mono text-emerald-400 flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <span>{product.stock} Units In Vault • Ready To Ship</span>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="space-y-3 pt-4">
              <button
                id="pdp-add-to-cart-btn"
                onClick={handleAdd}
                className="w-full py-4 rounded-xl bg-white/[0.06] hover:bg-white/[0.1] border border-red-500/40 hover:border-red-500 text-white font-heading font-bold text-sm tracking-[0.16em] uppercase flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(225,29,72,0.2)] transition-all"
              >
                <ShoppingBag className="w-4 h-4 text-red-400" />
                <span>Add To Shopping Bag</span>
              </button>

              <button
                id="pdp-buy-now-btn"
                onClick={handleBuyNow}
                className="w-full py-4 rounded-xl bg-gradient-to-r from-red-600 via-rose-600 to-purple-600 hover:from-red-500 hover:to-purple-500 text-white font-heading font-bold text-sm tracking-[0.16em] uppercase flex items-center justify-center gap-2 shadow-[0_0_30px_rgba(225,29,72,0.4)] transition-all"
              >
                <Zap className="w-4 h-4" />
                <span>Order Request</span>
              </button>
            </div>

            {/* Assurance Badges */}
            <div className="grid grid-cols-3 gap-3 pt-4 border-t border-white/[0.08] text-center">
              <div className="p-3 rounded-xl bg-[#0c0c14] border border-white/5 space-y-1">
                <Truck className="w-4 h-4 text-red-400 mx-auto" />
                <div className="text-[10px] font-bold text-white uppercase">Made in India</div>
                <div className="text-[9px] text-neutral-400">INR prices shown</div>
              </div>
              <div className="p-3 rounded-xl bg-[#0c0c14] border border-white/5 space-y-1">
                <ShieldCheck className="w-4 h-4 text-purple-400 mx-auto" />
                <div className="text-[10px] font-bold text-white uppercase">Direct Order Request</div>
                <div className="text-[9px] text-neutral-400">Saved in this browser</div>
              </div>
              <div className="p-3 rounded-xl bg-[#0c0c14] border border-white/5 space-y-1">
                <RotateCcw className="w-4 h-4 text-rose-400 mx-auto" />
                <div className="text-[10px] font-bold text-white uppercase">Manual Delivery</div>
                <div className="text-[9px] text-neutral-400">Terms confirmed directly</div>
              </div>
            </div>

          </div>

        </div>
      </div>

      {/* Product Information Accordions / Tabs */}
      <div className="mt-16 pt-10 border-t border-white/[0.08]">
        <div className="flex items-center gap-3 border-b border-white/10 pb-4 overflow-x-auto scrollbar-none">
          {[
            { id: 'specs', label: 'Material & Fabric Specs' },
            { id: 'shipping', label: 'Delivery Info' },
            { id: 'returns', label: 'Return Policy' },
            { id: 'reviews', label: `Reviews (${localReviews.length})` },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-5 py-2.5 rounded-xl text-xs font-bold tracking-wider uppercase transition-all whitespace-nowrap ${
                activeTab === tab.id
                  ? 'bg-gradient-to-r from-red-600 to-purple-600 text-white shadow-[0_0_15px_rgba(225,29,72,0.3)]'
                  : 'bg-white/[0.03] hover:bg-white/[0.06] text-neutral-400 hover:text-white'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <div className="py-8">
          {activeTab === 'specs' && (
            <div className="p-6 rounded-2xl bg-[#0c0c14] border border-white/[0.08] space-y-4 max-w-3xl">
              <h3 className="font-heading font-bold text-lg text-white flex items-center gap-2">
                <Layers className="w-4 h-4 text-red-400" />
                <span>Textile Architecture & Craftsmanship</span>
              </h3>
              <p className="text-neutral-300 text-sm leading-relaxed">
                {product.fabricSpecs}
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                <div className="p-3.5 rounded-xl bg-[#131320] border border-white/5 text-xs space-y-1">
                  <strong className="text-white block font-mono uppercase">Care Instructions</strong>
                  <span className="text-neutral-400">Machine wash cold inside-out with like colors. Hang dry in shade. Do not iron directly over high-density puff prints.</span>
                </div>
                <div className="p-3.5 rounded-xl bg-[#131320] border border-white/5 text-xs space-y-1">
                  <strong className="text-white block font-mono uppercase">Fit Architecture</strong>
                  <span className="text-neutral-400">Engineered drop-shoulder boxy drape. True-to-size gives relaxed streetwear fit. Size down for tailored fit.</span>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'shipping' && (
            <div className="p-6 rounded-2xl bg-[#0c0c14] border border-white/[0.08] space-y-3 max-w-3xl">
              <h3 className="font-heading font-bold text-lg text-white">Made in India · Delivery confirmed directly</h3>
              <p className="text-neutral-300 text-sm leading-relaxed">
                This store preview does not connect to a courier or fulfilment service. Delivery cost and timing must be confirmed manually before an order is accepted.
              </p>
              <ul className="text-xs text-neutral-400 space-y-2 list-disc pl-5">
                <li>Prices are displayed in Indian rupees.</li>
                <li>No dropshipping, automatic dispatch, or tracking is configured.</li>
                <li>Delivery details are confirmed by the store after an order request.</li>
              </ul>
            </div>
          )}

          {activeTab === 'returns' && (
            <div className="p-6 rounded-2xl bg-[#0c0c14] border border-white/[0.08] space-y-3 max-w-3xl">
              <h3 className="font-heading font-bold text-lg text-white">Return and exchange information</h3>
              <p className="text-neutral-300 text-sm leading-relaxed">
                A return or exchange policy is not configured in this preview. Confirm the store’s terms before placing an order request.
              </p>
            </div>
          )}

          {activeTab === 'reviews' && (
            <div className="space-y-8 max-w-4xl">
              {/* Existing Reviews List */}
              <div className="space-y-4">
                {localReviews.length === 0 && (
                  <p className="text-xs text-neutral-400">No reviews yet.</p>
                )}
                {localReviews.map((rev) => (
                  <div key={rev.id} className="p-5 rounded-2xl bg-[#0c0c14] border border-white/[0.08] space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="font-heading font-bold text-white text-sm">{rev.author}</span>
                      </div>
                      <span className="text-[11px] font-mono text-neutral-500">{rev.date}</span>
                    </div>
                    <div className="flex items-center gap-1 text-amber-400">
                      {[...Array(rev.rating)].map((_, i) => (
                        <Star key={i} className="w-3.5 h-3.5 fill-amber-400" />
                      ))}
                    </div>
                    <h4 className="text-sm font-bold text-white">{rev.title}</h4>
                    <p className="text-xs text-neutral-300 leading-relaxed">{rev.comment}</p>
                  </div>
                ))}
              </div>

              {/* Add Review Form */}
              <form onSubmit={handlePostReview} className="p-6 rounded-2xl bg-[#0e0e18] border border-red-500/30 space-y-4">
                <h4 className="font-heading font-bold text-base text-white">Leave A Collector Review</h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-mono text-neutral-400 mb-1">Your Name</label>
                    <input
                      type="text"
                      value={reviewerName}
                      onChange={(e) => setReviewerName(e.target.value)}
                      placeholder="e.g. Marcus V."
                      className="w-full bg-[#141422] border border-white/10 rounded-xl px-4 py-2.5 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-red-500"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-mono text-neutral-400 mb-1">Rating</label>
                    <select
                      value={reviewRating}
                      onChange={(e) => setReviewRating(Number(e.target.value))}
                      className="w-full bg-[#141422] border border-white/10 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none focus:border-purple-500"
                    >
                      <option value="5">★★★★★ (5/5) Masterpiece</option>
                      <option value="4">★★★★☆ (4/5) Premium Quality</option>
                      <option value="3">★★★☆☆ (3/5) Satisfactory</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-mono text-neutral-400 mb-1">Feedback & Fit Commentary</label>
                  <textarea
                    rows={3}
                    value={reviewComment}
                    onChange={(e) => setReviewComment(e.target.value)}
                    placeholder="Describe the fabric weight, drape, stitching, or styling..."
                    className="w-full bg-[#141422] border border-white/10 rounded-xl p-3 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-red-500"
                  />
                </div>

                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-red-600 to-purple-600 text-white text-xs font-bold tracking-wider uppercase shadow-[0_0_15px_rgba(225,29,72,0.3)] hover:opacity-90 transition-opacity"
                >
                  Submit Review
                </button>
              </form>
            </div>
          )}
        </div>
      </div>

      {/* Related Products Section */}
      {relatedProducts.length > 0 && (
        <div className="mt-16 pt-12 border-t border-white/10">
          <h3 className="font-heading font-black text-2xl text-white uppercase mb-8">
            COMPLETE THE <span className="text-[#D90429]">LOOK</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {relatedProducts.map((rel) => (
              <div
                key={rel.id}
                onClick={() => navigateTo('product-detail', rel)}
                className="group rounded-xl bg-[#0a0a0a] border border-white/10 hover:border-[#D90429] p-4 transition-all cursor-pointer shadow-lg"
              >
                <div className="aspect-[3/3.6] rounded-lg overflow-hidden bg-[#101016] mb-3">
                  <ImageWithSkeleton
                    src={rel.images[0]}
                    alt={rel.name}
                    aspectRatio="aspect-[3/3.6]"
                    className="group-hover:scale-105 transition-transform"
                  />
                </div>
                <div className="text-xs font-bold text-white group-hover:text-[#D90429] truncate">{rel.name}</div>
                <div className="text-sm font-mono font-extrabold text-white/90 mt-1">{formatINR(rel.discountPrice || rel.price)}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Size Guide Modal */}
      <AnimatePresence>
        {showSizeGuide && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="w-full max-w-xl bg-[#0e0e18] border border-white/10 rounded-3xl p-6 sm:p-8 space-y-6 shadow-[0_0_50px_rgba(0,0,0,0.9)]"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Ruler className="w-5 h-5 text-purple-400" />
                  <h3 className="font-heading font-bold text-xl text-white">XOLARA Sizing Matrix (Inches & CM)</h3>
                </div>
                <button
                  onClick={() => setShowSizeGuide(false)}
                  className="text-neutral-400 hover:text-white font-bold"
                >
                  ✕
                </button>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-xs font-mono text-left border-collapse">
                  <thead>
                    <tr className="border-b border-white/10 text-neutral-400">
                      <th className="py-2">Size</th>
                      <th className="py-2">Chest (In / CM)</th>
                      <th className="py-2">Length (In / CM)</th>
                      <th className="py-2">Shoulder (In / CM)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5 text-neutral-200">
                    <tr><td className="py-2 font-bold text-red-400">XS</td><td>38" / 96cm</td><td>28" / 71cm</td><td>20" / 51cm</td></tr>
                    <tr><td className="py-2 font-bold text-red-400">S</td><td>41" / 104cm</td><td>29" / 73cm</td><td>21" / 53cm</td></tr>
                    <tr><td className="py-2 font-bold text-red-400">M</td><td>44" / 112cm</td><td>30" / 76cm</td><td>22" / 56cm</td></tr>
                    <tr><td className="py-2 font-bold text-red-400">L</td><td>47" / 119cm</td><td>31" / 79cm</td><td>23" / 58cm</td></tr>
                    <tr><td className="py-2 font-bold text-red-400">XL</td><td>50" / 127cm</td><td>32" / 81cm</td><td>24" / 61cm</td></tr>
                    <tr><td className="py-2 font-bold text-red-400">2XL</td><td>53" / 135cm</td><td>33" / 84cm</td><td>25" / 63cm</td></tr>
                  </tbody>
                </table>
              </div>

              <div className="p-3.5 rounded-xl bg-purple-950/40 border border-purple-500/30 text-xs text-purple-200">
                All garments feature a relaxed drop-shoulder boxy cut. If you prefer a tailored fit, choose one size down.
              </div>

              <button
                onClick={() => setShowSizeGuide(false)}
                className="w-full py-3 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs uppercase"
              >
                Close Size Chart
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
};
