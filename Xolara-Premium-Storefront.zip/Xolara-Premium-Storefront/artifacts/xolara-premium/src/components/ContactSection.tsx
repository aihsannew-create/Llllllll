import React, { useState } from 'react';
import { Mail, Phone, MapPin, Send, MessageSquare, Check, Sparkles, ChevronDown } from 'lucide-react';
import { useStore } from '../context/StoreContext';
import { motion, AnimatePresence } from 'motion/react';

const FAQS = [
  {
    q: 'Where are XOLARA garments made?',
    a: 'XOLARA garments are made in India. Check each product page for its listed material, fit and garment details.'
  },
  {
    q: 'Can I request a custom graphic?',
    a: 'You can prepare a custom design request in the studio. It is saved only in this browser and is not sent to the store automatically.'
  },
  {
    q: 'How is delivery arranged?',
    a: 'Delivery cost and timing are confirmed manually by the store. This preview has no connected courier, shipment tracking, or automatic fulfilment.'
  },
  {
    q: 'What is the return or exchange policy?',
    a: 'A return policy is not configured in this preview. Please confirm the store’s terms before placing an order request.'
  }
];

export const ContactSection: React.FC = () => {
  const { addToast } = useStore();

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [message, setMessage] = useState('');
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !email || !message) {
      addToast('Missing Info', 'Please fill in Name, Email and your Message.', 'info');
      return;
    }

    const subject = encodeURIComponent(`XOLARA inquiry from ${name}`);
    const body = encodeURIComponent(
      `Name: ${name}\nEmail: ${email}\nPhone: ${phone || 'Not provided'}\n\n${message}`,
    );
    addToast('Email draft opened', 'Review and send the message from your email app.', 'info');
    window.location.href = `mailto:AIHSANEW@GMAIL.COM?subject=${subject}&body=${body}`;
  };

  return (
    <section 
      id="contact-section" 
      className="py-24 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto relative overflow-hidden"
    >
      {/* Background glow flares */}
      <div className="absolute top-10 left-1/3 w-80 h-80 bg-red-600/10 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-10 right-1/3 w-80 h-80 bg-purple-600/10 rounded-full blur-[120px] pointer-events-none" />

      {/* Section Header */}
      <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
        <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-white/[0.04] border border-red-500/30 text-red-400 text-xs font-mono font-bold tracking-[0.2em] uppercase">
          <Sparkles className="w-3.5 h-3.5 text-red-500" />
          <span>DIRECT ATELIER CONCIERGE</span>
        </div>
        
        <h2 className="font-heading font-black text-3xl sm:text-5xl lg:text-6xl text-white uppercase tracking-tight">
          CONNECT WITH <span className="text-transparent bg-clip-text bg-gradient-to-r from-red-500 to-purple-500">XOLARA</span>
        </h2>
        
        <p className="text-neutral-400 text-sm sm:text-base">
          Have an inquiry about sizing, custom wholesale drops, or private capsule collaborations? Reach out directly.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
        
        {/* Left Column: Direct Info & FAQ */}
        <div className="lg:col-span-5 space-y-8">
          
          {/* Direct Brand Contact Card */}
          <div className="p-6 sm:p-8 rounded-3xl bg-[#0c0c14] border border-white/[0.08] space-y-6 shadow-xl">
            <h3 className="font-heading font-bold text-xl text-white uppercase tracking-wide">
              Official Headquarters
            </h3>

            <div className="space-y-4 text-xs font-mono">
              <a 
                href="mailto:AIHSANEW@GMAIL.COM"
                className="flex items-center gap-3.5 p-3.5 rounded-xl bg-[#131320] border border-white/5 hover:border-red-500/40 text-neutral-300 hover:text-white transition-all group"
              >
                <div className="w-9 h-9 rounded-lg bg-red-600/20 text-red-400 flex items-center justify-center group-hover:scale-110 transition-transform">
                  <Mail className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-[10px] text-neutral-500 uppercase">Direct Email</div>
                  <div className="font-bold text-white text-xs sm:text-sm">AIHSANEW@GMAIL.COM</div>
                </div>
              </a>

              <div className="flex items-center gap-3.5 p-3.5 rounded-xl bg-[#131320] border border-white/5 text-neutral-300">
                <div className="w-9 h-9 rounded-lg bg-purple-600/20 text-purple-400 flex items-center justify-center">
                  <Sparkles className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-[10px] text-neutral-500 uppercase">Founder & Creative Director</div>
                  <div className="font-bold text-white">AIHSHAN ANAARI</div>
                </div>
              </div>

              <div className="flex items-center gap-3.5 p-3.5 rounded-xl bg-[#131320] border border-white/5 text-neutral-300">
                <div className="w-9 h-9 rounded-lg bg-emerald-600/20 text-emerald-400 flex items-center justify-center">
                  <MessageSquare className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-[10px] text-neutral-500 uppercase">Response Time</div>
                  <div className="font-bold text-white">Within 12 Hours • 7 Days a Week</div>
                </div>
              </div>
            </div>

            <div className="pt-4 border-t border-white/5 flex items-center justify-between text-xs text-neutral-400 font-mono">
              <span>XOLARA PREMIUM ARCHIVE</span>
              <span className="text-red-400 font-bold">WEAR YOUR IDENTITY</span>
            </div>
          </div>

          {/* Frequently Asked Questions Accordion */}
          <div className="space-y-3">
            <h3 className="font-heading font-bold text-lg text-white uppercase">
              Frequently Asked Questions
            </h3>

            <div className="space-y-2">
              {FAQS.map((faq, idx) => {
                const isOpen = openFaq === idx;
                return (
                  <div
                    key={idx}
                    className="rounded-2xl bg-[#0c0c14] border border-white/[0.08] overflow-hidden transition-colors"
                  >
                    <button
                      onClick={() => setOpenFaq(isOpen ? null : idx)}
                      className="w-full p-4 text-left flex items-center justify-between text-xs font-bold text-white font-mono hover:text-red-400"
                    >
                      <span>{faq.q}</span>
                      <ChevronDown className={`w-4 h-4 text-neutral-400 transition-transform ${isOpen ? 'rotate-180 text-red-400' : ''}`} />
                    </button>

                    <AnimatePresence>
                      {isOpen && (
                        <motion.div
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: 'auto', opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          className="px-4 pb-4 text-xs text-neutral-400 leading-relaxed font-sans"
                        >
                          {faq.a}
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                );
              })}
            </div>
          </div>

        </div>

        {/* Right Column: Interactive Contact Form */}
        <div className="lg:col-span-7">
          <div className="p-6 sm:p-10 rounded-3xl bg-[#0c0c14] border border-red-500/30 shadow-[0_0_40px_rgba(225,29,72,0.15)] space-y-6">
            <div className="space-y-1">
              <h3 className="font-heading font-black text-2xl text-white uppercase">
                Send Direct Transmission
              </h3>
              <p className="text-xs text-neutral-400 font-mono">
                Submitting opens an email draft. Review and send it from your email app.
              </p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-mono text-neutral-300 font-bold uppercase mb-1.5">
                    Your Name *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Your name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full bg-[#141422] border border-white/10 rounded-xl px-4 py-3 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-red-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-mono text-neutral-300 font-bold uppercase mb-1.5">
                    Email Address *
                  </label>
                  <input
                    type="email"
                    required
                    placeholder="you@example.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full bg-[#141422] border border-white/10 rounded-xl px-4 py-3 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-red-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-mono text-neutral-300 font-bold uppercase mb-1.5">
                  Phone / WhatsApp (Optional)
                </label>
                <input
                  type="tel"
                  placeholder="+91 98765 43210"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full bg-[#141422] border border-white/10 rounded-xl px-4 py-3 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-purple-500"
                />
              </div>

              <div>
                <label className="block text-xs font-mono text-neutral-300 font-bold uppercase mb-1.5">
                  Message / Inquiry *
                </label>
                <textarea
                  rows={5}
                  required
                  placeholder="Detail your inquiry: custom drop quantities, fabric specs, sizing questions, or brand collaboration..."
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  className="w-full bg-[#141422] border border-white/10 rounded-xl p-4 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-red-500"
                />
              </div>

              <button
                type="submit"
                id="contact-send-message-btn"
                className="w-full py-4 rounded-xl bg-gradient-to-r from-red-600 via-rose-600 to-purple-600 hover:from-red-500 hover:to-purple-500 text-white font-heading font-bold text-xs tracking-[0.2em] uppercase flex items-center justify-center gap-2 shadow-[0_0_30px_rgba(225,29,72,0.4)] transition-all"
              >
                <Send className="w-4 h-4" />
                <span>OPEN EMAIL DRAFT</span>
              </button>

            </form>
          </div>
        </div>

      </div>
    </section>
  );
};
