import React, { useState } from 'react';
import { useStore } from '../context/StoreContext';
import { 
  X,
  ArrowRight,
  Package,
  Check
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Order } from '../types';
import { formatINR } from '../lib/currency';

export const CheckoutModal: React.FC = () => {
  const { 
    isCheckoutOpen, 
    setIsCheckoutOpen, 
    cart, 
    cartSubtotal, 
    cartDiscount, 
    cartShipping, 
    cartTax, 
    cartTotal,
    createOrder,
    navigateTo
  } = useStore();

  const [step, setStep] = useState<'shipping' | 'review' | 'confirmation'>('shipping');

  // Customer Shipping Info
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [city, setCity] = useState('');
  const [state, setState] = useState('');
  const [zipCode, setZipCode] = useState('');
  const [country, setCountry] = useState('India');

  // Completed Order Info
  const [confirmedOrder, setConfirmedOrder] = useState<Order | null>(null);

  const handleProceedToReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullName || !email || !address || !city) return;
    setStep('review');
  };

  const handlePlaceOrder = () => {
    const order = createOrder({
      items: [...cart],
      customer: {
        fullName,
        email,
        phone: phone || 'Not provided',
        address,
        city,
        state: state || 'Not provided',
        zipCode: zipCode || 'Not provided',
        country,
      },
      paymentMethod: 'Manual confirmation required',
      subtotal: cartSubtotal,
      discount: cartDiscount,
      shipping: cartShipping,
      tax: cartTax,
      total: cartTotal,
    });

    setConfirmedOrder(order);
    setStep('confirmation');
  };

  const handleClose = () => {
    setIsCheckoutOpen(false);
    setStep('shipping');
    setConfirmedOrder(null);
  };

  if (!isCheckoutOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md overflow-y-auto">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="w-full max-w-2xl my-8 bg-[#0c0c14] border border-white/15 rounded-3xl p-6 sm:p-8 space-y-6 shadow-[0_0_60px_rgba(0,0,0,0.9)] max-h-[90vh] overflow-y-auto"
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between pb-4 border-b border-white/10">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-red-600/20 border border-red-500/40 flex items-center justify-center text-red-400">
              <Package className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-heading font-black text-lg text-white uppercase tracking-wider">
                {step === 'confirmation' ? 'Request Saved' : 'Order Request'}
              </h3>
              <span className="text-[10px] font-mono text-neutral-400">
                LOCAL BROWSER PREVIEW • NO PAYMENT PROCESSOR
              </span>
            </div>
          </div>

          <button
            onClick={handleClose}
            className="w-8 h-8 rounded-lg bg-white/5 hover:bg-white/10 text-neutral-400 hover:text-white flex items-center justify-center"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Step Indicator */}
        {step !== 'confirmation' && (
          <div className="flex items-center justify-between text-xs font-mono text-neutral-400 px-2">
            <span className={`flex items-center gap-1.5 ${step === 'shipping' ? 'text-red-400 font-bold' : 'text-emerald-400'}`}>
              <span className="w-5 h-5 rounded-full border border-current flex items-center justify-center text-[10px]">1</span>
              <span>Delivery Address</span>
            </span>
            <div className="h-[1px] flex-1 bg-white/10 mx-4" />
            <span className={`flex items-center gap-1.5 ${step === 'review' ? 'text-purple-400 font-bold' : 'text-neutral-500'}`}>
              <span className="w-5 h-5 rounded-full border border-current flex items-center justify-center text-[10px]">2</span>
              <span>Review Request</span>
            </span>
          </div>
        )}

        {/* STEP 1: Shipping Address Form */}
        {step === 'shipping' && (
          <form onSubmit={handleProceedToReview} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-mono text-neutral-300 font-bold uppercase mb-1">
                  Full Name *
                </label>
                <input
                  type="text"
                  required
                  placeholder="Marcus Vance"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  className="w-full bg-[#141422] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-red-500"
                />
              </div>

              <div>
                <label className="block text-xs font-mono text-neutral-300 font-bold uppercase mb-1">
                  Email Address *
                </label>
                <input
                  type="email"
                  required
                  placeholder="marcus@xolara.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-[#141422] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-red-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-mono text-neutral-300 font-bold uppercase mb-1">
                  Phone Number
                </label>
                <input
                  type="tel"
                  placeholder="+91 98765 43210"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full bg-[#141422] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-purple-500"
                />
              </div>

              <div>
                <label className="block text-xs font-mono text-neutral-300 font-bold uppercase mb-1">
                  Country
                </label>
                <select
                  value={country}
                  onChange={(e) => setCountry(e.target.value)}
                  className="w-full bg-[#141422] border border-white/10 text-white text-xs rounded-xl p-2.5 focus:outline-none focus:border-purple-500"
                >
                  <option value="India">India</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-mono text-neutral-300 font-bold uppercase mb-1">
                Street Address *
              </label>
              <input
                type="text"
                required
                placeholder="742 Evergreen Terrace, Suite 4B"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                className="w-full bg-[#141422] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-red-500"
              />
            </div>

            <div className="grid grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-mono text-neutral-300 font-bold uppercase mb-1">
                  City *
                </label>
                <input
                  type="text"
                  required
                  placeholder="Mumbai"
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  className="w-full bg-[#141422] border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-red-500"
                />
              </div>

              <div>
                <label className="block text-xs font-mono text-neutral-300 font-bold uppercase mb-1">
                  State / Prov
                </label>
                <input
                  type="text"
                  placeholder="Maharashtra"
                  value={state}
                  onChange={(e) => setState(e.target.value)}
                  className="w-full bg-[#141422] border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-red-500"
                />
              </div>

              <div>
                <label className="block text-xs font-mono text-neutral-300 font-bold uppercase mb-1">
                  PIN Code *
                </label>
                <input
                  type="text"
                  required
                  inputMode="numeric"
                  pattern="[0-9]{6}"
                  title="Enter a 6-digit Indian PIN code"
                  placeholder="400001"
                  value={zipCode}
                  onChange={(e) => setZipCode(e.target.value)}
                  className="w-full bg-[#141422] border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-red-500"
                />
              </div>
            </div>

            {/* Total summary glance */}
            <div className="p-4 rounded-2xl bg-[#12121e] border border-white/5 flex items-center justify-between text-xs font-mono">
                <span className="text-neutral-400">Product estimate ({cart.length} items):</span>
              <span className="font-heading font-bold text-lg text-white font-mono">{formatINR(cartTotal)}</span>
            </div>
            <p className="text-[10px] text-neutral-500">Delivery fee and applicable tax are confirmed manually.</p>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="submit"
                className="w-full sm:w-auto px-8 py-3.5 rounded-xl bg-gradient-to-r from-red-600 to-purple-600 text-white font-heading font-bold text-xs tracking-wider uppercase flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(225,29,72,0.3)]"
              >
                <span>Review Order Request</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </form>
        )}

        {/* STEP 2: Local order request review */}
        {step === 'review' && (
          <div className="space-y-6">
            <div className="border border-[#e89b4c]/30 bg-[#e89b4c]/5 p-4 text-xs leading-5 text-neutral-300">
              This is a local preview. No payment is taken and no shipping is arranged automatically. The store must confirm the request, delivery fee and payment with you directly.
            </div>

            {/* Shipping Recipient Recap */}
            <div className="p-3.5 rounded-xl bg-[#12121e] border border-white/5 text-xs font-mono text-neutral-300 flex items-center justify-between">
              <div>
                <span className="text-neutral-500 uppercase block text-[10px]">Shipping To:</span>
                <div>{fullName} • {address}, {city} ({country})</div>
              </div>
              <button
                onClick={() => setStep('shipping')}
                className="text-red-400 hover:text-red-300 font-bold underline"
              >
                Edit
              </button>
            </div>

            {/* Final Cost Breakdown */}
            <div className="p-4 rounded-2xl bg-gradient-to-r from-red-950/30 to-purple-950/30 border border-red-500/30 space-y-1.5 text-xs font-mono">
              <div className="flex justify-between text-neutral-400">
                <span>Subtotal</span>
                <span className="text-white">{formatINR(cartSubtotal)}</span>
              </div>
              {cartDiscount > 0 && (
                <div className="flex justify-between text-purple-400">
                  <span>VIP Discount</span>
                  <span>-{formatINR(cartDiscount)}</span>
                </div>
              )}
              <div className="flex justify-between text-neutral-400">
                <span>Delivery</span>
                <span>Confirmed manually</span>
              </div>
              <div className="pt-2 border-t border-white/10 flex justify-between text-base font-bold text-white">
                <span>Product estimate</span>
                <span className="text-red-400 font-mono text-lg">{formatINR(cartTotal)}</span>
              </div>
            </div>

            <div className="flex items-center justify-between gap-3 pt-2">
              <button
                type="button"
                onClick={() => setStep('shipping')}
                className="px-5 py-3 rounded-xl bg-white/5 hover:bg-white/10 text-neutral-300 text-xs font-bold uppercase font-mono"
              >
                Back
              </button>

              <button
                type="button"
                onClick={handlePlaceOrder}
                className="flex-1 py-4 rounded-xl bg-gradient-to-r from-red-600 via-rose-600 to-purple-600 hover:from-red-500 hover:to-purple-500 text-white font-heading font-bold text-xs tracking-[0.2em] uppercase flex items-center justify-center gap-2 shadow-[0_0_30px_rgba(225,29,72,0.4)]"
              >
                <Package className="w-4 h-4" />
                <span>Save order request · {formatINR(cartTotal)}</span>
              </button>
            </div>
          </div>
        )}

        {/* STEP 3: Order Confirmation */}
        {step === 'confirmation' && confirmedOrder && (
          <div className="py-6 text-center space-y-6">
            
            <div className="w-16 h-16 rounded-full bg-emerald-600/20 border border-emerald-500/40 text-emerald-400 flex items-center justify-center mx-auto animate-bounce">
              <Check className="w-8 h-8 stroke-[3]" />
            </div>

            <div className="space-y-2">
              <div className="text-xs font-mono text-red-400 uppercase tracking-widest font-bold">
                ORDER REQUEST SAVED IN THIS BROWSER
              </div>
              <h3 className="font-heading font-black text-2xl sm:text-3xl text-white uppercase">
                WEAR YOUR IDENTITY.
              </h3>
              <p className="text-xs text-neutral-300 font-mono">
                Order Reference: <strong className="text-white font-bold">{confirmedOrder.orderNumber}</strong>
              </p>
            </div>

            <div className="p-5 rounded-2xl bg-[#12121e] border border-white/5 text-xs font-mono text-left space-y-3">
              <div className="flex justify-between border-b border-white/5 pb-2">
                <span className="text-neutral-400">Recipient</span>
                <span className="text-white font-bold">{confirmedOrder.customer.fullName} ({confirmedOrder.customer.email})</span>
              </div>
              <div className="flex justify-between border-b border-white/5 pb-2">
                <span className="text-neutral-400">Delivery Address</span>
                <span className="text-white">{confirmedOrder.customer.address}, {confirmedOrder.customer.city}</span>
              </div>
              <div className="flex justify-between border-b border-white/5 pb-2">
                <span className="text-neutral-400">Payment</span>
                <span className="text-purple-300">{confirmedOrder.paymentMethod}</span>
              </div>
              <div className="flex justify-between text-white font-bold">
                <span>Product estimate</span>
                <span className="text-emerald-400 text-sm font-mono">{formatINR(confirmedOrder.total)}</span>
              </div>
            </div>

            <p className="text-xs text-neutral-400">
              No payment, confirmation email, dispatch or tracking is created. Contact the store to confirm this request and arrange delivery.
            </p>

            <button
              onClick={() => {
                handleClose();
                navigateTo('shop');
              }}
              className="w-full py-4 rounded-xl bg-gradient-to-r from-red-600 to-purple-600 text-white font-heading font-bold text-xs tracking-widest uppercase shadow-[0_0_20px_rgba(225,29,72,0.3)]"
            >
              Continue Exploring Drops
            </button>
          </div>
        )}

      </motion.div>
    </div>
  );
};
