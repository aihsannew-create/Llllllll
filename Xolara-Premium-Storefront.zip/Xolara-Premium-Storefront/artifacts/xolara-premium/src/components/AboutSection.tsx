import React from 'react';
import { ShieldCheck, Sparkles, User, Award, Mail, ArrowRight } from 'lucide-react';
import { motion } from 'motion/react';
import { useStore } from '../context/StoreContext';

export const AboutSection: React.FC = () => {
  const { navigateTo } = useStore();

  return (
    <section 
      id="about-section" 
      className="py-24 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto relative overflow-hidden"
    >
      {/* Background glowing gradients */}
      <div className="absolute top-1/3 right-10 w-96 h-96 bg-purple-700/10 rounded-full blur-[140px] pointer-events-none" />
      <div className="absolute bottom-10 left-10 w-96 h-96 bg-red-600/10 rounded-full blur-[140px] pointer-events-none" />

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
        
        {/* Left Column: Visual Brand Mood / Owner Archive Card */}
        <motion.div
          initial={{ opacity: 0, x: -30 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="lg:col-span-5 relative"
        >
          <div className="relative rounded-3xl p-1 bg-gradient-to-b from-purple-500/40 via-red-500/30 to-transparent shadow-[0_0_50px_rgba(139,92,246,0.2)]">
            <div className="rounded-[22px] bg-[#0c0c14] border border-white/[0.08] p-6 sm:p-8 space-y-6">
              
              {/* Card Header */}
              <div className="flex items-center justify-between">
                <span className="px-3 py-1 rounded-full bg-red-600/20 border border-red-500/40 text-red-400 text-[10px] font-mono font-bold uppercase tracking-widest">
                  ATELIER LEADERSHIP
                </span>
                <span className="text-xs font-mono text-neutral-400">EST. 2026</span>
              </div>

              {/* Owner Visual Frame */}
              <div className="relative aspect-[4/4.5] rounded-2xl overflow-hidden bg-gradient-to-b from-[#141424] to-[#090910] border border-white/10 group">
                <img
                  src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=1000&q=80"
                  alt="Aihshan Anaari - Founder of XOLARA PREMIUM"
                  className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700 filter contrast-110"
                />
                
                <div className="absolute inset-0 bg-gradient-to-t from-[#0c0c14] via-transparent to-transparent opacity-90" />

                {/* Overlaid Founder Nameplate */}
                <div className="absolute bottom-4 left-4 right-4 p-4 rounded-xl bg-[#090912]/85 backdrop-blur-md border border-white/10 space-y-1">
                  <div className="text-[10px] font-mono text-red-400 uppercase tracking-widest font-bold">
                    OWNER & CREATIVE DIRECTOR
                  </div>
                  <div className="font-heading font-black text-lg text-white tracking-wide uppercase">
                    AIHSHAN ANAARI
                  </div>
                  <div className="text-[11px] text-neutral-400 font-mono flex items-center gap-1.5 pt-0.5">
                    <Mail className="w-3 h-3 text-purple-400" />
                    <span>AIHSANEW@GMAIL.COM</span>
                  </div>
                </div>
              </div>

              {/* Atelier Commitments */}
              <div className="grid grid-cols-2 gap-3 text-center text-xs font-mono">
                <div className="p-3 rounded-xl bg-[#131320] border border-white/5">
                  <div className="font-bold text-white text-sm">300+ GSM</div>
                  <div className="text-neutral-400 text-[10px] uppercase">Fabric Minimum</div>
                </div>
                <div className="p-3 rounded-xl bg-[#131320] border border-white/5">
                  <div className="font-bold text-red-400 text-sm">Zero</div>
                  <div className="text-neutral-400 text-[10px] uppercase">Mass Production</div>
                </div>
              </div>

            </div>
          </div>
        </motion.div>

        {/* Right Column: Brand Philosophy & Narrative */}
        <motion.div
          initial={{ opacity: 0, x: 30 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="lg:col-span-7 space-y-8"
        >
          <div className="space-y-4">
            <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-white/[0.04] border border-purple-500/40 text-purple-300 text-xs font-mono font-bold tracking-[0.2em] uppercase">
              <Sparkles className="w-3.5 h-3.5 text-purple-400" />
              <span>THE XOLARA MANIFESTO</span>
            </div>

            <h2 className="font-heading font-black text-4xl sm:text-6xl text-white tracking-tight uppercase leading-[1.05]">
              BUILT TO <span className="text-transparent bg-clip-text bg-gradient-to-r from-red-500 via-rose-400 to-purple-500 glow-text-red">STAND OUT.</span>
            </h2>
          </div>

          <div className="space-y-4 text-neutral-300 text-base sm:text-lg leading-relaxed">
            <p className="font-medium text-white">
              XOLARA PREMIUM is a modern clothing brand focused on premium designs, bold streetwear and individuality. Our goal is to create clothing that feels different, looks premium and represents your identity.
            </p>
            
            <p className="text-neutral-400 text-sm sm:text-base">
              Founded by <strong className="text-white font-semibold">Aihshan Anaari</strong>, XOLARA was born from an uncompromising rebellion against thin, generic fast-fashion. We believe clothing is wearable architecture — an armor of individuality. Every drop is crafted with high-density combed cotton, sculpted boxy cuts, and tailored precision.
            </p>
          </div>

          {/* Core Values Bullets */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
            <div className="p-4 rounded-2xl bg-[#0c0c14] border border-white/[0.08] flex items-start gap-3">
              <div className="w-8 h-8 rounded-lg bg-red-600/20 border border-red-500/30 flex items-center justify-center flex-shrink-0 text-red-400">
                <ShieldCheck className="w-4 h-4" />
              </div>
              <div>
                <h4 className="font-heading font-bold text-sm text-white uppercase">Architectural Cuts</h4>
                <p className="text-xs text-neutral-400 mt-1">Structured drop shoulders and heavy collars engineered to never sag or lose form.</p>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-[#0c0c14] border border-white/[0.08] flex items-start gap-3">
              <div className="w-8 h-8 rounded-lg bg-purple-600/20 border border-purple-500/30 flex items-center justify-center flex-shrink-0 text-purple-400">
                <Award className="w-4 h-4" />
              </div>
              <div>
                <h4 className="font-heading font-bold text-sm text-white uppercase">1-of-1 Bespoke</h4>
                <p className="text-xs text-neutral-400 mt-1">Direct-to-garment atelier open for artists and individuals creating custom pieces.</p>
              </div>
            </div>
          </div>

          {/* Action Row */}
          <div className="flex flex-wrap items-center gap-4 pt-4 border-t border-white/[0.08]">
            <button
              onClick={() => navigateTo('shop')}
              className="px-8 py-4 rounded-xl bg-gradient-to-r from-red-600 via-rose-600 to-purple-600 text-white font-heading font-bold text-xs tracking-[0.16em] uppercase shadow-[0_0_25px_rgba(225,29,72,0.35)] hover:opacity-95 transition-all flex items-center gap-2"
            >
              <span>Explore Collection</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              onClick={() => navigateTo('contact')}
              className="px-8 py-4 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] border border-white/10 text-white font-heading font-bold text-xs tracking-[0.16em] uppercase transition-all"
            >
              Contact Owner
            </button>
          </div>

        </motion.div>

      </div>
    </section>
  );
};
