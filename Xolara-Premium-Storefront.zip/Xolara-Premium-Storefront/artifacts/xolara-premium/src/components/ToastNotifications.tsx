import React from 'react';
import { useStore } from '../context/StoreContext';
import { motion, AnimatePresence } from 'motion/react';
import { CheckCircle2, AlertCircle, Info, X } from 'lucide-react';

export const ToastNotifications: React.FC = () => {
  const { toasts, removeToast } = useStore();

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col gap-2.5 max-w-sm w-full pointer-events-none px-4 sm:px-0">
      <AnimatePresence>
        {toasts.map((toast) => (
          <motion.div
            key={toast.id}
            initial={{ opacity: 0, y: 20, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 10, scale: 0.9 }}
            className={`pointer-events-auto p-4 rounded-2xl border backdrop-blur-xl shadow-2xl flex items-start gap-3 ${
              toast.type === 'success'
                ? 'bg-[#0f1912]/95 border-emerald-500/40 text-emerald-300'
                : toast.type === 'crimson'
                ? 'bg-[#19150f]/95 border-[#e89b4c]/40 text-[#f3c48f]'
                : 'bg-[#101b1b]/95 border-[#2b827d]/40 text-[#a7dfd8]'
            }`}
          >
            <div className="mt-0.5 flex-shrink-0">
              {toast.type === 'success' && <CheckCircle2 className="w-5 h-5 text-emerald-400" />}
              {toast.type === 'crimson' && <AlertCircle className="h-5 w-5 text-[#e89b4c]" />}
              {toast.type === 'info' && <Info className="h-5 w-5 text-[#78c3bc]" />}
            </div>

            <div className="flex-1 space-y-0.5">
              <h5 className="font-heading font-bold text-xs uppercase tracking-wider text-white">
                {toast.title}
              </h5>
              <p className="text-xs text-neutral-300 leading-relaxed font-sans">
                {toast.message}
              </p>
            </div>

            <button
              onClick={() => removeToast(toast.id)}
              className="text-neutral-400 hover:text-white p-0.5 rounded transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
};
