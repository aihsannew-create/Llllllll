import React, { useEffect, useState } from 'react';
import { useStore } from '../context/StoreContext';
import { Heart, Menu, Search, ShoppingBag, Sliders, X } from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';

export const Header: React.FC = () => {
  const {
    activeView,
    navigateTo,
    cartCount,
    setIsCartOpen,
    wishlist,
    setIsWishlistOpen,
    setIsSearchOpen,
  } = useStore();
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 24);
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { id: 'home', label: 'Home' },
    { id: 'shop', label: 'Shop' },
    { id: 'custom-design', label: 'Custom' },
    { id: 'about', label: 'About' },
    { id: 'contact', label: 'Contact' },
  ];

  const handleNavClick = (viewId: string) => {
    navigateTo(viewId === 'collections' ? 'shop' : viewId);
    setMobileMenuOpen(false);
  };

  return (
    <>
      <div className="relative z-50 overflow-hidden border-b border-[#34464b]/40 bg-[#0d1016] py-2 font-mono text-[8px] uppercase tracking-[.28em] text-[#8d948f]">
        <div className="animate-ticker flex min-w-max justify-center gap-10 whitespace-nowrap">
          <span>Designed & made in India</span>
          <span className="text-[#e89b4c]">Prices in Indian rupees</span>
          <span>Delivery details confirmed manually</span>
          <span className="text-[#2b827d]">No automated shipping or dropshipping</span>
          <span>Designed & made in India</span>
        </div>
      </div>

      <header
        id="main-header"
        className={`sticky top-0 z-40 w-full transition-colors duration-500 ${isScrolled ? 'border-b border-[#34464b]/70 bg-[#0d1016]/90 backdrop-blur-xl' : 'border-b border-[#34464b]/40 bg-[#0d1016]/65 backdrop-blur-md'}`}
      >
        <div className="mx-auto flex h-[4.5rem] max-w-[1440px] items-center justify-between px-6 sm:px-10 lg:px-16">
          <button
            id="brand-logo-btn"
            data-testid="button-brand-home"
            onClick={() => handleNavClick('home')}
            className="group flex items-center gap-3 text-left"
          >
            <span className="flex h-7 w-7 items-center justify-center border border-[#e89b4c] font-heading text-sm font-semibold text-[#e89b4c] transition-colors group-hover:bg-[#e89b4c] group-hover:text-[#0d1016]">X</span>
            <span className="font-heading text-base font-semibold uppercase tracking-[.23em] text-[#f3efe5] sm:text-lg">Xolara<span className="text-[#e89b4c]">.</span></span>
          </button>

          <nav id="desktop-navbar" className="hidden items-center gap-7 lg:flex">
            {navLinks.map((link) => {
              const isActive = activeView === link.id;
              return (
                <button
                  key={link.id}
                  id={`nav-link-${link.id}`}
                  data-testid={`button-nav-${link.id}`}
                  onClick={() => handleNavClick(link.id)}
                  className={`relative py-2 text-[9px] font-semibold uppercase tracking-[.22em] transition-colors ${isActive ? 'text-[#e89b4c]' : 'text-[#b9b9ae] hover:text-[#f3efe5]'}`}
                >
                  {link.label}
                  {isActive && <motion.span layoutId="activeNavIndicator" className="absolute -bottom-0.5 left-0 right-0 h-px bg-[#e89b4c]" />}
                </button>
              );
            })}
          </nav>

          <div className="flex items-center gap-2 sm:gap-3">
            <button
              id="header-search-btn"
              data-testid="button-header-search"
              onClick={() => setIsSearchOpen(true)}
              className="flex h-9 w-9 items-center justify-center border border-[#34464b]/70 text-[#b9b9ae] transition-colors hover:border-[#e89b4c] hover:text-[#e89b4c]"
              aria-label="Search the archive"
            >
              <Search className="h-4 w-4" />
            </button>
            <button
              id="header-wishlist-btn"
              data-testid="button-header-wishlist"
              onClick={() => setIsWishlistOpen(true)}
              className="relative flex h-9 w-9 items-center justify-center border border-[#34464b]/70 text-[#b9b9ae] transition-colors hover:border-[#e89b4c] hover:text-[#e89b4c]"
              aria-label="Open wishlist"
            >
              <Heart className="h-4 w-4" />
              {wishlist.length > 0 && <span className="absolute -right-1.5 -top-1.5 flex h-4 min-w-4 items-center justify-center bg-[#e89b4c] px-1 font-mono text-[8px] font-bold text-[#0d1016]">{wishlist.length}</span>}
            </button>
            <button
              id="header-cart-btn"
              data-testid="button-header-cart"
              onClick={() => setIsCartOpen(true)}
              className="group relative flex h-9 items-center gap-2 bg-[#e89b4c] px-3 text-[9px] font-bold uppercase tracking-[.18em] text-[#0d1016] transition-transform hover:-translate-y-0.5"
              aria-label="Open shopping bag"
            >
              <ShoppingBag className="h-3.5 w-3.5" />
              <span className="hidden sm:inline">Bag</span>
              <span className="font-mono">[{cartCount}]</span>
            </button>
            <button
              id="header-admin-btn"
              data-testid="button-header-admin"
              onClick={() => handleNavClick('admin')}
              className="hidden h-9 items-center gap-2 border border-[#2b827d]/70 px-3 text-[9px] font-bold uppercase tracking-[.14em] text-[#a7dfd8] transition-colors hover:border-[#e89b4c] hover:text-[#e89b4c] sm:flex"
            >
              <Sliders className="h-3.5 w-3.5" />
              <span>Manage store</span>
            </button>
            <button
              id="header-mobile-menu-btn"
              data-testid="button-mobile-menu"
              onClick={() => setMobileMenuOpen((open) => !open)}
              className="flex h-9 w-9 items-center justify-center border border-[#34464b]/70 text-[#b9b9ae] lg:hidden"
              aria-label="Toggle navigation"
            >
              {mobileMenuOpen ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
            </button>
          </div>
        </div>
      </header>

      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            id="mobile-drawer"
            initial={{ opacity: 0, y: -12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            className="fixed inset-x-0 top-[6.5rem] z-50 border-b border-[#34464b] bg-[#0d1016]/98 p-6 shadow-2xl backdrop-blur-xl lg:hidden"
          >
            <nav className="grid gap-1">
              {navLinks.map((link) => (
                <button
                  key={link.id}
                  id={`mobile-nav-${link.id}`}
                  data-testid={`button-mobile-nav-${link.id}`}
                  onClick={() => handleNavClick(link.id)}
                  className={`flex items-center justify-between border-b border-[#34464b]/45 px-1 py-4 text-left text-[11px] font-semibold uppercase tracking-[.24em] ${activeView === link.id ? 'text-[#e89b4c]' : 'text-[#b9b9ae]'}`}
                >
                  {link.label}
                  <span className="font-mono text-[9px] text-[#8d948f]">0{navLinks.indexOf(link) + 1}</span>
                </button>
              ))}
            </nav>
            <button onClick={() => handleNavClick('admin')} data-testid="button-mobile-admin" className="mt-5 flex items-center gap-2 border border-[#2b827d]/70 px-3 py-2.5 text-[10px] font-bold uppercase tracking-[.16em] text-[#a7dfd8]">
              <Sliders className="h-3.5 w-3.5" /> Manage store
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};