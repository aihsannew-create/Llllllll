import React from 'react';
import { useStore } from '../context/StoreContext';
import { Product } from '../types';
import { X, Heart, ShoppingBag, Trash2, ArrowRight } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { formatINR } from '../lib/currency';

export const WishlistDrawer: React.FC = () => {
  const { 
    isWishlistOpen, 
    setIsWishlistOpen, 
    wishlist,
    products,
    toggleWishlist,
    addToCart, 
    setIsCartOpen,
    navigateTo 
  } = useStore();

  const savedProducts = products.filter((product) => wishlist.includes(product.id));

  const handleMoveToCart = (product: Product) => {
    addToCart(product, product.sizes[0] || 'L', product.colors[0], 1);
    toggleWishlist(product.id);
    setIsWishlistOpen(false);
    setIsCartOpen(true);
  };

  return (
    <AnimatePresence>
      {isWishlistOpen && (
        <div className="fixed inset-0 z-50 overflow-hidden">
          
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setIsWishlistOpen(false)}
            className="absolute inset-0 bg-black/80 backdrop-blur-sm"
          />

          <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
            <motion.div
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 30, stiffness: 300 }}
              className="w-screen max-w-md bg-[#0b0b14] border-l border-white/10 flex flex-col justify-between shadow-[0_0_60px_rgba(0,0,0,0.9)]"
            >
              {/* Header */}
              <div className="p-6 border-b border-white/[0.08] flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-lg bg-red-600/20 border border-red-500/40 flex items-center justify-center text-red-400">
                    <Heart className="w-4 h-4 fill-current" />
                  </div>
                  <div>
                    <h3 className="font-heading font-black text-lg text-white uppercase tracking-wider">
                      Vault Wishlist
                    </h3>
                    <span className="text-[11px] font-mono text-neutral-400">
                      {wishlist.length} Saved Artifacts
                    </span>
                  </div>
                </div>

                <button
                  onClick={() => setIsWishlistOpen(false)}
                  className="w-9 h-9 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] border border-white/10 flex items-center justify-center text-neutral-400 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Items List */}
              <div className="flex-1 overflow-y-auto p-6 space-y-4">
                {wishlist.length === 0 ? (
                  <div className="py-20 text-center space-y-4">
                    <div className="w-16 h-16 rounded-full bg-white/[0.04] border border-white/10 flex items-center justify-center mx-auto text-neutral-500">
                      <Heart className="w-7 h-7" />
                    </div>
                    <div className="space-y-1">
                      <h4 className="font-heading font-bold text-white text-base">Your Wishlist is Empty</h4>
                      <p className="text-xs text-neutral-400 max-w-xs mx-auto">
                        Tap the heart icon on any garment in the catalog to bookmark your favorite drops.
                      </p>
                    </div>
                    <button
                      onClick={() => {
                        setIsWishlistOpen(false);
                        navigateTo('shop');
                      }}
                      className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-red-600 to-purple-600 text-white text-xs font-bold tracking-wider uppercase"
                    >
                      Browse Catalog
                    </button>
                  </div>
                ) : (
                  savedProducts.map((product) => (
                    <div
                      key={product.id}
                      className="p-4 rounded-2xl bg-[#0e0e18] border border-white/[0.06] flex gap-4 relative group"
                    >
                      <div 
                        onClick={() => {
                          setIsWishlistOpen(false);
                          navigateTo('product-detail', product);
                        }}
                        className="w-20 h-24 rounded-xl overflow-hidden bg-[#141422] flex-shrink-0 cursor-pointer border border-white/5"
                      >
                        <img
                          src={product.images[0]}
                          alt={product.name}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                        />
                      </div>

                      <div className="flex-1 flex flex-col justify-between">
                        <div>
                          <div className="flex items-start justify-between gap-2">
                            <h4 
                              onClick={() => {
                                setIsWishlistOpen(false);
                                navigateTo('product-detail', product);
                              }}
                              className="font-heading font-bold text-sm text-white line-clamp-1 cursor-pointer hover:text-red-400 transition-colors"
                            >
                              {product.name}
                            </h4>
                            <button
                               onClick={() => toggleWishlist(product.id)}
                              className="text-neutral-500 hover:text-red-400 p-1"
                              title="Remove from wishlist"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>

                          <div className="text-xs font-mono text-neutral-400 mt-1">
                            {formatINR(product.discountPrice || product.price)}
                          </div>
                        </div>

                        <button
                          onClick={() => handleMoveToCart(product)}
                          className="mt-2 py-2 px-3 rounded-lg bg-white/5 hover:bg-gradient-to-r hover:from-red-600 hover:to-purple-600 hover:text-white border border-white/10 text-neutral-300 text-xs font-bold uppercase flex items-center justify-center gap-1.5 transition-all"
                        >
                          <ShoppingBag className="w-3.5 h-3.5" />
                          <span>Move to Bag</span>
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>

              {wishlist.length > 0 && (
                <div className="p-6 border-t border-white/[0.08] bg-[#0c0c14]">
                  <button
                    onClick={() => {
                      savedProducts.forEach((product) => addToCart(product, product.sizes[0] || 'L', product.colors[0], 1));
                      setIsWishlistOpen(false);
                      setIsCartOpen(true);
                    }}
                    className="w-full py-3.5 rounded-xl bg-gradient-to-r from-red-600 to-purple-600 text-white font-heading font-bold text-xs tracking-wider uppercase flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(225,29,72,0.3)]"
                  >
                    <span>Move All Items to Bag</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              )}

            </motion.div>
          </div>
        </div>
      )}
    </AnimatePresence>
  );
};
