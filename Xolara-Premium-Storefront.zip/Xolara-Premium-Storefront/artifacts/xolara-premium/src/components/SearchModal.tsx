import React, { useState, useEffect, useRef } from 'react';
import { useStore } from '../context/StoreContext';
import { Search, X, ArrowRight, Sparkles, Tag } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { formatINR } from '../lib/currency';
import { Product } from '../types';

export const SearchModal: React.FC = () => {
  const { isSearchOpen, setIsSearchOpen, products, navigateTo } = useStore();
  const [query, setQuery] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isSearchOpen) {
      setTimeout(() => inputRef.current?.focus(), 50);
    } else {
      setQuery('');
    }
  }, [isSearchOpen]);

  const filteredProducts = query.trim() === '' ? [] : products.filter(p => 
    p.name.toLowerCase().includes(query.toLowerCase()) ||
    p.category.toLowerCase().includes(query.toLowerCase()) ||
    p.tags.some(t => t.toLowerCase().includes(query.toLowerCase())) ||
    p.sku.toLowerCase().includes(query.toLowerCase())
  );

  const handleSelectProduct = (product: Product) => {
    setIsSearchOpen(false);
    navigateTo('product-detail', product);
  };

  const quickPills = ['Oversized Tee', 'Cyberpunk', 'Heavyweight 300GSM', 'Acid Crimson', 'Custom Design'];

  if (!isSearchOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-20 px-4 bg-black/85 backdrop-blur-md">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -20 }}
        className="w-full max-w-2xl bg-[#0c0c14] border border-white/15 rounded-3xl p-6 space-y-6 shadow-[0_0_60px_rgba(0,0,0,0.9)] overflow-hidden"
      >
        {/* Search Bar */}
        <div className="relative flex items-center">
          <Search className="absolute left-4 w-5 h-5 text-red-500" />
          <input
            ref={inputRef}
            type="text"
            placeholder="Search silhouettes, drops, GSM specs, or SKU codes..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="w-full bg-[#141424] border border-white/10 rounded-2xl pl-12 pr-12 py-4 text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-red-500 font-mono shadow-inner"
          />
          <button
            onClick={() => setIsSearchOpen(false)}
            className="absolute right-4 text-neutral-400 hover:text-white p-1 rounded-lg hover:bg-white/10"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Quick Tag Pills */}
        <div className="flex flex-wrap items-center gap-2 pt-1">
          <span className="text-[11px] font-mono text-neutral-500 uppercase mr-1">Trending:</span>
          {quickPills.map(tag => (
            <button
              key={tag}
              onClick={() => setQuery(tag)}
              className="px-3 py-1 rounded-full bg-white/[0.04] hover:bg-white/[0.08] border border-white/10 text-neutral-300 text-xs font-mono transition-colors"
            >
              {tag}
            </button>
          ))}
        </div>

        {/* Results List */}
        <div className="max-h-96 overflow-y-auto space-y-2">
          {query && filteredProducts.length === 0 ? (
            <div className="py-12 text-center text-neutral-400 text-xs font-mono">
              No matching archival items found for "{query}".
            </div>
          ) : (
            filteredProducts.map(prod => (
              <div
                key={prod.id}
                onClick={() => handleSelectProduct(prod)}
                className="p-3 rounded-2xl bg-[#12121e] hover:bg-[#181828] border border-white/5 hover:border-purple-500/40 flex items-center justify-between cursor-pointer transition-all group"
              >
                <div className="flex items-center gap-3.5">
                  <img
                    src={prod.images[0]}
                    alt={prod.name}
                    className="w-12 h-12 rounded-xl object-cover bg-black"
                  />
                  <div>
                    <h4 className="font-heading font-bold text-sm text-white group-hover:text-red-400 transition-colors">
                      {prod.name}
                    </h4>
                    <div className="text-[11px] font-mono text-neutral-400">
                      {prod.category} • <strong className="text-white">{formatINR(prod.discountPrice || prod.price)}</strong>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2 text-xs font-mono text-neutral-400 group-hover:text-purple-300">
                  <span>View Details</span>
                  <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                </div>
              </div>
            ))
          )}
        </div>

      </motion.div>
    </div>
  );
};
