import React, { useState } from 'react';

interface SkeletonProps {
  className?: string;
}

export const Skeleton: React.FC<SkeletonProps> = ({ className = '' }) => {
  return (
    <div
      className={`relative overflow-hidden bg-white/[0.05] rounded-lg animate-pulse before:absolute before:inset-0 before:-translate-x-full before:animate-[shimmer_2s_infinite] before:bg-gradient-to-r before:from-transparent before:via-white/[0.08] before:to-transparent ${className}`}
    />
  );
};

interface ImageWithSkeletonProps extends React.ImgHTMLAttributes<HTMLImageElement> {
  src: string;
  alt: string;
  className?: string;
  wrapperClassName?: string;
  aspectRatio?: string;
}

export const ImageWithSkeleton: React.FC<ImageWithSkeletonProps> = ({
  src,
  alt,
  className = '',
  wrapperClassName = '',
  aspectRatio = 'aspect-[3/4]',
  ...props
}) => {
  const [isLoaded, setIsLoaded] = useState(false);
  const [hasError, setHasError] = useState(false);

  return (
    <div className={`relative overflow-hidden ${aspectRatio} ${wrapperClassName}`}>
      {/* Shimmer skeleton while loading */}
      {!isLoaded && !hasError && (
        <div className="absolute inset-0 bg-[#12121c] animate-pulse flex flex-col items-center justify-center">
          <div className="w-12 h-12 rounded-2xl bg-white/[0.04] border border-white/[0.08] flex items-center justify-center">
            <div className="w-5 h-5 rounded-full border-2 border-[#D90429] border-t-transparent animate-spin" />
          </div>
          <span className="text-[9px] font-mono tracking-widest text-neutral-400 uppercase mt-3">
            Loading Asset...
          </span>
        </div>
      )}

      {/* Actual Image */}
      <img
        src={src}
        alt={alt}
        onLoad={() => setIsLoaded(true)}
        onError={() => {
          setHasError(true);
          setIsLoaded(true);
        }}
        className={`w-full h-full object-cover object-center transition-all duration-700 ${
          isLoaded && !hasError ? 'opacity-100 scale-100' : 'opacity-0 scale-95'
        } ${className}`}
        {...props}
      />

      {/* Error Fallback */}
      {hasError && (
        <div className="absolute inset-0 bg-[#12121c] flex flex-col items-center justify-center p-4 text-center">
          <span className="text-xs text-neutral-400 font-mono">XOLARA STUDIO</span>
          <span className="text-[10px] text-neutral-400 mt-1">Image preview pending</span>
        </div>
      )}
    </div>
  );
};

export const ProductCardSkeleton: React.FC = () => {
  return (
    <div className="rounded-2xl bg-[#0c0c14] border border-white/[0.08] overflow-hidden flex flex-col justify-between shadow-2xl p-0 h-full">
      {/* Image Skeleton Box */}
      <div className="relative aspect-[3/3.8] bg-[#141422] p-4 flex flex-col justify-between overflow-hidden">
        <Skeleton className="w-full h-full absolute inset-0" />
        
        {/* Top Badges Skeleton */}
        <div className="relative z-10 flex justify-between items-start">
          <Skeleton className="w-16 h-5 rounded-full bg-white/10" />
          <Skeleton className="w-8 h-8 rounded-xl bg-white/10" />
        </div>

        {/* Bottom Color dots skeleton */}
        <div className="relative z-10 flex items-center gap-1.5">
          <Skeleton className="w-3.5 h-3.5 rounded-full bg-white/15" />
          <Skeleton className="w-3.5 h-3.5 rounded-full bg-white/15" />
          <Skeleton className="w-3.5 h-3.5 rounded-full bg-white/15" />
        </div>
      </div>

      {/* Content Skeleton */}
      <div className="p-5 space-y-4 flex-1 flex flex-col justify-between">
        <div className="space-y-2.5">
          <div className="flex items-center justify-between">
            <Skeleton className="w-24 h-3 rounded" />
            <Skeleton className="w-12 h-3 rounded" />
          </div>
          <Skeleton className="w-3/4 h-5 rounded" />
          <Skeleton className="w-full h-3 rounded" />
          <Skeleton className="w-2/3 h-3 rounded" />
        </div>

        {/* Size chips skeleton */}
        <div className="space-y-1.5 pt-1">
          <Skeleton className="w-16 h-2.5 rounded" />
          <div className="flex gap-1.5">
            <Skeleton className="w-7 h-7 rounded-lg" />
            <Skeleton className="w-7 h-7 rounded-lg" />
            <Skeleton className="w-7 h-7 rounded-lg" />
            <Skeleton className="w-7 h-7 rounded-lg" />
          </div>
        </div>

        {/* Price & Action Row */}
        <div className="pt-3 border-t border-white/[0.06] flex items-center justify-between gap-3">
          <div className="space-y-1">
            <Skeleton className="w-16 h-6 rounded" />
            <Skeleton className="w-12 h-2.5 rounded" />
          </div>
          <div className="flex gap-2">
            <Skeleton className="w-9 h-9 rounded-xl" />
            <Skeleton className="w-20 h-9 rounded-xl" />
          </div>
        </div>
      </div>
    </div>
  );
};

export const ProductGridSkeleton: React.FC<{ count?: number }> = ({ count = 6 }) => {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
      {Array.from({ length: count }).map((_, index) => (
        <ProductCardSkeleton key={index} />
      ))}
    </div>
  );
};

export const ProductDetailSkeleton: React.FC = () => {
  return (
    <div className="py-10 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-10">
      {/* Top back breadcrumb skeleton */}
      <div className="flex items-center justify-between pb-4 border-b border-white/[0.06]">
        <Skeleton className="w-36 h-4 rounded" />
        <Skeleton className="w-48 h-4 rounded hidden sm:block" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14">
        {/* Left Column: Image Showcase Skeleton */}
        <div className="lg:col-span-7 space-y-4">
          <div className="relative aspect-[4/4.6] rounded-3xl overflow-hidden bg-[#0c0c14] border border-white/10 p-6">
            <Skeleton className="w-full h-full rounded-2xl" />
          </div>

          {/* Thumbnail Strip Skeleton */}
          <div className="grid grid-cols-4 gap-3">
            <Skeleton className="aspect-square rounded-2xl" />
            <Skeleton className="aspect-square rounded-2xl" />
            <Skeleton className="aspect-square rounded-2xl" />
            <Skeleton className="aspect-square rounded-2xl" />
          </div>
        </div>

        {/* Right Column: Product Info Skeleton */}
        <div className="lg:col-span-5 space-y-6">
          {/* Header & Badges */}
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <Skeleton className="w-24 h-5 rounded-full" />
              <Skeleton className="w-20 h-5 rounded-full" />
            </div>
            <Skeleton className="w-full h-10 rounded-xl" />
            <Skeleton className="w-2/3 h-6 rounded-lg" />
            
            {/* Price & Reviews */}
            <div className="flex items-center gap-4 pt-2">
              <Skeleton className="w-28 h-8 rounded-lg" />
              <Skeleton className="w-32 h-5 rounded-lg" />
            </div>
          </div>

          {/* Color Selection Skeleton */}
          <div className="space-y-2 pt-4 border-t border-white/[0.08]">
            <Skeleton className="w-28 h-3.5 rounded" />
            <div className="flex gap-2">
              <Skeleton className="w-9 h-9 rounded-full" />
              <Skeleton className="w-9 h-9 rounded-full" />
              <Skeleton className="w-9 h-9 rounded-full" />
              <Skeleton className="w-9 h-9 rounded-full" />
            </div>
          </div>

          {/* Size Selection Skeleton */}
          <div className="space-y-2 pt-4 border-t border-white/[0.08]">
            <div className="flex justify-between">
              <Skeleton className="w-24 h-3.5 rounded" />
              <Skeleton className="w-16 h-3.5 rounded" />
            </div>
            <div className="grid grid-cols-5 gap-2">
              <Skeleton className="h-11 rounded-xl" />
              <Skeleton className="h-11 rounded-xl" />
              <Skeleton className="h-11 rounded-xl" />
              <Skeleton className="h-11 rounded-xl" />
              <Skeleton className="h-11 rounded-xl" />
            </div>
          </div>

          {/* Quantity & CTA Button Skeletons */}
          <div className="space-y-3 pt-6 border-t border-white/[0.08]">
            <div className="flex gap-4">
              <Skeleton className="w-32 h-14 rounded-2xl" />
              <Skeleton className="flex-1 h-14 rounded-2xl" />
            </div>
            <Skeleton className="w-full h-12 rounded-2xl" />
          </div>

          {/* Value props skeleton */}
          <div className="grid grid-cols-3 gap-3 pt-6 border-t border-white/[0.08]">
            <Skeleton className="h-16 rounded-xl" />
            <Skeleton className="h-16 rounded-xl" />
            <Skeleton className="h-16 rounded-xl" />
          </div>
        </div>
      </div>
    </div>
  );
};
