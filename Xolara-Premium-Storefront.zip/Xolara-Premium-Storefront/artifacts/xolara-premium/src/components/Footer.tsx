import React from 'react';
import { ArrowUpRight } from 'lucide-react';
import { useStore } from '../context/StoreContext';

export const Footer: React.FC = () => {
  const { navigateTo } = useStore();

  const links = [
    { label: 'Shop collection', view: 'shop' },
    { label: 'Custom studio', view: 'custom-design' },
    { label: 'Our story', view: 'about' },
    { label: 'Contact', view: 'contact' },
    { label: 'Manage store', view: 'admin' },
  ];

  return (
    <footer className="border-t border-[#34464b]/70 bg-[#0a0e13]">
      <div className="mx-auto flex max-w-[1440px] flex-col gap-7 px-6 py-8 sm:px-10 lg:flex-row lg:items-center lg:justify-between lg:px-16">
        <div>
          <button
            onClick={() => navigateTo('home')}
            className="font-heading text-sm font-semibold uppercase tracking-[.2em] text-[#f3efe5]"
          >
            Xolara<span className="text-[#e89b4c]">.</span>
          </button>
          <p className="mt-1 text-[10px] uppercase tracking-[.15em] text-[#8d948f]">
            Made in India · Prices in INR
          </p>
        </div>

        <nav aria-label="Footer navigation" className="flex flex-wrap gap-x-6 gap-y-3">
          {links.map(({ label, view }) => (
            <button
              key={view}
              onClick={() => navigateTo(view)}
              className={`text-[10px] font-semibold uppercase tracking-[.14em] transition-colors ${
                view === 'admin'
                  ? 'text-[#78c3bc] hover:text-[#e89b4c]'
                  : 'text-[#b9b9ae] hover:text-[#e89b4c]'
              }`}
            >
              {label}
            </button>
          ))}
        </nav>

        <div className="flex items-center justify-between gap-6 border-t border-[#34464b]/50 pt-4 font-mono text-[9px] uppercase tracking-[.12em] text-[#737a79] lg:border-0 lg:pt-0">
          <span>© {new Date().getFullYear()} Xolara Premium</span>
          <button
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            className="flex items-center gap-1.5 text-[#b9b9ae] transition-colors hover:text-[#e89b4c]"
          >
            Back to top <ArrowUpRight className="h-3 w-3" />
          </button>
        </div>
      </div>
    </footer>
  );
};