import React, { useState, useEffect } from 'react';
import { useStore } from '../context/StoreContext';
import { ProductCategory, Product, ProductColor } from '../types';
import { 
  ShoppingBag, 
  Heart, 
  Zap, 
  Sparkles, 
  Filter, 
  ArrowUpDown,
  Search,
  Check,
  Eye
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { ImageWithSkeleton, ProductGridSkeleton } from './Skeletons';
import { formatINR } from '../lib/currency';

const CATEGORIES: ProductCategory[] = [
  'ALL',
  'T-SHIRTS',
  'OVERSIZED',
  'STREETWEAR',
  'CUSTOM DESIGNS',
  'NEW DROPS'
];

export const ShopSection: React.FC = () => {
  const { 
    products, 
    activeCategory, 
    setActiveCategory, 
    addToCart, 
    toggleWishlist, 
    wishlist, 
    navigateTo,
    setIsCheckoutOpen
  } = useStore();

  const [searchFilter, setSearchFilter] = useState('');
  const [sortBy, setSortBy] = useState<'featured' | 'price-asc' | 'price-desc' | 'newest'>('featured');
  const [isGridLoading, setIsGridLoading] = useState(false);
  
  // Card-specific selections for size & color
  const [selectedCardSizes, setSelectedCardSizes] = useState<Record<string, string>>({});
  const [selectedCardColors, setSelectedCardColors] = useState<Record<string, ProductColor>>({});

  // Simulate smooth skeleton transition on category change
  const handleCategoryChange = (cat: ProductCategory) => {
    if (cat === activeCategory) return;
    setIsGridLoading(true);
    setActiveCategory(cat);
    setTimeout(() => {
      setIsGridLoading(false);
    }, 280);
  };

  // Filter products by category and search
  const filteredProducts = products.filter(product => {
    const matchesCategory = activeCategory === 'ALL' || product.category === activeCategory;
    const matchesSearch = 
      product.name.toLowerCase().includes(searchFilter.toLowerCase()) ||
      product.description.toLowerCase().includes(searchFilter.toLowerCase()) ||
      product.sku.toLowerCase().includes(searchFilter.toLowerCase()) ||
      product.tags.some(t => t.toLowerCase().includes(searchFilter.toLowerCase()));
    
    return matchesCategory && matchesSearch;
  });

  // Sort products
  const sortedProducts = [...filteredProducts].sort((a, b) => {
    const priceA = a.discountPrice || a.price;
    const priceB = b.discountPrice || b.price;

    if (sortBy === 'price-asc') return priceA - priceB;
    if (sortBy === 'price-desc') return priceB - priceA;
    if (sortBy === 'newest') return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    return (b.isFeatured ? 1 : 0) - (a.isFeatured ? 1 : 0);
  });

  const handleSizeSelect = (productId: string, size: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setSelectedCardSizes(prev => ({ ...prev, [productId]: size }));
  };

  const handleColorSelect = (productId: string, color: ProductColor, e: React.MouseEvent) => {
    e.stopPropagation();
    setSelectedCardColors(prev => ({ ...prev, [productId]: color }));
  };

  const handleAddToCart = (product: Product, e: React.MouseEvent) => {
    e.stopPropagation();
    const size = selectedCardSizes[product.id] || product.sizes[0] || 'L';
    const color = selectedCardColors[product.id] || product.colors[0];
    addToCart(product, size, color);
  };

  const handleBuyNow = (product: Product, e: React.MouseEvent) => {
    e.stopPropagation();
    const size = selectedCardSizes[product.id] || product.sizes[0] || 'L';
    const color = selectedCardColors[product.id] || product.colors[0];
    addToCart(product, size, color);
    setIsCheckoutOpen(true);
  };

  return (
    <section 
      id="shop-section" 
      className="mx-auto max-w-[1440px] px-4 py-20 sm:px-6 lg:px-12"
    >
      {/* Shop Header */}
      <div className="text-center max-w-3xl mx-auto mb-12 space-y-3">
        <div className="inline-flex items-center gap-2 border border-[#e89b4c]/40 bg-[#e89b4c]/10 px-3 py-1 text-[10px] font-bold uppercase tracking-[0.25em] text-[#e89b4c]">
          <Sparkles className="h-3 w-3 text-[#e89b4c]" />
          <span>CURATED STREETWEAR CATALOG</span>
        </div>
        
        <h2 className="font-heading text-3xl font-semibold uppercase tracking-tight text-[#f3efe5] sm:text-5xl lg:text-6xl">
          Explore the <span className="text-[#e89b4c]">collection</span>
        </h2>
        
        <p className="text-xs uppercase tracking-wider text-[#8d948f] sm:text-sm">
          India-made streetwear. All listed product prices are in Indian rupees.
        </p>
      </div>

      {/* Categories & Filter Controls */}
      <div className="mb-10 space-y-6">
        
        {/* Category Buttons Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none justify-start lg:justify-center">
          {CATEGORIES.map((cat) => {
            const isActive = activeCategory === cat;
            return (
              <button
                key={cat}
                id={`category-tab-${cat.toLowerCase().replace(/\s+/g, '-')}`}
                onClick={() => handleCategoryChange(cat)}
                className={`relative px-5 py-2.5 rounded-lg text-[10px] font-bold tracking-[0.2em] uppercase transition-all duration-200 whitespace-nowrap flex-shrink-0 ${
                  isActive
                    ? 'bg-[#e89b4c] text-[#0d1016]'
                    : 'border border-[#34464b] bg-[#f3efe5]/[.03] text-[#b9b9ae] hover:bg-[#f3efe5]/[.08] hover:text-[#f3efe5]'
                }`}
              >
                <span>{cat}</span>
              </button>
            );
          })}
        </div>

        {/* Search Bar & Sort Dropdown */}
        <div className="flex flex-col items-center justify-between gap-4 border-y border-[#34464b] bg-[#0d1016]/70 p-4 backdrop-blur-md sm:flex-row">
          <div className="relative w-full sm:w-80">
            <Search className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-[#8d948f]" />
            <input
              type="text"
              placeholder="Search by name, fabric, or SKU..."
              value={searchFilter}
              onChange={(e) => setSearchFilter(e.target.value)}
              className="w-full border border-[#34464b] bg-[#f3efe5]/[.03] py-2 pl-10 pr-4 text-xs text-[#f3efe5] placeholder-[#8d948f] focus:border-[#e89b4c] focus:outline-none"
            />
            {searchFilter && (
              <button
                onClick={() => setSearchFilter('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-white/40 hover:text-white text-xs"
              >
                Clear
              </button>
            )}
          </div>

          <div className="flex items-center gap-3 w-full sm:w-auto justify-between sm:justify-end">
            <span className="text-xs font-mono text-white/50">
              Showing <strong className="text-white">{sortedProducts.length}</strong> styles
            </span>

            <div className="flex items-center gap-2">
              <ArrowUpDown className="w-3.5 h-3.5 text-white/40" />
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
              className="cursor-pointer border border-[#34464b] bg-[#f3efe5]/[.03] px-3 py-2 text-xs text-[#f3efe5] focus:border-[#2b827d] focus:outline-none"
              >
                <option value="featured" className="bg-[#0a0a0a]">Featured Drops</option>
                <option value="price-asc" className="bg-[#0a0a0a]">Price: Low to High</option>
                <option value="price-desc" className="bg-[#0a0a0a]">Price: High to Low</option>
                <option value="newest" className="bg-[#0a0a0a]">Newest Releases</option>
              </select>
            </div>
          </div>
        </div>

      </div>

      {/* Loading Skeleton Grid Screen */}
      {isGridLoading ? (
        <ProductGridSkeleton count={8} />
      ) : sortedProducts.length === 0 ? (
        <div className="space-y-4 rounded-2xl border border-[#34464b] bg-[#11161c] p-8 py-24 text-center">
          <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full border border-[#e89b4c]/40 bg-[#e89b4c]/10 text-[#e89b4c]">
            <Filter className="w-8 h-8" />
          </div>
          <h3 className="font-heading font-bold text-xl text-white">No Pieces Match Your Filter</h3>
          <p className="text-white/50 text-xs sm:text-sm max-w-md mx-auto uppercase tracking-wider">
            Try adjusting your search criteria or switch categories to explore other limited garments.
          </p>
          <button
            onClick={() => {
              setActiveCategory('ALL');
              setSearchFilter('');
            }}
            className="bg-[#e89b4c] px-6 py-2.5 text-xs font-bold uppercase tracking-wider text-[#0d1016]"
          >
            Reset Filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 sm:gap-8">
          {sortedProducts.map((product) => {
            const isWishlisted = wishlist.includes(product.id);
            const activeSize = selectedCardSizes[product.id] || product.sizes[0] || 'L';
            const activeColor = selectedCardColors[product.id] || product.colors[0];
            const displayPrice = product.discountPrice || product.price;

            return (
              <motion.div
                key={product.id}
                layout
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ duration: 0.4 }}
                className="group flex flex-col justify-between overflow-hidden border border-[#34464b] bg-[#11161c] transition-all duration-300 hover:-translate-y-1 hover:border-[#e89b4c]"
              >
                {/* Image Container with Zoom and ImageWithSkeleton */}
                <div 
                  onClick={() => navigateTo('product-detail', product)}
                  className="relative aspect-[3/3.8] cursor-pointer overflow-hidden bg-[#182026]"
                >
                  <ImageWithSkeleton
                    src={product.images[0]}
                    alt={product.name}
                    aspectRatio="aspect-[3/3.8]"
                    className="transition-transform duration-700 ease-out group-hover:scale-105"
                    loading="lazy"
                  />

                  {/* Dark Radial Gradient Overlay */}
                  <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-[#11161c] via-transparent to-transparent opacity-90" />

                  {/* Badges on Image */}
                  <div className="absolute top-3 left-3 flex flex-col gap-1.5 z-10 pointer-events-none">
                    <span className="bg-[#2b827d] px-2 py-0.5 text-[9px] font-bold uppercase tracking-widest text-white">
                      MADE IN INDIA
                    </span>
                    {product.isLimitedDrop && (
                      <span className="bg-[#e89b4c] px-2 py-0.5 text-[9px] font-black uppercase tracking-widest text-[#0d1016]">
                        LIMITED
                      </span>
                    )}
                    {product.discountPrice && (
                      <span className="bg-[#2b827d] px-2 py-0.5 font-mono text-[9px] font-bold text-[#f3efe5]">
                        SAVE {formatINR(product.price - product.discountPrice)}
                      </span>
                    )}
                  </div>

                  {/* Wishlist Button */}
                  <button
                    id={`wishlist-btn-${product.id}`}
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleWishlist(product.id);
                    }}
                    className={`absolute top-3 right-3 w-8 h-8 rounded-lg backdrop-blur-md border flex items-center justify-center transition-all z-20 ${
                      isWishlisted
                        ? 'border-[#2b827d] bg-[#2b827d] text-[#f3efe5]'
                        : 'border-[#b9b9ae]/20 bg-[#0d1016]/75 text-[#b9b9ae] hover:border-[#e89b4c] hover:text-[#f3efe5]'
                    }`}
                    aria-label="Wishlist"
                  >
                    <Heart className={`w-3.5 h-3.5 ${isWishlisted ? 'fill-current' : ''}`} />
                  </button>

                  {/* Quick Detail Hover Peek Overlay */}
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center pointer-events-none">
                    <span className="px-4 py-2 rounded-lg bg-white/10 backdrop-blur-md border border-white/20 text-white text-[10px] font-bold tracking-widest uppercase flex items-center gap-1.5 shadow-lg">
                      <Eye className="w-3.5 h-3.5 text-[#D90429]" />
                      <span>View Garment</span>
                    </span>
                  </div>
                </div>

                {/* Content & Control Area */}
                <div className="p-4 sm:p-5 flex-1 flex flex-col justify-between space-y-4">
                  <div>
                    <div className="flex items-center justify-between text-[9px] text-white/40 font-mono uppercase mb-1">
                      <span>{product.category}</span>
                      <span>{product.sizes.length} SIZES</span>
                    </div>

                    <h3 
                      onClick={() => navigateTo('product-detail', product)}
                      className="cursor-pointer truncate font-heading text-sm font-semibold text-[#f3efe5] transition-colors hover:text-[#e89b4c] sm:text-base"
                    >
                      {product.name}
                    </h3>

                    {/* Price Display */}
                    <div className="flex items-baseline gap-2 mt-2">
                      <span className="font-heading font-bold text-base text-white font-mono">
                        {formatINR(displayPrice)}
                      </span>
                      {product.discountPrice && (
                        <span className="text-[11px] text-white/40 line-through font-mono">
                          {formatINR(product.price)}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Available Colors Swatches */}
                  <div className="space-y-1.5">
                    <div className="text-[9px] text-white/40 tracking-wider uppercase flex items-center justify-between font-mono">
                      <span>Color: <strong className="text-white">{activeColor.name}</strong></span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      {product.colors.map((c) => {
                        const isSelected = activeColor.name === c.name;
                        return (
                          <button
                            key={c.name}
                            onClick={(e) => handleColorSelect(product.id, c, e)}
                            className={`w-4 h-4 rounded-full border transition-all flex items-center justify-center ${
                              isSelected
                        ? 'scale-110 border-[#e89b4c]'
                                : 'border-white/20 hover:border-white/50'
                            }`}
                            style={{ backgroundColor: c.hex }}
                            title={c.name}
                          >
                            {isSelected && <Check className="w-2 h-2 text-white stroke-[3]" />}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Size Options Selector */}
                  <div className="space-y-1.5">
                    <div className="text-[9px] text-white/40 tracking-wider uppercase font-mono">
                      Size:
                    </div>
                    <div className="flex flex-wrap gap-1.5">
                      {product.sizes.map((s) => {
                        const isSelected = activeSize === s;
                        return (
                          <button
                            key={s}
                            onClick={(e) => handleSizeSelect(product.id, s, e)}
                            className={`px-2 py-0.5 rounded text-[9px] font-mono font-bold transition-all ${
                              isSelected
                              ? 'bg-[#e89b4c] text-[#0d1016]'
                              : 'border border-[#34464b] bg-[#f3efe5]/[.03] text-[#b9b9ae] hover:bg-[#f3efe5]/[.08]'
                            }`}
                          >
                            {s}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Dual Action Buttons: Add to Cart & Buy Now */}
                  <div className="pt-2 grid grid-cols-2 gap-2">
                    <button
                      id={`add-to-cart-${product.id}`}
                      onClick={(e) => handleAddToCart(product, e)}
                      className="flex items-center justify-center gap-1.5 border border-[#34464b] bg-[#f3efe5]/[.03] px-3 py-2.5 text-[10px] font-bold uppercase tracking-wider text-[#f3efe5] transition-all hover:border-[#e89b4c] hover:bg-[#f3efe5]/[.08]"
                    >
                      <ShoppingBag className="h-3 w-3 text-[#e89b4c]" />
                      <span>Add To Cart</span>
                    </button>

                    <button
                      id={`buy-now-${product.id}`}
                      onClick={(e) => handleBuyNow(product, e)}
                      className="flex items-center justify-center gap-1 bg-[#e89b4c] px-3 py-2.5 text-[10px] font-bold uppercase tracking-wider text-[#0d1016] transition-all hover:-translate-y-0.5"
                    >
                      <Zap className="w-3 h-3" />
                      <span>Buy Now</span>
                    </button>
                  </div>

                </div>
              </motion.div>
            );
          })}
        </div>
      )}
    </section>
  );
};
