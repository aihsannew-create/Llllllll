export type ProductCategory = 
  | 'ALL' 
  | 'T-SHIRTS' 
  | 'OVERSIZED' 
  | 'STREETWEAR' 
  | 'CUSTOM DESIGNS' 
  | 'NEW DROPS';

export type ProductStatus = 'Active' | 'Draft' | 'Sold Out' | 'Limited Drop';

export interface ProductColor {
  name: string;
  hex: string;
}

export interface Product {
  id: string;
  sku: string;
  name: string;
  slug: string;
  category: ProductCategory;
  price: number;
  discountPrice?: number;
  images: string[];
  colors: ProductColor[];
  sizes: ('XS' | 'S' | 'M' | 'L' | 'XL' | '2XL' | '3XL')[];
  description: string;
  fabricSpecs: string;
  stock: number;
  status: ProductStatus;
  isFeatured?: boolean;
  isLimitedDrop?: boolean;
  rating: number;
  reviewsCount: number;
  tags: string[];
  createdAt: string;
}

export interface CustomDesignSpecs {
  productType: string;
  baseColor: string;
  colorName: string;
  size: string;
  quantity: number;
  designImage?: string;
  customText?: string;
  textColor?: string;
  textFont?: string;
  position: 'Front Chest' | 'Oversized Front' | 'Back Center' | 'Sleeve Minimal';
  scale: number;
  specialInstructions?: string;
  estimatedPrice: number;
}

export interface CartItem {
  id: string;
  productId: string;
  product: Product;
  selectedColor: ProductColor;
  selectedSize: string;
  quantity: number;
  customSpecs?: CustomDesignSpecs;
}

export interface CustomDesignSubmission {
  id: string;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  productType: string;
  baseColor: string;
  colorName: string;
  size: string;
  quantity: number;
  designImage?: string;
  customText?: string;
  position: string;
  specialInstructions: string;
  status: 'Received' | 'In Review' | 'Sample Approved' | 'In Production' | 'Completed';
  createdAt: string;
  estimatedPrice: number;
}

export interface OrderCustomerInfo {
  fullName: string;
  email: string;
  phone: string;
  address: string;
  city: string;
  state: string;
  zipCode: string;
  country: string;
}

export interface Order {
  id: string;
  orderNumber: string;
  items: CartItem[];
  customer: OrderCustomerInfo;
  paymentMethod: 'Manual confirmation required';
  subtotal: number;
  discount: number;
  shipping: number;
  tax: number;
  total: number;
  status: 'Request Received' | 'Processing' | 'Shipped' | 'Delivered';
  createdAt: string;
}
