import { ArrowLeft, AlertCircle } from 'lucide-react';

export default function NotFound() {
  return (
    <main className="flex min-h-[100dvh] items-center justify-center bg-[#0d1016] px-6 text-[#f3efe5]">
      <section className="w-full max-w-md border border-[#34464b] bg-[#11161c] p-8">
        <div className="mb-5 flex items-center gap-3 text-[#e89b4c]">
          <AlertCircle className="h-6 w-6" />
          <span className="font-mono text-[10px] uppercase tracking-[.24em]">Archive error / 404</span>
        </div>
        <h1 className="font-heading text-3xl font-semibold uppercase tracking-tight">Piece not found.</h1>
        <p className="mt-3 text-sm leading-6 text-[#8d948f]">This page is outside the current XOLARA archive. Return to the index and continue exploring.</p>
        <button onClick={() => window.history.back()} className="mt-8 flex items-center gap-3 border border-[#e89b4c] px-4 py-3 text-[10px] font-bold uppercase tracking-[.2em] text-[#e89b4c] transition-colors hover:bg-[#e89b4c] hover:text-[#0d1016]">
          <ArrowLeft className="h-4 w-4" /> Return
        </button>
      </section>
    </main>
  );
}