/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect } from 'react';
import { StoreProvider, useStore } from './context/StoreContext';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { FeaturedDrop } from './components/FeaturedDrop';
import { ShopSection } from './components/ShopSection';
import { ProductDetailPage } from './components/ProductDetailPage';
import { CustomDesignStudio } from './components/CustomDesignStudio';
import { WhyXolara } from './components/WhyXolara';
import { AboutSection } from './components/AboutSection';
import { ContactSection } from './components/ContactSection';
import { AdminCMS } from './components/AdminCMS';
import { CartDrawer } from './components/CartDrawer';
import { WishlistDrawer } from './components/WishlistDrawer';
import { SearchModal } from './components/SearchModal';
import { CheckoutModal } from './components/CheckoutModal';
import { ToastNotifications } from './components/ToastNotifications';
import { Footer } from './components/Footer';
import { motion, AnimatePresence } from 'motion/react';

const MainLayout: React.FC = () => {
  const { activeView } = useStore();

  // Scroll to top on view changes
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [activeView]);

  return (
    <div className="min-h-[100dvh] bg-[#0d1016] text-[#f3efe5] flex flex-col font-sans antialiased overflow-x-hidden">
      <div className="noise-overlay" aria-hidden="true" />
      
      {/* Sticky Glass Header Navigation */}
      <Header />

      {/* Main Dynamic View Content */}
      <main className="flex-1">
        <AnimatePresence mode="wait">
          
          {/* HOME VIEW: Full High-Impact International Fashion Experience */}
          {activeView === 'home' && (
            <motion.div
              key="home"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.4 }}
        className="space-y-0"
            >
              <Hero />
              <FeaturedDrop />
            </motion.div>
          )}

          {/* SHOP VIEW: Comprehensive Catalog with Filters */}
          {activeView === 'shop' && (
            <motion.div
              key="shop"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.35 }}
               className="pt-10 pb-16"
            >
              <ShopSection />
            </motion.div>
          )}

          {/* PRODUCT DETAIL VIEW: Image Zoom, Specs & Reviews */}
          {activeView === 'product-detail' && (
            <motion.div
              key="product-detail"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.35 }}
               className="pt-10 pb-16"
            >
              <ProductDetailPage />
            </motion.div>
          )}

          {/* CUSTOM DESIGN STUDIO: 2D Garment Visualizer */}
          {activeView === 'custom-design' && (
            <motion.div
              key="custom-design"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.35 }}
               className="pt-10 pb-16"
            >
              <CustomDesignStudio />
            </motion.div>
          )}

          {/* ADMIN / CMS: Master Upload & Product Management System */}
          {activeView === 'admin' && (
            <motion.div
              key="admin"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.35 }}
              className="pt-6 pb-16"
            >
              <AdminCMS />
            </motion.div>
          )}

          {/* ABOUT MANIFESTO VIEW */}
          {activeView === 'about' && (
            <motion.div
              key="about"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.35 }}
              className="pt-8 pb-16 space-y-12"
            >
              <AboutSection />
              <WhyXolara />
            </motion.div>
          )}

          {/* CONTACT & FAQ VIEW */}
          {activeView === 'contact' && (
            <motion.div
              key="contact"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.35 }}
              className="pt-8 pb-16"
            >
              <ContactSection />
            </motion.div>
          )}

        </AnimatePresence>
      </main>

      {/* Slide-out Cart Drawer */}
      <CartDrawer />

      {/* Vault Wishlist Drawer */}
      <WishlistDrawer />

      {/* Search Modal */}
      <SearchModal />

      {/* 256-Bit SSL Checkout Modal */}
      <CheckoutModal />

      {/* System Toast Alerts */}
      <ToastNotifications />

      {/* Atelier Dark Footer */}
      <Footer />

    </div>
  );
};

export default function App() {
  return (
    <StoreProvider>
      <MainLayout />
    </StoreProvider>
  );
}
