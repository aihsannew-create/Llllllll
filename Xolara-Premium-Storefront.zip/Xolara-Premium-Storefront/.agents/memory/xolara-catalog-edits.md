---
name: Xolara catalog editing scope
description: The store manager is intentionally browser-local rather than a shared live catalog.
---

Keep Xolara product edits saved only in the current browser; do not add login, central storage, or cross-visitor synchronization unless the user changes this decision.

**Why:** the user chose browser-only editing instead of a shared dashboard.

**How to apply:** preserve browser-local product persistence and clearly state that changes do not appear on other devices or visitors' browsers.